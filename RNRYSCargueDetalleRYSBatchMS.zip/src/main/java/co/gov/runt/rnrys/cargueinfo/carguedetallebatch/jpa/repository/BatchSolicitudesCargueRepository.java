package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.jpa.repository;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.jpa.entity.BatchSolicitudesCargueEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repositorio que contiene todas las operaciones necesarias para gestionar de la entidad
 * BatchSolicitudesCargueEntity.
 */
@Repository
public interface BatchSolicitudesCargueRepository
    extends JpaRepository<BatchSolicitudesCargueEntity, Long> {}
