package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service;

/**
 * Interfaz para la gestión del servicio Batch de cargue de archivos de detalle de vehículo.
 *
 * @since 1.0.0
 */
public interface IBatchCargueDetalleService {

  /** Método para ejecutar el batch de cargue de detalle de vehículo. */
  void procesarCargueDetalle();
}
