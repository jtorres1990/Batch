package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.utilidades.exception.ErrorGeneralException;

/**
 * Interfaz con todos los métodos disponibles para los registros del tipo de cargue creación.
 *
 * @since 1.0.0
 */
public interface IRegistrosCreacionService {
  /**
   * Método para realizar el proceso registrar el cargue de creación.
   *
   * @param vehiculoDTO DTO con la informacion para el cargue.
   * @param nit Numero de identificación del ensamblador, importador o fabricante.
   * @param idUsuario Identificador del usuario.
   * @param idAutoridad Identificador de la autoridad de tránsito.
   * @param ipUsuario Ip del usuario.
   * @param idSolicitud Identificador de la solicitud.
   * @throws ErrorGeneralException error general cuando no cumple con ninguna condición evaluada.
   */
  void registrarCargueCreacion(
      VehiculoDTO vehiculoDTO,
      String nit,
      String idUsuario,
      Long idAutoridad,
      String ipUsuario,
      Long idSolicitud)
      throws ErrorGeneralException;
}
