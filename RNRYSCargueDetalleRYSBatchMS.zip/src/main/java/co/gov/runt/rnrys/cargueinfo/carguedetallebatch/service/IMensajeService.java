package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums.MensajesErrorEnum;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.MensajeEntity;
import co.gov.runt.utilidades.exception.ErrorGeneralException;

/**
 * Recuperar mensajes
 *
 * @since 1.0.0
 */
public interface IMensajeService {

  /**
   * Obtener mensaje mensaje entity.
   *
   * @param mensajesErrorEnum the mensajes error enum
   * @return the mensaje entity
   * @throws ErrorGeneralException the error general exception
   */
  MensajeEntity obtenerMensaje(MensajesErrorEnum mensajesErrorEnum) throws ErrorGeneralException;
}
