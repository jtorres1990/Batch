package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/** Enum que representa los los valores de la constante VALIDACION WS DIAN */
@Getter
@RequiredArgsConstructor
public enum ValorConstanteWSDIANEnum {
  /** Valor SI */
  SI("SI"),

  /** Valor NO */
  NO("NO");

  private final String valor;
}
