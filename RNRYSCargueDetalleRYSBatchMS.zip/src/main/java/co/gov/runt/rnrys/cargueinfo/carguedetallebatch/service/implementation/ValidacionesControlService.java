package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.batch.model.ColumnNames;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.MensajeValidacionesControlDTO;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums.MensajesErrorEnum;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IMensajeService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IValidacionesControlService;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.PersonaEntity;
import co.gov.runt.rnrys.cargueinfo.validaciones.service.implementation.DependeciasManager;
import co.gov.runt.rnrys.cargueinfo.validaciones.utilities.Constantes;
import co.gov.runt.rnrys.cargueinfo.validaciones.utilities.Util;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import co.gov.runt.utilidades.utilities.FechaUtilidad;
import java.text.MessageFormat;
import java.util.Date;
import java.util.Optional;
import java.util.regex.Pattern;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Clase que implementa las funcionalidades de la interfaz IValidacionesControlService
 *
 * @since 1.0.0
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ValidacionesControlService implements IValidacionesControlService {

  private final DependeciasManager dependeciasManager;
  private final IMensajeService mensajeService;

  @Override
  public MensajeValidacionesControlDTO validaNumeroRegistros(String totalRegistros)
      throws ErrorGeneralException {
    log.info("Inicio validacion numero de registros {}: ", totalRegistros);
    MensajeValidacionesControlDTO mensajeValidacionesControlDTO =
        new MensajeValidacionesControlDTO();
    if (Long.parseLong(totalRegistros) > 9999999) {
      mensajeValidacionesControlDTO.setError(Boolean.TRUE);
      mensajeValidacionesControlDTO.setMensaje(
          mensajeService.obtenerMensaje(MensajesErrorEnum.ERROR_VALOR_MAXIMO_REGISTROS).getValor());
    } else {
      mensajeValidacionesControlDTO.setError(Boolean.FALSE);
    }
    return mensajeValidacionesControlDTO;
  }

  @Override
  public MensajeValidacionesControlDTO validaFechaCorte(String fechaCorte)
      throws ErrorGeneralException {
    MensajeValidacionesControlDTO mensajeValidacionesControlDTO =
        new MensajeValidacionesControlDTO();
    Date fechaCarga = new Date();
    Date fechaLimite = Util.convertStringToDateFormatFechAyyyyMMdd(Constantes.FECHA_LIMITE);
    Date fechaCorteDate = Util.convertStringToDateFormatFechAyyyyMMdd(fechaCorte);
    log.info(
        "result fecha carga" + (FechaUtilidad.compararFechas(fechaCorteDate, fechaCarga) == -1));
    log.info(
        "result fecha limite" + (FechaUtilidad.compararFechas(fechaCorteDate, fechaLimite) == 1));
    if ((FechaUtilidad.compararFechas(fechaCorteDate, fechaCarga) == -1)
        && (FechaUtilidad.compararFechas(fechaCorteDate, fechaLimite) == 1)) {
      mensajeValidacionesControlDTO.setError(Boolean.FALSE);
    } else {
      mensajeValidacionesControlDTO.setError(Boolean.TRUE);
      mensajeValidacionesControlDTO.setMensaje(
          mensajeService.obtenerMensaje(MensajesErrorEnum.ERROR_FECHA_DE_CORTE).getValor());
    }
    return mensajeValidacionesControlDTO;
  }

  @Override
  public boolean validaExpresionLinea(String linea) {
    return contarRegistros(linea) == ColumnNames.getColumnNames().length;
  }

  /**
   * Contar registros int.
   *
   * @param cadena the cadena
   * @return the int
   */
  public static int contarRegistros(String cadena) {
    String separador = Pattern.quote("|");
    String[] partes = cadena.split(separador, -1);
    return partes.length;
  }

  @Override
  public MensajeValidacionesControlDTO validarNit(String nit, String nombreArchivo)
      throws ErrorGeneralException {
    MensajeValidacionesControlDTO mensajeValidacionesControlDTO =
        new MensajeValidacionesControlDTO();
    Optional<PersonaEntity> persona =
        dependeciasManager.getPersonaRepository().getImportadorEnsambladorByNit(nit);
    if (persona.isEmpty()) {
      mensajeValidacionesControlDTO.setError(Boolean.TRUE);
      String mensaje =
          MessageFormat.format(
              mensajeService.obtenerMensaje(MensajesErrorEnum.ERROR_NIT).getValor(),
              nit,
              nombreArchivo);
      mensajeValidacionesControlDTO.setMensaje(mensaje);

    } else {
      mensajeValidacionesControlDTO.setError(Boolean.FALSE);
    }
    return mensajeValidacionesControlDTO;
  }
}
