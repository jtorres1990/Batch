package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.batch.processor;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.EjecutarValidacionesRequest;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IValidacionesCargueService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.utilities.Constantes;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

/** Clase responsable de tratar la información obtenida del vehciculo por el reader. */
@Slf4j
@Component
@RequiredArgsConstructor
public class VehiculoProcessor implements ItemProcessor<VehiculoDTO, VehiculoDTO> {

  private final IValidacionesCargueService validacionesCargueService;

  private String nit;
  private String nombreArchivo;

  private Long solicitudId;

  private Long idAutoridad;

  private Long idEmpresa;

  private String idUsuario;

  private boolean fallidoValEstruContenido;

  private Integer regFallidosValEstruContenido;

  private Integer registrosExitosos;

  private StepExecution stepExecution;

  /**
   * Metodo que obtiene los datos basicos para continuar la ejecución
   *
   * @param stepExecution the step execution
   */
  @BeforeStep
  public void beforeStep(StepExecution stepExecution) {
    this.stepExecution = stepExecution;
    JobParameters parametros = this.stepExecution.getJobExecution().getJobParameters();

    nit = parametros.getString("nit");
    solicitudId = parametros.getLong("solicitudId");
    nombreArchivo = parametros.getString("nombreArchivo");
    idAutoridad = parametros.getLong("idAutoridad");
    idEmpresa = parametros.getLong("idEmpresa");
    idUsuario = parametros.getString("idUsuario");
    fallidoValEstruContenido = false;
    regFallidosValEstruContenido = 0;
    registrosExitosos = 0;
  }

  /**
   * Método que se llamará despues de que se ejecute el writer, donde se cargan los parametros.
   *
   * @param stepExecution the step execution
   */
  @AfterStep
  public void afterStep(StepExecution stepExecution) {
    this.stepExecution = stepExecution;
    if (regFallidosValEstruContenido != null) {
      this.stepExecution
          .getJobExecution()
          .getExecutionContext()
          .put(Constantes.REGISTROS_FALLIDOS, regFallidosValEstruContenido);
    }

    if (registrosExitosos != null) {
      this.stepExecution
          .getJobExecution()
          .getExecutionContext()
          .put(Constantes.REGISTROS_EXITOSOS, registrosExitosos);
    }
  }

  /**
   * Metodo que procesa las validaciones de vehiculo.
   *
   * @param vehiculoDTO DTO Entrada.
   * @return vehiculoDTO
   */
  @Override
  public VehiculoDTO process(@NonNull VehiculoDTO vehiculoDTO) throws ErrorGeneralException {
    log.info("Inicia proceso ejecutar validaciones vehiculo {}", vehiculoDTO);
    EjecutarValidacionesRequest request = new EjecutarValidacionesRequest();
    request.setVehiculoDTO(vehiculoDTO);
    request.setNit(nit);
    request.setNombreArchivo(nombreArchivo);
    request.setIdAutoridad(idAutoridad);
    request.setIdEmpresa(idEmpresa);
    request.setIdUsuario(idUsuario);
    request.setSolicitudId(solicitudId);
    request.setFallidoValEstruContenido(fallidoValEstruContenido);

    VehiculoDTO vehiculoDT =
        validacionesCargueService.ejecutarValidaciones(
            request,
            validarInconsistente(vehiculoDTO.getSecuencia()),
            validarRepetido(vehiculoDTO));
    if (vehiculoDT.isFallidoValEstruContenido()) {
      regFallidosValEstruContenido = regFallidosValEstruContenido + 1;
      vehiculoDT = null;
    } else {
      registrosExitosos = registrosExitosos + 1;
    }
    log.info("Finaliza procesor Vehiculo para el archivo de la solicitud {}", solicitudId);
    return vehiculoDT;
  }

  @SuppressWarnings("unchecked")
  private boolean validarInconsistente(String consecutivo) {
    List<String> listaInconsistente =
        (List<String>)
            this.stepExecution
                .getJobExecution()
                .getExecutionContext()
                .get(Constantes.LISTA_INCONSISTENTES);
    if (listaInconsistente == null) return false;
    return listaInconsistente.stream().anyMatch(elemento -> elemento.equals(consecutivo));
  }

  @SuppressWarnings("unchecked")
  private boolean validarVinRepetido(String vin) {

    List<String> listavinExiste =
        (List<String>)
            this.stepExecution
                .getJobExecution()
                .getExecutionContext()
                .get(Constantes.LISTA_VIN_EXISTE);

    if (listavinExiste != null && listavinExiste.stream().anyMatch(s -> s.equals(vin))) {
      return true;
    } else {
      setListaRepetido(listavinExiste, vin);
    }

    return false;
  }

  private void setListaRepetido(List<String> listaVin, String vin) {

    if (listaVin != null) {
      listaVin.add(vin);
    } else {
      listaVin = new ArrayList<>();
      listaVin.add(vin);
    }

    this.stepExecution
        .getJobExecution()
        .getExecutionContext()
        .put(Constantes.LISTA_VIN_EXISTE, listaVin);
  }

  private boolean validarRepetido(VehiculoDTO vehiculoDTO) {
    String repetidos =
        this.stepExecution
            .getJobExecution()
            .getJobParameters()
            .getString(Constantes.LISTA_REPETIDOS);

    if (repetidos == null) return false;

    String[] partes = StringUtils.commaDelimitedListToStringArray(repetidos);
    List<String> repetidosLista = Arrays.asList(partes);
    return repetidosLista.stream().anyMatch(elemento -> elemento.equals(vehiculoDTO.getSecuencia()))
        || validarVinRepetido(vehiculoDTO.getVin());
  }
}
