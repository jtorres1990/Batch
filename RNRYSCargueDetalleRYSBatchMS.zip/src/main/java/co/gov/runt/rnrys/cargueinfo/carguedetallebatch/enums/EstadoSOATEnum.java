package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/** Enum que representa los Estados del SOAT */
@Getter
@RequiredArgsConstructor
public enum EstadoSOATEnum {

  /** Estado CANCELADO */
  CANCELADO("CANCELADO"),
  /** Estado ANULADO */
  ANULADO("ANULADO");

  private final String id;

  /**
   * Método encargado de validar el estado del SOAT si es ANULADO o CANCELADO
   *
   * @param id Identificador del estado del SOAT
   * @return Respuesta de la validación true o false
   * @since 1.0.0
   */
  public static boolean esAnuladoCancelado(String id) {
    return (CANCELADO.getId().equals(id) || ANULADO.getId().equals(id));
  }
}
