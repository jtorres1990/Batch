package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * DTO Respuesta para el proceso del validaciones control.
 *
 * @since 1.0.0
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class MensajeValidacionesControlDTO {

  private boolean isError;
  private String mensaje;
}
