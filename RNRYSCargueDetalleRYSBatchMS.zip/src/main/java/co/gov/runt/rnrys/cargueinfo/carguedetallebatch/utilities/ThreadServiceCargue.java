package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.utilities;

import co.gov.runt.rnf.procesadorsolicitudes.annotations.RuntFunction;
import co.gov.runt.rnf.procesadorsolicitudes.security.KafaRequestAttribute;
import co.gov.runt.rnf.procesadorsolicitudes.utilities.InformacionUsuarioUtilities;
import co.gov.runt.utilidades.utilities.InformacionUsuario;
import co.gov.runt.utilidades.utilities.TokenJWT;
import java.util.Objects;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobParameters;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;

/**
 * Clase encargada de ejecutar tareas en paralelo creando nuevos hilos de ejecución..
 *
 * @since 1.0.0
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ThreadServiceCargue {

  private final InformacionUsuario informacionUsuario;
  private final TokenJWT tokenJWT;
  private final InformacionUsuarioUtilities informacionUsuarioUtilities;

  /**
   * Execute on thread runnable.
   *
   * @param function the function
   * @param jobParameters the job parameters
   * @return the runnable
   */
  @SuppressWarnings({"squid:S6201", "squid:S6201"})
  public Runnable executeOnThread(RuntFunction function, JobParameters jobParameters) {

    UUID idTransaccion = UUID.randomUUID();
    String idTransaccionStr = idTransaccion.toString();
    InformacionUsuario usuario = new InformacionUsuario();
    TokenJWT token = new TokenJWT();
    this.insertarDatosSesion(usuario, jobParameters, idTransaccionStr);
    this.insertarToken(token, this.tokenJWT);

    return new Runnable() {
      @Override
      public void run() {

        RequestContextHolder.setRequestAttributes(new KafaRequestAttribute());
        informacionUsuarioUtilities.addCorrelationId(idTransaccionStr);
        insertarDatosSesion(informacionUsuario, jobParameters, idTransaccionStr);
        insertarToken(tokenJWT, token);

        try {
          function.apply();
        } catch (Throwable e) {
          rethrow(e);
          log.info("Error al ejectutar proceso {}", e.getMessage());
        }

        RequestContextHolder.resetRequestAttributes();
      }

      private void rethrow(Throwable t) {
        if (t instanceof RuntimeException) {
          throw (RuntimeException) t;
        } else if (t instanceof Error) {
          throw (Error) t;
        } else {
          throw new IllegalStateException(t);
        }
      }
    };
  }

  /**
   * Insertar datos sesion.
   *
   * @param informacionUsuario the informacion usuario
   * @param jobParameters the job parameters
   * @param idTransaccionStr the id transaccion str
   */
  public void insertarDatosSesion(
      InformacionUsuario informacionUsuario, JobParameters jobParameters, String idTransaccionStr) {
    informacionUsuario.setIdTransaccion(idTransaccionStr);
    informacionUsuario.setIdAutoridad(jobParameters.getLong(Constantes.IDAUTORIDAD));
    informacionUsuario.setIp(jobParameters.getString(Constantes.IPUSUARIO));
    informacionUsuario.setIdUsuario(
        Long.parseLong(Objects.requireNonNull(jobParameters.getString(Constantes.IDUSUARIO))));
    informacionUsuario.setNombreCompleto(jobParameters.getString(Constantes.NOMBRE_USUARIO));
  }

  private void insertarToken(TokenJWT tokenJWT, TokenJWT tokenJWT1) {
    tokenJWT.setToken(tokenJWT1.getToken());
  }
}
