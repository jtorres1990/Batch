package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.batch.writer;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums.TipoCargueArchivoEnum;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums.TipoLogMensajeEnum;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.ILogMensajeCargueService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IRegistrosCreacionService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IRegistrosEliminacionService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IRegistrosModificacionService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.utilities.Constantes;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;

/**
 * Clase responsable de guardar la información del vehiculo del archivo leida por el reader y
 * tratada por el processor .
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class VehiculoWriter implements ItemWriter<VehiculoDTO> {

  private final IRegistrosCreacionService registrosCreacionService;
  private final IRegistrosModificacionService registrosModificacionService;
  private final IRegistrosEliminacionService registrosEliminacionService;

  private String nit;
  private Long idAutoridad;
  private String idUsuario;
  private String ipUsuario;
  private Long solicitudId;
  private String nombreArchivo;

  private Integer registrosGuardados;

  private Integer totalErrores;
  private StepExecution stepExecution;
  private final ILogMensajeCargueService logMensajeCargueService;

  /**
   * Método que se llamará antes de que se ejecute el writer, donde se cargan los parametros.
   *
   * @param stepExecution StepExecution.
   */
  @BeforeStep
  public void beforeStep(StepExecution stepExecution) {

    this.stepExecution = stepExecution;
    JobParameters parametros = this.stepExecution.getJobExecution().getJobParameters();
    nit = parametros.getString("nit");
    idAutoridad = parametros.getLong("idAutoridad");
    idUsuario = parametros.getString("idUsuario");
    ipUsuario = parametros.getString("ipUsuario");
    solicitudId = parametros.getLong("solicitudId");
    nombreArchivo = parametros.getString("nombreArchivo");
    registrosGuardados = 0;
    totalErrores = 0;
  }

  /**
   * Método en donde se guardar la información del vehiculo que proviene del archivo.
   *
   * @param list Lista de VehiculoDTO.
   */
  @Override
  public void write(List<? extends VehiculoDTO> list) {
    if (!list.isEmpty()) {
      for (VehiculoDTO vehiculoDTO : list) {
        try {
          registrarTipoCargue(vehiculoDTO);
          setValorGuardado();
        } catch (Exception e) {
          logMensajeCargueService.guardarLog(
              e.getMessage(), solicitudId, TipoLogMensajeEnum.ERROR.getId());
          log.error(
              "Error al registrar el cargue del vehiculo. Registro número: {}, del archivo: {}.",
              vehiculoDTO.getSecuencia(),
              nombreArchivo);
          setErrores();
        }
      }
    } else {
      this.stepExecution
          .getJobExecution()
          .getExecutionContext()
          .putInt(Constantes.REGISTROS_GUARDADOS, registrosGuardados);
    }
    log.info("Finaliza escritura vehiculo para el archivo de la solicitud {}", solicitudId);
  }

  /**
   * Método en donde se orquesta el registro del cargue segun el tipo de cargue.
   *
   * @param vehiculoDTO DTO con los datos del cargue.
   * @throws ErrorGeneralException error general cuando no cumple con ninguna condición evaluada
   */
  private void registrarTipoCargue(VehiculoDTO vehiculoDTO) throws ErrorGeneralException {
    if (TipoCargueArchivoEnum.CREACION.getId().equals(vehiculoDTO.getTipoCargue())) {
      registrosCreacionService.registrarCargueCreacion(
          vehiculoDTO, nit, idUsuario, idAutoridad, ipUsuario, solicitudId);
    } else if (TipoCargueArchivoEnum.MODIFICACION.getId().equals(vehiculoDTO.getTipoCargue())) {
      registrosModificacionService.modificarCargueCreacion(
          vehiculoDTO, nit, idUsuario, idAutoridad, ipUsuario, solicitudId);
    } else if (TipoCargueArchivoEnum.ELIMINACION.getId().equals(vehiculoDTO.getTipoCargue())) {
      registrosEliminacionService.eliminarCargueCreacion(vehiculoDTO);
    }
  }

  /** Método en donde se obtiene el número de registros guardados. */
  private void setValorGuardado() {

    registrosGuardados = registrosGuardados + 1;
    log.info("Guardadas total {}", registrosGuardados);
    this.stepExecution
        .getJobExecution()
        .getExecutionContext()
        .putInt(Constantes.REGISTROS_GUARDADOS, registrosGuardados);
  }

  /** Método en donde se obtiene el número de registros guardados. */
  private void setErrores() {

    totalErrores = totalErrores + 1;
    log.info("Errores total {}", totalErrores);
    this.stepExecution
        .getJobExecution()
        .getExecutionContext()
        .putInt(Constantes.REGISTROS_FALLIDOS, totalErrores);
  }
}
