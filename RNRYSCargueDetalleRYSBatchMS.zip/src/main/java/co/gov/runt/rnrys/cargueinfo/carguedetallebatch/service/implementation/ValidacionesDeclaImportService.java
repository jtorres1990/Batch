package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums.*;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IMensajeService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IValidacionesControlService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IValidacionesDeclaImportService;
import co.gov.runt.rnrys.cargueinfo.core.consultas.dto.DetalleCargueVehiculoRequest;
import co.gov.runt.rnrys.cargueinfo.core.consultas.enums.EstadoDeclaracionEnum;
import co.gov.runt.rnrys.cargueinfo.core.consultas.enums.TipoFuenteDeclaracionEnum;
import co.gov.runt.rnrys.cargueinfo.core.consultas.enums.TipoServicioEnum;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.AutomotorEntity;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.RaDeclimportEntity;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.RpServicioEntity;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.repository.DeclaracionImportacionRepository;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.repository.RpServicioRepository;
import co.gov.runt.rnrys.cargueinfo.core.registros.dto.RegistroRequest;
import co.gov.runt.rnrys.cargueinfo.core.registros.service.IRegistroDeclaracionImportacionService;
import co.gov.runt.rnrys.cargueinfo.validaciones.dto.DeclaracionImportacionResponse;
import co.gov.runt.rnrys.cargueinfo.validaciones.enums.ConstanteGrupoEnum;
import co.gov.runt.rnrys.cargueinfo.validaciones.enums.ConstanteNombreEnum;
import co.gov.runt.rnrys.cargueinfo.validaciones.enums.Mensaje;
import co.gov.runt.rnrys.cargueinfo.validaciones.enums.RespuestaEstadoEnum;
import co.gov.runt.rnrys.cargueinfo.validaciones.service.IConstanteService;
import co.gov.runt.rnrys.cargueinfo.validaciones.service.IValidacionesActaImportService;
import co.gov.runt.rnrys.cargueinfo.validaciones.utilities.Constantes;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import co.gov.runt.utilidades.utilities.ExpresionRegularUtilidad;
import java.text.MessageFormat;
import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Clase que implementa las funcionalidades de la interfaz IValidacionesDeclaImportService
 *
 * @since 1.0.0
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ValidacionesDeclaImportService implements IValidacionesDeclaImportService {

  private final DeclaracionImportacionRepository declaracionImportacionRepository;
  private final IValidacionesActaImportService validacionesActaImportService;
  private final RpServicioRepository rpServicioRepository;
  private final IMensajeService mensajeService;
  private final IConstanteService iConstanteService;
  private final IRegistroDeclaracionImportacionService iRegistroDeclaracionImportacionService;
  private final IValidacionesControlService iValidacionesControlService;

  @Override
  public void validacionesDeclaracionImport(
      VehiculoDTO vehiculoDTO,
      String nit,
      Long idAutoridad,
      Long idEmpresa,
      String idUsuario,
      String nombreArchivo)
      throws ErrorGeneralException {
    RaDeclimportEntity declaracionImportEntity =
        declaracionImportacionRepository
            .findByDeclimpor(vehiculoDTO.getNumeroAceptacion())
            .orElse(null);

    // 14. El sistema identifica que la declaración o número de aceptación NO es manual o no
    // contiene el carácter” M” en la posición indicada.
    if (ExpresionRegularUtilidad.validarExpresion(
        vehiculoDTO.getNumeroAceptacion(), Constantes.PATTERN_ACTA_IMPORTACION_MANUAL)) {
      validarDeclaracionManual(vehiculoDTO, declaracionImportEntity, nit, nombreArchivo);
      log.info("Es manual");
    } else {
      validarDeclaracionNoManual(
          declaracionImportEntity, vehiculoDTO, nit, idAutoridad, idEmpresa, nombreArchivo);
    }
  }

  /**
   * Método que valida la declaracion de importación No manual.
   *
   * @param declaracionImportEntity Entidad de la declaración de importación.
   * @param vehiculoDTO DTO con la informacion para el cargue.
   * @param nit Numero de identificación del ensamblador, importador o fabricante.
   * @param idAutoridad Identificador de la autoridad de tránsito.
   * @param idEmpresa Identificador de la empresa.
   * @param nombreArchivo Nombre del archivo.
   * @throws ErrorGeneralException error general cuando no cumple con ninguna condición evaluada.
   */
  private void validarDeclaracionNoManual(
      RaDeclimportEntity declaracionImportEntity,
      VehiculoDTO vehiculoDTO,
      String nit,
      Long idAutoridad,
      Long idEmpresa,
      String nombreArchivo)
      throws ErrorGeneralException {
    // 15. El sistema valida que exista una declaración de importación con el número de
    // declaración del detalle del archivo.
    if (declaracionImportEntity != null
        && !declaracionImportEntity
            .getTipfuedec()
            .equals(TipoFuenteDeclaracionEnum.MANUAL.getNombre())) {

      validarExistenciaDeclaracion(
          declaracionImportEntity, vehiculoDTO, nit, nombreArchivo, idEmpresa);

    } else {
      // 5.22 Número de declaración de importación no está registrada en el sistema
      // 5.22.1	El sistema identifica si el parámetro de validación de declaración de importación
      // ante la DIAN <<VALIDACION_WS_DIAN>> está en SI.
      String constanteValidaWsDian =
          iConstanteService.obtenerConstantePorGrupoNombre(
              ConstanteGrupoEnum.CARGUE_INFORMACION, ConstanteNombreEnum.VALIDACION_WS_DIAN_RNRS);

      if (constanteValidaWsDian != null
          && !ValorConstanteWSDIANEnum.SI.getValor().equals(constanteValidaWsDian)) {

        // 5.30 Parámetro de validación de declaración de importación ante la DIAN
        // <<VALIDACION_WS_DIAN>> está en NO
        validarConstanteDianEnNo(nit, vehiculoDTO, nombreArchivo);
      }

      DeclaracionImportacionResponse response;

      // 5.22.2	El sistema ejecuta el caso de uso CU6412-Consultar de declaración de importación
      // en DIAN enviando el tipo de registro.
      response =
          validacionesActaImportService.validarDeclaracionImportacion(
              vehiculoDTO, vehiculoDTO.getOrigenVehiculo(), idAutoridad, idEmpresa, nombreArchivo);
      validarRegistroManualDeclaracion(declaracionImportEntity, vehiculoDTO, nit, nombreArchivo);

      if (response != null) {
        // 5.22.3	El sistema identifica que la consulta de la DIAN fue exitosa y si existe la
        // declaración de importación
        if (RespuestaEstadoEnum.esNE((response.getCodigoMensaje()))) {
          // 5.23
          String complemento =
              MessageFormat.format(
                  mensajeService.obtenerMensaje(MensajesErrorEnum.COMPLEMENTO_MENSAJE).getValor(),
                  vehiculoDTO.getSecuencia(),
                  nombreArchivo);
          throw new ErrorGeneralException(RespuestaEstadoEnum.NE.getId() + complemento);
        } else if (RespuestaEstadoEnum.DIAN.getId().equals(response.getCodigoMensaje())
            || RespuestaEstadoEnum.OK.getId().equals(response.getCodigoMensaje())) {
          // Registrar declaracion
          validarRespuestaDianExitosa(response, nit, vehiculoDTO, nombreArchivo);
          registrarDeclaracion(response);
        }
      }
    }
  }

  private void validarRegistroManualDeclaracion(
      RaDeclimportEntity declaracionImportEntity,
      VehiculoDTO vehiculoDTO,
      String nit,
      String nombreArchivo)
      throws ErrorGeneralException {
    if (declaracionImportEntity != null
        && declaracionImportEntity
            .getTipfuedec()
            .equals(TipoFuenteDeclaracionEnum.MANUAL.getNombre()))
      validarImportadorEntidad(declaracionImportEntity, vehiculoDTO, nit, nombreArchivo);
  }

  private void registrarDeclaracion(DeclaracionImportacionResponse declaracionImportacionResponse) {
    RegistroRequest registroRequest = new RegistroRequest();
    DetalleCargueVehiculoRequest detalleCargueVehiculoRequest = new DetalleCargueVehiculoRequest();
    detalleCargueVehiculoRequest.setNumeroLevante(
        declaracionImportacionResponse.getObject().getNroLevante());
    detalleCargueVehiculoRequest.setFechaLevante(
        declaracionImportacionResponse.getObject().getFechaLevante());
    detalleCargueVehiculoRequest.setFechaAceptacion(
        declaracionImportacionResponse.getObject().getFechaDeclaracion());
    detalleCargueVehiculoRequest.setNumeroAceptacion(
        declaracionImportacionResponse.getObject().getNroDeclaracion());
    detalleCargueVehiculoRequest.setNumDocumentoImportador(
        declaracionImportacionResponse.getObject().getNroDocumentoImportador());
    detalleCargueVehiculoRequest.setTipoDocumentoImportador(
        declaracionImportacionResponse.getObject().getTipoDocumentoImportador());

    if (declaracionImportacionResponse.getObject().isWebservice())
      registroRequest.setTipoFuente(TipoFuenteDeclaracionEnum.WEBSERVICE.getNombre());
    else registroRequest.setTipoFuente(TipoFuenteDeclaracionEnum.CARGUE.getNombre());

    registroRequest.setDetalleCargueVehiculoRequest(detalleCargueVehiculoRequest);
    iRegistroDeclaracionImportacionService.registroDeclImportacion(
        registroRequest, new AutomotorEntity());
  }

  @Override
  public void validarExistenciaDeclaracion(
      RaDeclimportEntity declaracionImportEntity,
      VehiculoDTO vehiculoDTO,
      String nit,
      String nombreArchivo,
      Long idEmpresa)
      throws ErrorGeneralException {
    // 16. El sistema identifica que la declaración de importación fue ingresada por el consumo
    // del web Service.
    if (declaracionImportEntity
        .getTipfuedec()
        .equals(TipoFuenteDeclaracionEnum.WEBSERVICE.getNombre())) {
      validarImportadorEntidad(declaracionImportEntity, vehiculoDTO, nit, nombreArchivo);
    }
  }

  private void validarImportadorEntidad(
      RaDeclimportEntity declaracionImportEntity,
      VehiculoDTO vehiculoDTO,
      String nit,
      String nombreArchivo)
      throws ErrorGeneralException {
    if (!TipoDocEnum.TIPO_DOC_NIT.getId().equals(declaracionImportEntity.getTipoIdent())
        || !nit.equals(declaracionImportEntity.getNumeIdent())) {

      throw new ErrorGeneralException(
          MessageFormat.format(
              mensajeService
                  .obtenerMensaje(MensajesErrorEnum.ERROR_NO_COINCIDE_INFORMACION_IMPORTADOR)
                  .getValor(),
              vehiculoDTO.getSecuencia(),
              nombreArchivo));
    }
    iValidacionesControlService.validarNit(nit, nombreArchivo);
  }

  /**
   * Método que valida la respuesta exitosa que genera el servicio Dian .
   *
   * @param vehiculoDTO DTO con la informacion para el cargue.
   * @param nit Numero de identificación del ensamblador, importador o fabricante.
   * @param response Datos de respuesta del servicio Dian.
   * @param nombreArchivo Nombre del archivo.
   * @throws ErrorGeneralException error general cuando no cumple con ninguna condición evaluada.
   */
  private void validarRespuestaDianExitosa(
      DeclaracionImportacionResponse response,
      String nit,
      VehiculoDTO vehiculoDTO,
      String nombreArchivo)
      throws ErrorGeneralException {

    String complemento =
        MessageFormat.format(
            mensajeService.obtenerMensaje(MensajesErrorEnum.COMPLEMENTO_MENSAJE).getValor(),
            vehiculoDTO.getSecuencia(),
            nombreArchivo);
    // 5.22.4	El sistema identifica que la consulta de la DIAN devuelve datos para la fecha
    // y número de levante
    if (response.getObject().getNroLevante().isEmpty()
        || response.getObject().getFechaLevante().isEmpty()) {
      // 5.39 El WS de la DIAN no retorna fecha o número de levante
      // Si en el paso 4 del flujo alterno 5.22, el sistema identifica el WS de la DIAN no
      // retorna
      // fecha o número de levante, se realizan las siguientes acciones:
      // 5.39.1.El sistema no carga la información y deja un registro (Log) con la causa de
      // rechazo, la cual se parametrizará de acuerdo con la respuesta entregada por el
      // servicio
      // de la DIAN.
      throw new ErrorGeneralException(
          MessageFormat.format(
              mensajeService.obtenerMensaje(MensajesErrorEnum.MENSAJES_DIAN).getValor(),
              Mensaje.DIAN_NO_RETORNA_INFORMACION_LEVANTE.getMsg(),
              complemento));
      // 5.39.2.El sistema retorna al paso 26 del flujo básico de eventos.
    }
    // 5.22.5	El sistema guarda la respuesta de la DIAN localmente con la información del
    // detalle de vehículo para consultas posteriores.

    // 5.22.6.	Si el usuario autenticado pertenece a una PNJ con tipo de prestador de
    // servicio importador, ensamblador,
    // el sistema valida que el tipo y número de documento de la PNJ a la que pertenece el
    // usuario autenticado sea igual
    // al tipo y número de documento de la declaración de importación consultada por el WS
    // de la DIAN
    validarUsuarioPertenecePNJ(nit, response, vehiculoDTO, nombreArchivo);
  }

  /**
   * Método que valida cuando la constante de la Dian tiene un valor de No.
   *
   * @param vehiculoDTO DTO con la informacion para el cargue.
   * @param nit Numero de identificación del ensamblador, importador o fabricante.
   * @param nombreArchivo Nombre del archivo.
   * @throws ErrorGeneralException error general cuando no cumple con ninguna condición evaluada.
   */
  private void validarConstanteDianEnNo(String nit, VehiculoDTO vehiculoDTO, String nombreArchivo)
      throws ErrorGeneralException {
    // 5.30.1.	El sistema verifica que el usuario autenticado corresponde con un tipo de PNJ
    // ensamblador o importador.
    // 5.30.2  El sistema verifica que la PNJ con el tipo y número de documento de importador se
    // encuentre en estado ACTIVO y HABILITADA
    Optional<RpServicioEntity> ensamblador = rpServicioRepository.getImporEnsambladorByNumIden(nit);

    if (ensamblador.isEmpty()) {
      // 5.32 PNJ con el tipo y número de documento de importador NO se encuentra en estado
      // ACTIVO y HABILITADA
      throw new ErrorGeneralException(
          MessageFormat.format(
              mensajeService
                  .obtenerMensaje(MensajesErrorEnum.ERROR_DECLAIMPORT_VALIDACION_PNJ_NO_REG)
                  .getValor(),
              nit,
              vehiculoDTO.getSecuencia(),
              nombreArchivo));
    }
    vehiculoDTO.setInsertDeclaracionImport(Boolean.TRUE);
  }

  /**
   * Método que valida que el usuario pertencezca a una PNJ .
   *
   * @param vehiculoDTO DTO con la informacion para el cargue.
   * @param nit Numero de identificación del ensamblador, importador o fabricante.
   * @param nombreArchivo Nombre del archivo.
   * @param response Datos de respuesta del servicio Dian.
   * @throws ErrorGeneralException error general cuando no cumple con ninguna condición evaluada.
   */
  private void validarUsuarioPertenecePNJ(
      String nit,
      DeclaracionImportacionResponse response,
      VehiculoDTO vehiculoDTO,
      String nombreArchivo)
      throws ErrorGeneralException {

    Optional<RpServicioEntity> ensamblador =
        rpServicioRepository.getImporByNumIdeAndTipoSer(
            nit, TipoServicioEnum.IMPORTADOR_ENSAMBLADOR.getId());

    if (ensamblador.isEmpty()) {
      // 5.28 El usuario pertenece a una autoridad de tránsito y la PNJ no es un importador
      // ocasional
      // Si en el paso 6 del flujo alternativo 5.22, el sistema identifica que el tipo y número de
      // documento recibido
      // no está registrado como PNJ o se encuentra registrado, pero no es un importador ocasional,
      // se ejecuta las siguientes acciones
      Optional<RpServicioEntity> servicioEntity =
          rpServicioRepository.getServicioDiferenteOcasionalByNumIden(nit);
      if (servicioEntity.isPresent()) {
        throw new ErrorGeneralException(
            MessageFormat.format(
                mensajeService
                    .obtenerMensaje(MensajesErrorEnum.ERROR_DECLAIMPORT_VALIDACION_IMPOCACIONAL)
                    .getValor(),
                TipoDocEnum.TIPO_DOC_NIT.getId(),
                nit,
                vehiculoDTO.getSecuencia(),
                nombreArchivo));
      }
    }
    if (!nit.equals(response.getObject().getNroDocumentoImportador())
        || !TipoDocEnum.TIPO_DOC_NIT
            .getId()
            .equals(response.getObject().getTipoDocumentoImportador())) {
      // 5.27 tipo y número de documento de la PNJ del usuario autenticado NO es igual al tipo y
      // número de documento de
      // la declaración de importación consultada por el WS de la DIAN

      throw new ErrorGeneralException(
          MessageFormat.format(
              mensajeService
                  .obtenerMensaje(MensajesErrorEnum.ERROR_DECLAIMPORT_VALIDACION_PNJ)
                  .getValor(),
              response.getObject().getNroDeclaracion()));
    }
  }

  /**
   * Método que valida la declaracion de importación manual.
   *
   * @param vehiculoDTO DTO con la informacion para el cargue.
   * @param declimportEntity Entidad de la declaración de importación.
   */
  private void validarDeclaracionManual(
      VehiculoDTO vehiculoDTO,
      RaDeclimportEntity declimportEntity,
      String nit,
      String nombreArchivo)
      throws ErrorGeneralException {
    validarRegistroManualDeclaracion(declimportEntity, vehiculoDTO, nit, nombreArchivo);

    if (!Objects.isNull(declimportEntity)
        && declimportEntity.getEstadoNombre().equals(EstadoDeclaracionEnum.ACTIVO.getId())) {
      vehiculoDTO.setDeclimportEntity(declimportEntity);
      if (!Objects.isNull(declimportEntity.getTipregdec())) {
        vehiculoDTO.setDeclaracionManual(Boolean.TRUE);
      }
    } else {
      vehiculoDTO.setDeclaracionManualNE(Boolean.TRUE);
    }
  }
}
