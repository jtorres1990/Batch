package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IRegistrosComunService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IRegistrosModificacionService;
import co.gov.runt.rnrys.cargueinfo.core.registros.dto.RegistroRequest;
import co.gov.runt.rnrys.cargueinfo.core.registros.service.IRegistroCargueDetalleRnaService;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Clase que implementa las funcionalidades de la interfaz IRegistrosModificacionService
 *
 * @since 1.0.0
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RegistrosModificacionService implements IRegistrosModificacionService {

  private final IRegistroCargueDetalleRnaService registroCargueDetalleVehiculo;
  private final IRegistrosComunService registrosComunService;

  @Override
  public void modificarCargueCreacion(
      VehiculoDTO vehiculoDTO,
      String nit,
      String idUsuario,
      Long idAutoridad,
      String ipUsuario,
      Long idSolicitud)
      throws ErrorGeneralException {
    RegistroRequest registroRequest =
        registrosComunService.crearRegistroRequest(
            vehiculoDTO, nit, idUsuario, idAutoridad, ipUsuario, idSolicitud);
    registroRequest.setAutomotor(vehiculoDTO.getAutomotorEntity());
    registroCargueDetalleVehiculo.registroCargueDetalleVehiculo(registroRequest);
  }
}
