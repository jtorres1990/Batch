package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/** Enum que representa los Tipos de documento */
@Getter
@RequiredArgsConstructor
public enum TipoDocEnum {

  /** Tipo de documento nit */
  TIPO_DOC_NIT("N");

  private final String id;
}
