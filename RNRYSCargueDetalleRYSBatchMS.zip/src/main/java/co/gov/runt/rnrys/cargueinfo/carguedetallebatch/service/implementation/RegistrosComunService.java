package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums.TipoDocEnum;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IRegistrosComunService;
import co.gov.runt.rnrys.cargueinfo.core.consultas.enums.TipoFuenteDeclaracionEnum;
import co.gov.runt.rnrys.cargueinfo.core.registros.dto.RegistroRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Clase que implementa las funcionalidades de la interfaz IRegistrosComunService
 *
 * @since 1.0.0
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RegistrosComunService implements IRegistrosComunService {

  @Override
  public RegistroRequest crearRegistroRequest(
      VehiculoDTO vehiculoDTO,
      String nit,
      String idUsuario,
      Long idAutoridad,
      String ipUsuario,
      Long idSolicitud) {
    vehiculoDTO.setNumDocumentoImportador(nit);
    vehiculoDTO.setTipoDocumentoImportador(TipoDocEnum.TIPO_DOC_NIT.getId());
    RegistroRequest registroRequest = new RegistroRequest();
    registroRequest.setDetalleCargueVehiculoRequest(vehiculoDTO);
    registroRequest.setTipoFuente(TipoFuenteDeclaracionEnum.CARGUE.getNombre());
    registroRequest.setDeclaracionManual(vehiculoDTO.isDeclaracionManual());
    registroRequest.setDeclaracionManualNE(vehiculoDTO.isDeclaracionManualNE());
    registroRequest.setIdUsuario(idUsuario);
    registroRequest.setIdAutoridad(idAutoridad);
    registroRequest.setInsertDeclaracionImpor(vehiculoDTO.isInsertDeclaracionImport());
    registroRequest.setIpUsuario(ipUsuario);
    registroRequest.setTipoCargue(vehiculoDTO.getTipoCargue());
    registroRequest.setIdSolicitud(idSolicitud);
    return registroRequest;
  }
}
