package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.utilities;

import static co.gov.runt.rnrys.cargueinfo.carguedetallebatch.utilities.Constantes.*;

import co.gov.runt.manejadorcolas.service.IKafkaService;
import co.gov.runt.rna.rnacarguearchivosapiclient.jpa.entity.SolicitudCargueEntity;
import co.gov.runt.rnrys.cargueinfo.validaciones.utilities.Util;
import co.gov.runt.utilidades.model.MensajeInDto;
import co.gov.runt.utilidades.model.correoModel.EnvioCorreoPlantillaIn;
import co.gov.runt.utilidades.model.enums.TipoProveedorEnum;
import co.gov.runt.utilidades.services.CorreoService;
import com.fasterxml.jackson.core.JsonProcessingException;
import java.text.SimpleDateFormat;
import java.util.*;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Clase donde se definen las funciones del proceso Batch.
 *
 * @since 1.0.0
 */
@Component
@AllArgsConstructor
@Slf4j
public class FuncionesBatch {

  /** The constant TITULO. */
  public static final String TITULO = "titulo";

  /** The constant CUERPO. */
  public static final String CUERPO = "cuerpo";

  /** The constant FECHA_TITULO. */
  public static final String FECHA_TITULO = "fecha_titulo";

  private final IKafkaService kafkaService;

  /**
   * Metodo que nos retorna la ruta del archivo
   *
   * @param solicitud entidad de la solicitud
   * @return ruta del archivo {@link String}
   */
  public String darRutaArchivo(SolicitudCargueEntity solicitud) {
    String ruta = solicitud.getRutaArchivo() + "/" + solicitud.getNombreArchivo();
    ruta = ruta.replaceAll("//+", "/");
    return ruta;
  }

  /**
   * Enviar correo.
   *
   * @param correos the correos
   * @param idSolicitud the id solicitud
   * @param fechaCrague the fecha crague
   * @param usuario the usuario
   * @throws JsonProcessingException the json processing exception
   */
  public void enviarCorreo(
      List<String> correos, String idSolicitud, String fechaCrague, String usuario)
      throws JsonProcessingException {
    Map<String, Object> parametro = new HashMap<>();
    parametro.put(TITULO, Constantes.TITULO);
    parametro.put(
        CUERPO, Util.formatearMensaje(Constantes.CUERPO, usuario, idSolicitud, fechaCrague));
    EnvioCorreoPlantillaIn plantillaIn = new EnvioCorreoPlantillaIn();
    plantillaIn.setAsunto(ASUNTO);
    parametro.put(FECHA_TITULO, new SimpleDateFormat("dd/MM/yyyy").format(new Date()));
    plantillaIn.setPara(correos);
    plantillaIn.setNombrePlantilla(PLANTILLA_GENERICA_RUNT_2); // No Cambiar esta plantilla
    plantillaIn.setParametros(parametro);
    plantillaIn.setTipoCorreo(TIPO_CORREO);

    MensajeInDto mensajeDTO =
        CorreoService.obtenerDatosCorreo(TipoProveedorEnum.SENDGRID, plantillaIn);
    kafkaService.enviarMensaje(mensajeDTO);
  }
}
