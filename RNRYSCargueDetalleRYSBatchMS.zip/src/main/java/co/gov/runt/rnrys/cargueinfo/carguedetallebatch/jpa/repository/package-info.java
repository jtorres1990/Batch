/**
 * Repositorios utilizados para gestionar información de BD
 *
 * @since 1.0.0
 */
package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.jpa.repository;
