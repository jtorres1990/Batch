package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.controller;

import co.gov.runt.rnf.procesadorsolicitudes.annotations.PrintLogs;
import co.gov.runt.rnf.procesadorsolicitudes.service.implementation.ThreadService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IBatchCargueDetalleService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.utilities.Constantes;
import co.gov.runt.utilidades.model.Mensaje;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Clase donde se implementan servicios REST para el proceso batch del cargue de detalle de
 * vehículo.
 *
 * @since 1.0.0
 */
@RestController
@Slf4j
@RequestMapping(Constantes.PATH_BATCH)
@AllArgsConstructor
public class BatchController {

  private final ThreadService threadService;

  private final IBatchCargueDetalleService batchCargueDetalleService;

  /**
   * Método para procesar los cargues de detalle de vehículo.
   *
   * @return mensaje de ejecución del metodo
   */
  @PrintLogs
  @PostMapping(Constantes.PATH_EJECUTAR_TAREA)
  public Mensaje batchCargueArchivo() {
    threadService.executeOnThread(batchCargueDetalleService::procesarCargueDetalle);
    return new Mensaje(
        "200",
        "Se inicializo el procesamiento de cargues de detalle de vehículo de forma exitosa",
        null,
        List.of());
  }
}
