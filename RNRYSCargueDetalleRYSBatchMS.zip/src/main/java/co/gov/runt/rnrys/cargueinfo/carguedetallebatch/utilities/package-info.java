/**
 * Paquete que agrupa todas las clases de utilidades para el funcionamiento de la aplicación
 *
 * @since 1.0.0
 */
package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.utilities;
