package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums.MensajesErrorEnum;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IMensajeService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IValidacionesComunesService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IValidacionesCreacionService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IValidacionesDeclaImportService;
import co.gov.runt.rnrys.cargueinfo.core.consultas.enums.OrigenRegistroEnum;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.AutomotorEntity;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.RpServicioEntity;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.repository.RpServicioRepository;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import java.text.MessageFormat;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Clase que implementa las funcionalidades de la interfaz IValidacionesCreacionService
 *
 * @since 1.0.0
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ValidacionesCreacionService implements IValidacionesCreacionService {

  private final IValidacionesDeclaImportService validacionesDeclaImportService;
  private final IValidacionesComunesService validacionesComunesService;
  private final RpServicioRepository rpServicioRepository;
  private final IMensajeService iMensajeService;

  @Override
  public void validarCreacion(
      VehiculoDTO vehiculoDTO,
      String nit,
      String nombreArchivo,
      Long idAutoridad,
      Long idEmpresa,
      String idUsuario)
      throws ErrorGeneralException {
    // 18.	El sistema verifica que no exista un detalle de un remolque o semiremolque ya registrado
    // con el mismo
    // número de serie de fabricación, VIN y marca ingresados.

    List<AutomotorEntity> automotorEntityList =
        validacionesComunesService.obtenerAutomotorPorLineaMarcaGuarismos(vehiculoDTO);

    if (!Objects.isNull(automotorEntityList) && !automotorEntityList.isEmpty()) {
      throw new ErrorGeneralException("Existe un registro con los datos del vehiculo ingresados");
    }
    // 13. El sistema identifica que el origen del vehículo es diferente de Fabricación Nacional. si
    // el origen del vehículo es Fabricación Nacional continúa en el paso 16 del presente flujo
    if (!OrigenRegistroEnum.esFabricacionNacional(vehiculoDTO.getOrigenVehiculo())) {
      validacionesDeclaImportService.validacionesDeclaracionImport(
          vehiculoDTO, nit, idAutoridad, idEmpresa, idUsuario, nombreArchivo);
    } else {
      Optional<RpServicioEntity> servicioEntity =
          rpServicioRepository.getImporEnsamFabByNumIden(nit);
      if (servicioEntity.isEmpty()) {

        throw new ErrorGeneralException(
            MessageFormat.format(
                iMensajeService
                    .obtenerMensaje(MensajesErrorEnum.ERROR_ACTOR_NO_PERTENECE_ENTIDAD)
                    .getValor(),
                vehiculoDTO.getSecuencia(),
                nombreArchivo));
      }
    }
  }
}
