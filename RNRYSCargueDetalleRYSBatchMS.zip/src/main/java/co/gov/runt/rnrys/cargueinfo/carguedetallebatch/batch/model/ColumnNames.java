package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.batch.model;

/** Clase encargada de las nombres de las columnas por orden de captura del batch */
public final class ColumnNames {

  /** Valor de nombre de columna por orden de captura del batch */
  private ColumnNames() {
    throw new UnsupportedOperationException("No se pueden inicializar clase de utilidad");
  }

  /** columna para secuencia */
  public static final String SECUENCIA = "secuencia";
  /** columna para tipoCargue */
  public static final String TIPO_CARGUE = "tipoCargue";
  /** columna para tipoRegistro */
  public static final String TIPO_REGISTRO = "tipoRegistro";

  /** columna para numeroDeclaracion */
  public static final String NUMERO_CERTIFICADO = "numeroCertificado";

  /** columna para numeroDeclaracion */
  public static final String NUMERO_SERIE_FABRICACION = "numeroSerieFabricacion";

  /** columna para vin */
  public static final String VIN = "vin";

  /** columna para marca */
  public static final String MARCA = "marca";

  /** columna para linea */
  public static final String LINEA = "linea";

  /** columna para claseVehiculo */
  public static final String CLASE_VEHICULO = "claseVehiculo";

  /** columna para modelo */
  public static final String MODELO = "modelo";
  /** columna para numeroFth */
  public static final String NUMERO_FTH = "numeroFth";

  /** columna para numeroEjes */
  public static final String NUMERO_EJES = "numeroEjes";

  /** columna para numeroEjes */
  public static final String ALTO = "alto";

  /** columna para numeroEjes */
  public static final String LARGO = "largo";

  /** columna para numeroEjes */
  public static final String ANCHO = "ancho";

  /** columna para numeroEjes */
  public static final String PESO_TOTAL = "pesoTotal";

  /** columna para numeroEjes */
  public static final String CARGA_UTIL = "cargaUtil";

  /** columna para numeroEjes */
  public static final String NUMERO_LLANTAS = "numeroLlantas";

  /** columna para numeroEjes */
  public static final String TIPO_CARROCERIA = "tipoCarroceria";
  /** columna para numeroEjes */
  public static final String CONDICION_MOVILIDAD = "condicionMovilidad";

  /** columna para numeroEjes */
  public static final String NUMERO_ACEPTACION = "numeroAceptacion";
  /** columna para numeroEjes */
  public static final String FECHA_ACEPTACION = "fechaAceptacion";
  /** columna para numeroEjes */
  public static final String NUMERO_LEVANTE = "numeroLevante";
  /** columna para numeroEjes */
  public static final String FECHA_LEVANTE = "fechaLevante";
  /** columna para numeroEjes */
  public static final String FECHA_CERTIFICACION = "fechaCertificacion";
  /** columna para numeroEjes */
  public static final String ORIGEN_VEHICULO = "origenVehiculo";

  // crear un metodo publico get
  private static final int[] FIELDS = {
    0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25
  };

  /**
   * Get fields int [ ].
   *
   * @return the int [ ]
   */
  public static int[] getFields() {
    return FIELDS;
  }

  /**
   * Get column names string [ ].
   *
   * @return the string [ ]
   */
  public static String[] getColumnNames() {
    return new String[] {
      SECUENCIA,
      TIPO_CARGUE,
      TIPO_REGISTRO,
      NUMERO_CERTIFICADO,
      NUMERO_SERIE_FABRICACION,
      VIN,
      MARCA,
      LINEA,
      CLASE_VEHICULO,
      MODELO,
      NUMERO_FTH,
      NUMERO_EJES,
      ALTO,
      LARGO,
      ANCHO,
      PESO_TOTAL,
      CARGA_UTIL,
      NUMERO_LLANTAS,
      TIPO_CARROCERIA,
      CONDICION_MOVILIDAD,
      NUMERO_ACEPTACION,
      FECHA_ACEPTACION,
      NUMERO_LEVANTE,
      FECHA_LEVANTE,
      FECHA_CERTIFICACION,
      ORIGEN_VEHICULO
    };
  }
}
