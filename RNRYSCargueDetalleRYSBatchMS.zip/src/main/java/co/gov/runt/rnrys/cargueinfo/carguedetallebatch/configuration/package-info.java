/**
 * Paquete que agrupa todas las configuraciones necesarias del proyecto
 *
 * @since 1.0.0
 */
package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.configuration;
