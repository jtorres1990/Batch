package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import static co.gov.runt.rnrys.cargueinfo.carguedetallebatch.utilities.Constantes.CORREOS;

import co.gov.runt.rna.rnacarguearchivosapiclient.jpa.entity.SolicitudCargueEntity;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.batch.listener.JobListener;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.batch.processor.EstructuraVehiculoProcessor;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.batch.processor.VehiculoProcessor;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.batch.reader.EstructuraVehiculoReader;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.batch.reader.VehiculoItemReader;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.batch.writer.EstructuraVehiculoWriter;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.batch.writer.VehiculoWriter;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums.TipoArchivoEnum;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IBatchService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.utilities.Constantes;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.utilities.FuncionesBatch;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.utilities.SimpleJobLauncherRuntCargue;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.utilities.ThreadServiceCargue;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.ArchivosEntity;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.PersonaEntity;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.repository.ArchivosRepository;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.repository.PersonaRepository;
import co.gov.runt.utilidades.exception.ElementoNoEncontradoException;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import co.gov.runt.utilidades.utilities.InformacionUsuario;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Stream;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.*;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
 * Clase que implementa las funcionalidades de la interfaz IBatchService
 *
 * @since 1.0.0
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class BatchService implements IBatchService {

  private final StepBuilderFactory stepBuilderFactory;
  private final VehiculoItemReader vehiculoItemReader;
  private final VehiculoWriter vehiculoWriter;
  private final VehiculoProcessor vehiculoProcessor;
  private final JobBuilderFactory jobBuilderFactory;
  private final FuncionesBatch funcionesBatch;
  private final PersonaRepository personaRepository;
  private final ArchivosRepository archivoRepository;
  private final EstructuraVehiculoReader estructuraVehiculoReader;
  private final EstructuraVehiculoProcessor estructuraVehiculoProcessor;
  private final EstructuraVehiculoWriter estructuraVehiculoWriter;
  private final ThreadServiceCargue threadService;
  private final TaskExecutor taskExecutor;
  private final JobRepository jobRepository;
  private final JobListener jobListener;
  private final BatchJobProcesorService batchJobProcesorService;
  private final InformacionUsuario informacionUsuario;

  @Override
  public void ejecutar(SolicitudCargueEntity solicitud) {

    log.info("Ejecutar cargue");
    Long idSolicitud = solicitud.getSolicitud();

    try {
      batchJobProcesorService.cambiarEstadoInicial(solicitud);
      this.ejecutarTarea(solicitud);

    } catch (ElementoNoEncontradoException e) {
      log.error("Error al ejecutar la solicitud {} : Error: {}", idSolicitud, e.getMessage());
    }
  }

  /**
   * Método para ejecutar una tarea de carga de datos, como parte de un sistema de procesamiento por
   * lotes.
   *
   * @param solicitud Entidad de Solicitud.
   */
  private void ejecutarTarea(SolicitudCargueEntity solicitud) {
    try {
      String rutaArchivo = this.funcionesBatch.darRutaArchivo(solicitud);

      Date inicio = new Date();
      String complemento = solicitud.getSolicitud() + "_" + inicio.getTime();

      String jobsId = "cargue_" + complemento;
      String stepId = "step_" + complemento;
      String stepIdEstructura = "stepE_" + complemento;

      Path filePath = Path.of(rutaArchivo);

      String primeraLinea = obtenerPrimeraLinea(filePath);
      List<Character> caracteresSacados = new ArrayList<>();
      long cantidadLineasSinEncabezado =
          obtenerCantidadLineasSinEncabezado(filePath, caracteresSacados);
      List<String> repetidos = caracteresSacados.stream().map(String::valueOf).toList();

      if (primeraLinea != null) {

        Map<String, String> map = obtenerMap(primeraLinea);
        String parametersAsString = String.join(",", informacionUsuario.getCorreos());
        PersonaEntity empresa = obtenerEmpresa(solicitud.getEmpresa());
        JobParameters jobParameters =
            new JobParametersBuilder()
                .addLong(Constantes.SOLICITUD_ID, solicitud.getSolicitud())
                .addString(Constantes.NOMBREARCHIVO, solicitud.getNombreArchivo())
                .addString(Constantes.RUTA_ARCHIVO, rutaArchivo)
                .addString(Constantes.TOTAL_REGISTROS, map.get(Constantes.TOTAL_REGISTROS))
                .addString(Constantes.FECHA_CORTE, map.get(Constantes.FECHA_CORTE))
                .addLong(Constantes.CONTADOR_FILAS, cantidadLineasSinEncabezado)
                .addString(Constantes.NIT, map.get(Constantes.NIT))
                .addLong(Constantes.IDAUTORIDAD, solicitud.getEmpresa())
                .addLong(Constantes.IDEMPRESA, empresa.getIdPersona())
                .addString(Constantes.IDUSUARIO, solicitud.getUsuario())
                .addString(Constantes.IPUSUARIO, solicitud.getIpTranzaccion())
                .addString(Constantes.NOMBRE_USUARIO, informacionUsuario.getNombreCompleto())
                .addString(CORREOS, parametersAsString)
                .addString(
                    Constantes.LISTA_REPETIDOS,
                    StringUtils.collectionToCommaDelimitedString(repetidos))
                .toJobParameters();
        Job job = getJob(jobsId, stepId, stepIdEstructura);
        simpleJobLauncher().run(job, jobParameters);
      }

    } catch (JobExecutionAlreadyRunningException
        | JobRestartException
        | JobInstanceAlreadyCompleteException
        | ErrorGeneralException
        | JobParametersInvalidException ex) {
      log.error("Error ejecutando cargue detalle vehiculos", ex);
    }
  }

  /**
   * Método que tiene como objetivo obtener la cantidad de lineas sin encabezado.
   *
   * @param filePath Ruta del archivo.
   * @return La cantidad de lineas.
   */
  private long obtenerCantidadLineasSinEncabezado(
      Path filePath, List<Character> caracteresSacados) {

    try (Stream<String> lines = Files.lines(filePath)) {
      List<String> campos = lines.filter(line -> !line.trim().isEmpty()).skip(1).toList();
      encontrarRepetidos(campos, caracteresSacados);

      return campos.size();
    } catch (IOException e) {
      return 0;
    }
  }

  public static void encontrarRepetidos(List<String> lista, List<Character> caracteresSacados) {
    Set<String> unicos = new HashSet<>();

    lista.forEach(
        str -> {
          char primerCaracter = str.charAt(0);
          String resto = str.substring(1);

          if (!unicos.add(resto)) {
            caracteresSacados.add(primerCaracter);
          }
        });
  }

  /**
   * Método que tiene como objetivo leer el contenido del archivo especificado por la ruta filePath.
   *
   * @param filePath Ruta del archivo.
   * @return La primera línea como una cadena de caracteres.
   */
  private String obtenerPrimeraLinea(Path filePath) {
    try (Stream<String> stream = Files.lines(filePath)) {
      return stream.findFirst().orElse(null);
    } catch (IOException e) {
      return null;
    }
  }

  /**
   * Método para obtener la empresa mediante el nit.
   *
   * @param idAutoridad id Autoridad
   * @return PersonaEntity Entidad de persona.
   */
  private PersonaEntity obtenerEmpresa(Long idAutoridad) throws ErrorGeneralException {
    Optional<PersonaEntity> empresa = personaRepository.getPersonaAutoridad(idAutoridad);
    if (empresa.isEmpty()) {
      throw new ErrorGeneralException("No se encontro información de la empresa");
    }
    return empresa.get();
  }

  /**
   * Método para procesar la primera linea obteniendo en un hasMap los datos Total de registros,
   * fecha de corte y nit.
   *
   * @param primeraLinea Primera linea.
   * @return hashMap con la información de la primera linea.
   */
  private Map<String, String> obtenerMap(String primeraLinea) {

    String totalRegistros;
    String fechaCorte;
    String nit;
    HashMap<String, String> hashMap = new HashMap<>();

    log.info("Primera línea del archivo: {}", primeraLinea);
    String[] parametros = primeraLinea.split("\\|");
    totalRegistros = parametros[0];
    fechaCorte = parametros[1];
    nit = parametros[2];

    hashMap.put(Constantes.TOTAL_REGISTROS, totalRegistros);
    hashMap.put(Constantes.FECHA_CORTE, fechaCorte);
    hashMap.put(Constantes.NIT, nit);
    return hashMap;
  }

  /**
   * Método que construye y devuelve un objeto Job.
   *
   * @param cargueId Identificador se utiliza para nombrar el trabajo.
   * @param stepIdEstructura Identificador del primer paso.
   * @param stepId Identificador del segundo paso.
   * @return Job.
   */
  private Job getJob(String cargueId, String stepId, String stepIdEstructura) {
    return jobBuilderFactory
        .get(cargueId)
        .incrementer(new RunIdIncrementer())
        .listener(this.jobListener)
        .flow(estructuraStep(stepIdEstructura))
        .next(getStep(stepId))
        .end()
        .build();
  }

  /**
   * Método que construye y devuelve un objeto Step relacionado a la estructura.
   *
   * @param stepId Identificador del segundo paso.
   * @return Step.
   */
  private Step estructuraStep(String stepId) {
    ArchivosEntity archivo =
        archivoRepository.findArchivoByTipoArchivo(TipoArchivoEnum.DETALLE_VEHICULORYS.getId());
    return stepBuilderFactory
        .get(stepId)
        .<String, String>chunk(archivo.getChunk().intValue())
        .reader(estructuraVehiculoReader)
        .processor(estructuraVehiculoProcessor)
        .writer(estructuraVehiculoWriter)
        .build();
  }

  /**
   * Método que construye y devuelve un objeto Step.
   *
   * @param stepId Identificador del segundo paso.
   * @return Step.
   */
  private Step getStep(String stepId) {
    ArchivosEntity archivo =
        archivoRepository.findArchivoByTipoArchivo(TipoArchivoEnum.DETALLE_VEHICULORYS.getId());
    return stepBuilderFactory
        .get(stepId)
        .<VehiculoDTO, VehiculoDTO>chunk(archivo.getChunk().intValue())
        .reader(vehiculoItemReader)
        .processor(vehiculoProcessor)
        .writer(vehiculoWriter)
        .build();
  }

  @Override
  @SuppressWarnings({"squid:S6201", "squid:S6201"})
  public JobLauncher simpleJobLauncher() throws ErrorGeneralException {
    try {
      SimpleJobLauncherRuntCargue jl = new SimpleJobLauncherRuntCargue();
      jl.setJobRepository(jobRepository);
      jl.setTaskExecutor(taskExecutor);
      jl.setThreadService(threadService);
      jl.afterPropertiesSet();
      return jl;
    } catch (Exception ex) {
      throw new ErrorGeneralException("No se pudo inicializar el simpleJobLauncher");
    }
  }
}
