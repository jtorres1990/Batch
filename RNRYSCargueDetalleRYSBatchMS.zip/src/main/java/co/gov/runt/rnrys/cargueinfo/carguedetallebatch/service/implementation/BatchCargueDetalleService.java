package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import co.gov.runt.rna.rnacarguearchivosapiclient.jpa.entity.SolicitudCargueEntity;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums.TipoArchivoEnum;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.jpa.repository.SolicitudesCargueRepository;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IBatchCargueDetalleService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IBatchService;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

/**
 * Clase que implementa las funcionalidades de la interfaz IBatchCargueDetalleService
 *
 * @since 1.0.0
 */
@Slf4j
@Component
@RequiredArgsConstructor
@Service
public class BatchCargueDetalleService implements IBatchCargueDetalleService {

  private final IBatchService batchService;
  private final SolicitudesCargueRepository solicitudCargueRepository;

  @Override
  public void procesarCargueDetalle() {
    log.info("BatchCargueCargueService ::> procesarTarea()");

    List<SolicitudCargueEntity> solicitudes =
        solicitudCargueRepository.findSoliCargueByIdTipoArchivoAndEstado(
            Long.parseLong(TipoArchivoEnum.DETALLE_VEHICULORYS.getId()));
    log.info("Solicitudes a procesar => {}", solicitudes.size());
    for (SolicitudCargueEntity solicitud : solicitudes) {
      batchService.ejecutar(solicitud);
    }
  }
}
