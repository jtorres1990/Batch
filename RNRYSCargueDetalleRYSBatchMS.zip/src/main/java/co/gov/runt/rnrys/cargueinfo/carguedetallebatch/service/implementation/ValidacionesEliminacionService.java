package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.*;
import co.gov.runt.rnrys.cargueinfo.core.consultas.dto.FiltroAutomotorDTO;
import co.gov.runt.rnrys.cargueinfo.core.consultas.enums.EstadoVehiculoEnum;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.AutomotorEntity;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.repository.AutomotorRepository;
import co.gov.runt.rnrys.cargueinfo.validaciones.enums.Mensaje;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import java.text.MessageFormat;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Clase que implementa las funcionalidades de la interfaz IValidacionesEliminacionService
 *
 * @since 1.0.0
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ValidacionesEliminacionService implements IValidacionesEliminacionService {

  private final AutomotorRepository automotorRepository;

  @Override
  public void validarEliminacion(VehiculoDTO vehiculoDTO, String nombreArchivo)
      throws ErrorGeneralException {

    FiltroAutomotorDTO filtro = FiltroAutomotorDTO.builder().build();
    filtro.setNumeroVIN(vehiculoDTO.getVin());
    filtro.setIdMarca(Long.valueOf(vehiculoDTO.getMarca()));
    filtro.setNumeroSerie(vehiculoDTO.getNumeroSerieFabricacion());

    Optional<AutomotorEntity> automotor =
        automotorRepository.buscarAutomotorVinSerieMarca(
            vehiculoDTO.getVin(),
            vehiculoDTO.getNumeroSerieFabricacion(),
            Long.valueOf(vehiculoDTO.getMarca()));

    if (automotor.isPresent()) validarEstado(automotor.get());
    else
      throw new ErrorGeneralException(
          MessageFormat.format(
              Mensaje.ERROR_VEHICULO_NO_EXISTE_GUARISMOS.getMsg(),
              vehiculoDTO.getSecuencia(),
              nombreArchivo));

    vehiculoDTO.setAutomotorEntity(automotor.get());
  }

  private void validarEstado(AutomotorEntity automotor) throws ErrorGeneralException {
    if (automotor.getEstado().equals(EstadoVehiculoEnum.ACTIVO.name())) {
      throw new ErrorGeneralException(
          "No se pudo registrar la modificación porque el remolque a modificar ya tiene un trámite"
              + " de matrícula inicial aprobado");
    }
    if (automotor.getEstado().equals(EstadoVehiculoEnum.ELIMINADO.name())) {
      throw new ErrorGeneralException(
          "No se pudo registrar la modificación porque el remolque a modificar ya se encuentra en"
              + " estado eliminado");
    }
  }
}
