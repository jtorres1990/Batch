package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.configuration;

import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

/** Clase encargada de la ejecución de tareas y parametrización para los hilos del batch */
@Configuration
@Slf4j
@EnableBatchProcessing
public class BatchConfig {
  /**
   * Metodo encargado de la ejecución de tareas del batch
   *
   * @return retorna una instancia de la clase TaskExecutor
   */
  @Bean
  public TaskExecutor taskExecutor() {
    ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
    taskExecutor.setCorePoolSize(1);
    taskExecutor.setMaxPoolSize(1);
    taskExecutor.setQueueCapacity(1000);
    taskExecutor.setThreadNamePrefix("DetalleVehiRNA-");
    return taskExecutor;
  }
}
