package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.jpa.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;

/**
 * Entidad TipoArchivosEntity. RUNTPROD.CAR_TIPOARCHI
 *
 * @since 1.0.0
 */
@Getter
@Setter
@Entity
@Cacheable(false)
@Table(schema = "RUNTPROD", name = "CAR_TIPOARCHI")
public class TipoArchivosEntity implements Serializable {

  private static final long serialVersionUID = -2776917419177376377L;

  @Id
  @Column(name = "TIPOARCHI_ID")
  private Long id;

  @Column(name = "TIPOARCHI_NOMBRE")
  private String nombre;

  @Column(name = "TIPOARCHI_DESCRIPCI")
  private String descripcion;

  @Column(name = "TIPOARCHI_MASNOMARC")
  private String mascaraArchivo;

  @Column(name = "TIPOARCHI_VALICONTE")
  private Long validarContenido;

  @Column(name = "TIPOARCHI_VALINEGO")
  private Long validarNegocio;

  @Column(name = "TIPOARCHI_TIPCARTEM")
  private char tipoTablaCargueTemp;

  @Column(name = "TIPOARCHI_MASREGCON")
  private String claseConvierteFormato;

  @Column(name = "TIPOARCHI_CLAJAVCON")
  private String claseConvierteFormatoVali;

  @Column(name = "TIPOARCHI_NOTICORRE")
  private String notiCorre;

  @Column(name = "TIPOARCHI_FECINICAR")
  private Date fechaIniCar;

  @Column(name = "TIPOARCHI_INTTIEFTP")
  private Long intTieFtp;

  @Column(name = "TIPOARCHI_FECINIFTP")
  private Date fechaIniFtp;

  @Column(name = "TIPOARCHI_FIRMDIGIT")
  private String firmaDigital;

  @Column(name = "TIPOARCHI_EJECDEMAN")
  private String ejecDemanda;

  @Column(name = "TIPOARCHI_EXTENSION")
  private String extension;

  @Column(name = "TIPOARCHI_REGCONTRO")
  private String registroControl;

  @Column(name = "TIPOARCHI_SUBPATH")
  private String rutaSecAlmacenamiento;

  /** Indica si se debe validar la concurrencia de archivos cargados. Valores posibles S o N. */
  @Column(name = "TIPOARCHI_VALICONCU")
  private String validarConcurrencia;
}
