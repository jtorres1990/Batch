/**
 * Paquete que agrupa todos los objetos utilizados por la aplicación que modelan conceptos o
 * elementos del negocio
 *
 * @since 1.0.0
 */
package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto;
