package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.jpa.repository;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.jpa.entity.CGeSolicitudesEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repositorio que contiene todas las operaciones necesarias para gestionar de la entidad
 * CGeSolicitudesEntity.
 */
@Repository
public interface CGeSolicitudesRepository extends JpaRepository<CGeSolicitudesEntity, Long> {}
