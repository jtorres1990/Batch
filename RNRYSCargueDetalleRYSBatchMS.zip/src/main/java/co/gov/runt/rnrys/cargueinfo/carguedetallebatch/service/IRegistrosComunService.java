package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.rnrys.cargueinfo.core.registros.dto.RegistroRequest;

/**
 * Interfaz con todos los métodos disponibles para crear el DTO RegistroRequest datos de entrada
 * para los registros.
 *
 * @since 1.0.0
 */
public interface IRegistrosComunService {
  /**
   * Método para crear el DTO RegistroRequest datos de entrada para los registros.
   *
   * @param vehiculoDTO DTO con la información para el cargue.
   * @param nit Numero de identificación del ensamblador, importador o fabricante.
   * @param idUsuario Identificador del usuario.
   * @param idAutoridad Identificador de la autoridad de tránsito.
   * @param ipUsuario Ip del usuario.
   * @param idSolicitud Identificador de la solicitud.
   * @return RegistroRequest DTO de datos de entrada para los registros.
   */
  RegistroRequest crearRegistroRequest(
      VehiculoDTO vehiculoDTO,
      String nit,
      String idUsuario,
      Long idAutoridad,
      String ipUsuario,
      Long idSolicitud);
}
