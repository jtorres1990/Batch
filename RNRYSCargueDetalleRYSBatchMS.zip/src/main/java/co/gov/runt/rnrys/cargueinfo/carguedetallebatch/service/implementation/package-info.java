/**
 * Implementaciones de la lógica de negocio para la aplicación
 *
 * @since 1.0.0
 */
package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;
