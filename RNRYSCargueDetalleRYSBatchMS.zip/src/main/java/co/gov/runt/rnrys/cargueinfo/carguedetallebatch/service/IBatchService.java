package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service;

import co.gov.runt.rna.rnacarguearchivosapiclient.jpa.entity.SolicitudCargueEntity;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import org.springframework.batch.core.launch.JobLauncher;

/**
 * Interfaz con todos los métodos disponibles para gestionar clase de BatchService
 *
 * @since 1.0.0
 */
public interface IBatchService {

  /**
   * Método donde se ejecutan las tareas del proceso batch
   *
   * @param solicitud Entidad de solicitud de cargue.
   */
  void ejecutar(SolicitudCargueEntity solicitud);

  /**
   * Método para lanzar simple Job
   *
   * @return {@link JobLauncher}
   * @throws ErrorGeneralException cuando no se puede ejecutar el Batch
   */
  JobLauncher simpleJobLauncher() throws ErrorGeneralException;
}
