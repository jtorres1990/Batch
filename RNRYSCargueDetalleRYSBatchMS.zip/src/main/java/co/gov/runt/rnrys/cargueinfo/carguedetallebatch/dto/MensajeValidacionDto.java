package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums.MensajesErrorEnum;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

/**
 * Dto mensajes
 *
 * @since 1.0.0
 */
@Setter
@Getter
public class MensajeValidacionDto {

  private MensajesErrorEnum mensajesErrorEnum;
  private List<String> parametros;
}
