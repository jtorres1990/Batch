package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/** Enum que representa los estados del proceso batch */
@Getter
@RequiredArgsConstructor
public enum EstadoBatchEnum {
  /** Enumerado de estado de batch: pendiente */
  PENDIENTE("PENDIENTE"),
  /** Enumerado de estado de batch: en proceso */
  EN_PROCESO("EN_PROCESO"),
  /** Enumerado de estado de batch: procesado */
  PROCESADO("PROCESADO");

  private final String id;
}
