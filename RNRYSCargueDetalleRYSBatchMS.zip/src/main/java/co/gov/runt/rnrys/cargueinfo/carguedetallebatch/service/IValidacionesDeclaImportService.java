package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.RaDeclimportEntity;
import co.gov.runt.utilidades.exception.ErrorGeneralException;

/**
 * Interfaz con todos los métodos disponibles para las validaciones de la declaracion de
 * importación.
 *
 * @since 1.0.0
 */
public interface IValidacionesDeclaImportService {
  /**
   * Método para validar la declaración de importación.
   *
   * @param vehiculoDTO DTO con la informacion para el cargue.
   * @param nit Numero de identificación del ensamblador, importador o fabricante.
   * @param idAutoridad Identificador de la autoridad de tránsito.
   * @param idEmpresa Identificador de la empresa.
   * @param idUsuario Identificador del usuario.
   * @param nombreArchivo Nombre del archivo.
   * @throws ErrorGeneralException error general cuando no cumple con ninguna condición evaluada.
   */
  void validacionesDeclaracionImport(
      VehiculoDTO vehiculoDTO,
      String nit,
      Long idAutoridad,
      Long idEmpresa,
      String idUsuario,
      String nombreArchivo)
      throws ErrorGeneralException;

  /**
   * Método para validar cuando declaración de importación existe en el sistema.
   *
   * @param declaracionImportEntity RaDeclimportEntity.
   * @param vehiculoDTO DTO con la informacion para el cargue.
   * @param nit Numero de identificación del ensamblador, importador o fabricante.
   * @param nombreArchivo Nombre del archivo.
   * @param idEmpresa the id empresa
   * @throws ErrorGeneralException error general cuando no cumple con ninguna condición evaluada.
   */
  void validarExistenciaDeclaracion(
      RaDeclimportEntity declaracionImportEntity,
      VehiculoDTO vehiculoDTO,
      String nit,
      String nombreArchivo,
      Long idEmpresa)
      throws ErrorGeneralException;
}
