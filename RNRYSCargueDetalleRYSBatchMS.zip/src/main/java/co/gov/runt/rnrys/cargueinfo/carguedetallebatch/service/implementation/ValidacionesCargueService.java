package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.EjecutarValidacionesRequest;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums.TipoCargueArchivoEnum;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums.TipoLogMensajeEnum;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.*;
import co.gov.runt.rnrys.cargueinfo.validaciones.enums.Mensaje;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import java.text.MessageFormat;
import java.util.List;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Clase que implementa las funcionalidades de la interfaz IValidacionesCargueService
 *
 * @since 1.0.0
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ValidacionesCargueService implements IValidacionesCargueService {

  private final IValidacionesEstructuraContenidoService estructuraContenidoService;
  private final IValidacionesCreacionService validacionesCreacionService;
  private final IValidacionesModificacionService validacionesModificacionService;
  private final ILogMensajeCargueService logMensajeCargueService;
  private final ValidacionesEliminacionService validacionesEliminacionService;

  @Override
  public VehiculoDTO ejecutarValidaciones(
      EjecutarValidacionesRequest request, boolean inconsistente, boolean repetido) {
    log.info("Inicia proceso de validacion para la solicitud {}", request.getSolicitudId());

    if (validarErroresArchivo(request, inconsistente, repetido)) {

      List<String> erroresValidaciones =
          estructuraContenidoService.ejecutarValidaciones(
              request.getVehiculoDTO(),
              request.getNit(),
              request.getNombreArchivo(),
              request.getIdAutoridad(),
              request.getSolicitudId());
      try {
        if (Objects.isNull(erroresValidaciones) || erroresValidaciones.isEmpty()) {
          // 7. El sistema identifica que el tipo de cargue del detalle es Creación.
          validarTipoCargue(
              request.getVehiculoDTO(),
              request.getNit(),
              request.getNombreArchivo(),
              request.getIdAutoridad(),
              request.getIdEmpresa(),
              request.getIdUsuario());
        } else {
          logMensajeCargueService.guardarListaLog(
              erroresValidaciones,
              request.getSolicitudId(),
              request.getVehiculoDTO().getSecuencia(),
              request.getNombreArchivo());
          request.getVehiculoDTO().setFallidoValEstruContenido(Boolean.TRUE);
        }
        return request.getVehiculoDTO();
      } catch (Exception e) {
        request.getVehiculoDTO().setFallidoValEstruContenido(Boolean.TRUE);
        registrarLog(
            e.getMessage(),
            request.getVehiculoDTO().getSecuencia(),
            request.getNombreArchivo(),
            request.getSolicitudId());
        log.error("Error no controlado: ", e);
        return request.getVehiculoDTO();
      }
    }
    request.getVehiculoDTO().setFallidoValEstruContenido(Boolean.TRUE);
    return request.getVehiculoDTO();
  }

  private boolean validarErroresArchivo(
      EjecutarValidacionesRequest request, boolean inconsistente, boolean repetido) {

    if (inconsistente) {
      registrarLog(
          Mensaje.ERROR_NUMERO_REGISTROS.getMsg(),
          request.getVehiculoDTO().getSecuencia(),
          request.getNombreArchivo(),
          request.getSolicitudId());
    } else if (repetido) {
      registrarLog(
          Mensaje.ERROR_VEHICULO_EXISTE_GUARISMOS.getMsg(),
          request.getVehiculoDTO().getSecuencia(),
          request.getNombreArchivo(),
          request.getSolicitudId());
    }

    return !inconsistente && !repetido;
  }

  private void registrarLog(
      String mensaje, String registro, String nombreArchivo, Long solicitudId) {
    if (!registro.isBlank())
      logMensajeCargueService.guardarLog(
          MessageFormat.format(mensaje, registro, nombreArchivo),
          solicitudId,
          TipoLogMensajeEnum.ERROR.getId());
  }

  /**
   * Método para orquestar las validaciones dependiento del tipo de cargue.
   *
   * @param vehiculoDTO DTO con la informacion para el cargue.
   * @param nit Numero de identificación del ensamblador, importador o fabricante.
   * @param nombreArchivo Nombre del archivo.
   * @param idAutoridad Identificador de la autoridad de tránsito.
   * @param idEmpresa Identificador de la empresa.
   * @param idUsuario Identificador del usuario.
   */
  private void validarTipoCargue(
      VehiculoDTO vehiculoDTO,
      String nit,
      String nombreArchivo,
      Long idAutoridad,
      Long idEmpresa,
      String idUsuario)
      throws ErrorGeneralException {
    if (TipoCargueArchivoEnum.CREACION.getId().equals(vehiculoDTO.getTipoCargue())) {
      validacionesCreacionService.validarCreacion(
          vehiculoDTO, nit, nombreArchivo, idAutoridad, idEmpresa, idUsuario);
    } else if (TipoCargueArchivoEnum.MODIFICACION.getId().equals(vehiculoDTO.getTipoCargue())) {
      // 5.3 Tipo de cargue es modificación
      validacionesModificacionService.validarModificacion(
          vehiculoDTO, nit, nombreArchivo, idAutoridad, idEmpresa, idUsuario);
    } else if (TipoCargueArchivoEnum.ELIMINACION.getId().equals(vehiculoDTO.getTipoCargue())) {
      validacionesEliminacionService.validarEliminacion(vehiculoDTO, nombreArchivo);
    }
  }
}
