package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/** Enum que representa los estados de las placas de los vehículos */
@Getter
@AllArgsConstructor
public enum EstadoPlacaEnum {

  /** Estado pre-asignada */
  PREASIGNADA("PREASIGNADA");
  private final String id;
}
