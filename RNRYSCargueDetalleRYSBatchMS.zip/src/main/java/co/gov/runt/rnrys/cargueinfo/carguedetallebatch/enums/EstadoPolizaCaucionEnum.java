package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/** Enum que representa los estados de la póliza de caución */
@Getter
@RequiredArgsConstructor
public enum EstadoPolizaCaucionEnum {

  /** Estado ANULADA */
  ANULADA("ANULADA");
  private final String id;
}
