package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.jpa.entity;

import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;

/**
 * Entidad BatchSolicitudesCargueEntity. CSWCORETRANS.CAR_BATCHSOLICITUDES
 *
 * @since 1.0.0
 */
@Getter
@Setter
@Entity
@Cacheable(false)
@Table(schema = "CSWCORETRANS", name = "CAR_BATCHSOLICITUDES")
public class BatchSolicitudesCargueEntity {

  @Id
  @Column(name = "BATCHSOLICIT_SOLICARGU_ID")
  private Long solicitudCargueId;

  @Column(name = "BATCHSOLICIT_ESTADO")
  private String estado;

  @Column(name = "BATCHSOLICIT_IDAUTTRA")
  private Long idAutoridad;

  @Column(name = "BATCHSOLICIT_RAZOSOCIA")
  private String razonSocial;

  @Column(name = "BATCHSOLICIT_CORREOS")
  private String correos;

  @Column(name = "BATCHSOLICIT_NODO")
  private String nodo;

  @Column(name = "BATCHSOLICIT_JOB_ID")
  private Long job;
}
