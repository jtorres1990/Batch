package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.batch.reader;

import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.PassThroughLineMapper;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;

/** Clase encargada de leer los datos del archivo que tienen que ver con la estructura. */
@Slf4j
@Component
public class EstructuraVehiculoReader extends FlatFileItemReader<String> {

  /**
   * Metodo que obtiene los parametro necesario para la lectura del archivo y manejo de variables de
   * la ejecución
   *
   * @param stepExecution the step execution
   */
  @BeforeStep
  public void beforeStep(StepExecution stepExecution) {

    JobParameters parametros = stepExecution.getJobExecution().getJobParameters();
    String rutaArchivo = parametros.getString("rutaArchivo");
    if (Objects.nonNull(rutaArchivo)) {
      setResource(new FileSystemResource(Paths.get(rutaArchivo).toString()));
    } else {
      log.error("Ruta del archivo es null");
    }
  }

  /** Metodo que lee la estructura del detalle vehículo. */
  public EstructuraVehiculoReader() {
    setName("vehiculoEstructuraReader");
    setLinesToSkip(1);
    setEncoding(StandardCharsets.UTF_8.name());
    setLineMapper(new PassThroughLineMapper());
  }
}
