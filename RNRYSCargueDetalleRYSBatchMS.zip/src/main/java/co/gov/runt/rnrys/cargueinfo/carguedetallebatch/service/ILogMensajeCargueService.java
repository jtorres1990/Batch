package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service;

import java.util.List;

/**
 * Interfaz con todos los métodos disponibles para el log mensajes del cargue.
 *
 * @since 1.0.0
 */
public interface ILogMensajeCargueService {
  /**
   * Método para guardar los mesajes de error.
   *
   * @param mensaje Mensaje de error.
   * @param solicitudId Identificador de la solicitud.
   * @param tipoLogMensaje Tipo de log de mensaje.
   */
  void guardarLog(String mensaje, Long solicitudId, String tipoLogMensaje);

  /**
   * Método para guardar lista de mesajes de error.
   *
   * @param mensajes Lista de mensajes de error.
   * @param solicitudId Identificador de la solicitud.
   * @param secuencia Secuencia del archivo.
   * @param archivoNombre the archivo nombre
   */
  void guardarListaLog(
      List<String> mensajes, Long solicitudId, String secuencia, String archivoNombre);
}
