package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.jpa.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;

/**
 * Entidad CGeSolicitudesEntity. RUNTPROD.GE_SOLICITUD
 *
 * @since 1.0.0
 */
@Getter
@Setter
@Entity
@Cacheable(false)
@Table(schema = "RUNTPROD", name = "GE_SOLICITUD")
public class CGeSolicitudesEntity implements Serializable {

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SolicitudEntitySeq")
  @SequenceGenerator(
      schema = "RUNTPROD",
      sequenceName = "GE_SOLICITUD_SEQ",
      allocationSize = 1,
      name = "SolicitudEntitySeq")
  @Column(name = "SOLICITUD_IDENSOLIC")
  private Long solicitudId;

  @Column(name = "SOLICITUD_AUTOTRANS_IDAUTTRA")
  private Long autoridadTransito;

  @Column(name = "SOLICITUD_TIPREGSOL_IDREGISOL")
  private Long registroRuntSolcitud;

  @Column(name = "SOLICITUD_PERSONA_IDPERSONA")
  private Long persona;

  @Column(name = "SOLICITUD_PERSONA_NRODOCUME")
  private String numeroDocumento;

  @Column(name = "SOLICITUD_PERSONA_TIPOIDENT")
  private String tipoDocumento;

  @Column(name = "SOLICITUD_PODEPROPI_IDPODER")
  private Long poderPropiedad;

  @Column(name = "SOLICITUD_NROLIQAUT")
  private Long numeroLiquidacio;

  @Column(name = "SOLICITUD_PLACA_NUMPLACA")
  private String numeroPlaca;

  @Column(name = "SOLICITUD_PERSONA_IDENPERSO")
  private Long personaSolicitud;

  @Column(name = "SOLICITUD_INDISOLIC")
  private String servicioAsociado;

  @Column(name = "SOLICITUD_INDILIQUI")
  private String liquidacion;

  @Column(name = "SOLICITUD_FECHREGIS")
  private Date fechaRegistro;

  @Column(name = "SOLICITUD_FECHVIGEN")
  private Date fechaVegencia;

  @Column(name = "SOLICITUD_FECHEJECU")
  private Date fechaEjecucion;

  @Column(name = "SOLICITUD_TIPOSOLIC_NOMBRE")
  private String tipoSolicitud;

  @Column(name = "SOLICITUD_AUTOTRANS_IDEMPSEDE")
  private Long sedeSolicitud;

  @Column(name = "SOLICITUD_INDIINGRE")
  private String ingresoSolicitud;

  @Column(name = "SOLICITUD_NRODOCREP")
  private String documentoRepresentanteLegal;

  @Column(name = "SOLICITUD_TIPOIDENT_TIPDOCREP")
  private String tipoDocumentoRepresentanteLegal;

  @Column(name = "SOLICITUD_APRFUNVAH")
  private String aprobacionHuella;

  @Column(name = "SOLICITUD_SOLCIUDAD")
  private String ciudadanoSolitud;
}
