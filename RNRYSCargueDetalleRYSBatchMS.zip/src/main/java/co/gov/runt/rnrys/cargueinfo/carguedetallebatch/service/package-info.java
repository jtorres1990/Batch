/**
 * Paquete que agrupa todas las interfaces o contratos que representan la lógica del negocio de la
 * aplicación
 *
 * @since 1.0.0
 */
package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service;
