package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums;

import java.util.Arrays;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Enumerado para los tipos de registro en un acta de importación
 *
 * @since 1.0.0
 */
@Getter
@AllArgsConstructor
public enum TipoRegistroEnum {

  /** Tipo de registro Vehículo */
  VEHICULO("V", "VEHICULO", "AUTOMOVIL"),

  /** Tipo de registro Chasis */
  CHASIS("C", "CHASIS", null),

  /** Tipo de registro Motor */
  MOTOR("MOTOR", "MOTOR", null),

  /** Tipo de registro Motocarro */
  MOTOCARRO("M", "MOTOCARRO", "MOTOCARRO"),

  /** Tipo de registro Moto */
  MOTO("MOTO", "MOTO", "MOTO"),

  /** Tipo de registro Maquinaria */
  MAQUINARIA("MAQUINARIA", "MAQUINARIA", "MAQUINARIA AGRICOLA");

  /** Identificador para registrar información por pantalla o por archivo */
  private final String id;

  /** PK de RUNTPROD.PA_TIPREGDEC */
  private final String idHomologado;

  /** Homologación para obtener clases de vehículo */
  private final String homologoClasificacion;

  /**
   * Método encargado de obtener el enumerado de tipo de registro por nombre para el homólogo
   *
   * @param idHomologado Nombre del tipo de registro
   * @return Enumerado para el tipo de registro ingresado
   * @since 1.0.0
   */
  public static TipoRegistroEnum getByIdHomologado(String idHomologado) {
    return Arrays.stream(TipoRegistroEnum.values())
        .filter(tipoRegistroEnum -> tipoRegistroEnum.getIdHomologado().equals(idHomologado))
        .findFirst()
        .orElse(null);
  }

  /**
   * Método encargado de obtener el tipo de registro valido para el cargue.
   *
   * @param id Identificador del tipo de registro
   * @return true o false
   * @since 1.0.0
   */
  public static boolean esTipoRegistroValido(String id) {
    return (VEHICULO.getId().equals(id)
        || CHASIS.getId().equals(id)
        || MOTOCARRO.getId().equals(id));
  }
  /**
   * Método encargado de validar si es de tipo Moto
   *
   * @param id Identificador del tipo de registro
   * @return true o false
   * @since 1.0.0
   */
  public static boolean esMoto(String id) {
    return (MOTO.getId().equals(id));
  }
  /**
   * Método encargado de validar si es chasis o motocarro.
   *
   * @param id Identificador del tipo de registro
   * @return true o false
   * @since 1.0.0
   */
  public static boolean esChasisMotocarro(String id) {
    return (CHASIS.getId().equals(id) || MOTOCARRO.getId().equals(id));
  }
}
