package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * DTO Datos entrada para ejecutar las validaciones.
 *
 * @since 1.0.0
 */
@Getter
@Setter
public class EjecutarValidacionesRequest {

  private VehiculoDTO vehiculoDTO;
  private String nit;
  private String nombreArchivo;
  private Long idAutoridad;
  private Long idEmpresa;
  private String idUsuario;
  private Long solicitudId;
  private Boolean fallidoValEstruContenido;
}
