package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import java.util.List;

/**
 * Interfaz con todos los métodos disponibles para las validaciones de estructura y contenido.
 *
 * @since 1.0.0
 */
public interface IValidacionesEstructuraContenidoService {
  /**
   * Método para orquestar la ejecución de las validaciones de estructura y contenido.
   *
   * @param vehiculoDTO DTO con la informacion para el cargue.
   * @param nit Numero de identificación del ensamblador, importador o fabricante.
   * @param nombreArchivo Nombre del archivo.
   * @param idAutoridad Identificador de la autoridad de tránsito.
   * @param solicitudId Identificador de la solicitud de cargue.
   * @return Lista de String
   */
  List<String> ejecutarValidaciones(
      VehiculoDTO vehiculoDTO,
      String nit,
      String nombreArchivo,
      Long idAutoridad,
      Long solicitudId);
}
