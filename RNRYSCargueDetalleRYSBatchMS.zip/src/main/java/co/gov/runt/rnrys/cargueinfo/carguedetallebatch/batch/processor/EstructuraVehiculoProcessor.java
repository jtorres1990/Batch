package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.batch.processor;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IValidacionesControlService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.utilities.Constantes;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import java.util.ArrayList;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

/** Clase responsable de tratar la información obtenida de la estructura por el reader. */
@Slf4j
@Component
@RequiredArgsConstructor
public class EstructuraVehiculoProcessor implements ItemProcessor<String, String> {
  private final IValidacionesControlService validacionesControlService;
  private Long solicitudId;

  private StepExecution stepExecution;

  /**
   * Método que obtiene los datos basicos para continuar la ejecución
   *
   * @param stepExecution the step execution
   */
  @BeforeStep
  public void beforeStep(StepExecution stepExecution) {
    this.stepExecution = stepExecution;
    JobParameters parametros = stepExecution.getJobExecution().getJobParameters();
    solicitudId = parametros.getLong("solicitudId");
  }

  /**
   * Método que porcesa la validaciones de estructura de la linea.
   *
   * @param lineaVehiculo
   * @return Linea del archivo de cargue de vehículo
   */
  @Override
  public String process(String lineaVehiculo) throws ErrorGeneralException {
    log.info("Linea vehículo a procesar {}", lineaVehiculo);

    if (validacionesControlService.validaExpresionLinea(lineaVehiculo)) {
      log.info("Finaliza procesor Estructura para el archivo de la solicitud {}", solicitudId);
      return lineaVehiculo;
    }
    validarInconsistente(lineaVehiculo);
    log.info("Finaliza procesor Estructura para el archivo de la solicitud {}", solicitudId);
    return null;
  }

  @SuppressWarnings("unchecked")
  private void validarInconsistente(String lineaVehiculo) {
    String[] partes = lineaVehiculo.split("\\|");
    String registro = partes[0];
    List<String> listaInconsistente =
        (List<String>)
            this.stepExecution
                .getJobExecution()
                .getExecutionContext()
                .get(Constantes.LISTA_INCONSISTENTES);

    if (listaInconsistente != null) {
      listaInconsistente.add(registro);
    } else {
      listaInconsistente = new ArrayList<>();
      listaInconsistente.add(registro);
    }

    this.stepExecution
        .getJobExecution()
        .getExecutionContext()
        .put(Constantes.LISTA_INCONSISTENTES, listaInconsistente);
  }
}
