package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums.MensajesErrorEnum;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IValidacionesComunesService;
import co.gov.runt.rnrys.cargueinfo.core.consultas.dto.FiltroAutomotorDTO;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.*;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.repository.*;
import co.gov.runt.rnrys.cargueinfo.validaciones.enums.Mensaje;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import java.text.MessageFormat;
import java.util.List;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Clase que implementa las funcionalidades de la interfaz IValidacionesComunesService
 *
 * @since 1.0.0
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ValidacionesComunesService implements IValidacionesComunesService {

  private final AutomotorRepository automotorRepository;
  private final MensajeService mensajeService;

  @Override
  public void validarMotorChasisMarca(VehiculoDTO vehiculoDTO, String nombreArchivo)
      throws ErrorGeneralException {
    // F.A. 5.11 El tipo de cargue es modificación/eliminación y no se relaciona VIN
    // 1. El sistema identifica que, para el registro a modificar/eliminar el número de motor,
    // chasis, serie y marca
    // existe en el RNA y no tiene VIN asociado.
    FiltroAutomotorDTO filtro = FiltroAutomotorDTO.builder().build();
    filtro.setIdMarca(Long.parseLong(vehiculoDTO.getMarca()));

    List<AutomotorEntity> automotorEntityList = automotorRepository.findFiltered(filtro);

    if (!Objects.isNull(automotorEntityList)
        && !automotorEntityList.isEmpty()
        && (automotorEntityList.get(0).getNroVin() == null
            || automotorEntityList.get(0).getNroVin().isEmpty()
            || automotorEntityList.get(0).getNroVin().trim().isEmpty())) {

      throw new ErrorGeneralException(
          MessageFormat.format(
              mensajeService
                  .obtenerMensaje(MensajesErrorEnum.ERROR_VIN_VEHICULO_MOD_ELI)
                  .getValor(),
              vehiculoDTO.getSecuencia(),
              nombreArchivo));
      // Finaliza CU en F.A. 5.11
    }
  }

  @Override
  public AutomotorEntity obtenerAutomotorPorVin(VehiculoDTO vehiculoDTO, String nombreArchivo)
      throws ErrorGeneralException {
    // 5.13 VIN no existe en el RNA
    FiltroAutomotorDTO filtro = FiltroAutomotorDTO.builder().build();
    filtro.setNumeroVIN(vehiculoDTO.getVin());

    List<AutomotorEntity> automotorEntities = automotorRepository.findFiltered(filtro);

    if (Objects.isNull(automotorEntities) || automotorEntities.isEmpty()) {

      // F.A 5.13 VIN no existe en el RNA
      throw new ErrorGeneralException(
          MessageFormat.format(
              Mensaje.ERROR_VEHICULO_NO_EXISTE_GUARISMOS.getMsg(),
              vehiculoDTO.getSecuencia(),
              nombreArchivo));
    }

    return automotorEntities.get(0);
  }

  @Override
  public List<AutomotorEntity> obtenerAutomotorPorLineaMarcaGuarismos(VehiculoDTO vehiculoDTO) {
    // 5.13 VIN no existe en el RNA
    FiltroAutomotorDTO filtroAutomotor = FiltroAutomotorDTO.builder().build();
    filtroAutomotor.setNumeroVIN(vehiculoDTO.getVin());
    filtroAutomotor.setIdMarca(Long.parseLong(vehiculoDTO.getMarca()));
    filtroAutomotor.setIdLinea(Long.parseLong(vehiculoDTO.getLinea()));
    return automotorRepository.findFiltered(filtroAutomotor);
  }
}
