package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/** Enum que representa los Tipos de archivo */
@Getter
@AllArgsConstructor
public enum TipoArchivoEnum {
  /** Tipo detalle vehículo */
  DETALLE_VEHICULORYS("22");
  private final String id;
}
