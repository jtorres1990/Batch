package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.batch.writer;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.MensajeValidacionesControlDTO;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums.MensajesErrorEnum;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums.TipoLogMensajeEnum;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.ILogMensajeCargueService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IMensajeService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IValidacionesControlService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.utilities.Constantes;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import java.text.MessageFormat;
import java.util.List;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;

/**
 * Clase responsable de guardar la información de la estructura del archivo leida por el reader y
 * tratada por el procesor .
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class EstructuraVehiculoWriter implements ItemWriter<String> {

  private String totalRegistros;
  private String fechaCorte;
  private Long totalFilasLeidas;
  private String nit;
  private String nombreArchivo;
  private Long solicitudId;
  private final IValidacionesControlService validacionesControlService;
  private final ILogMensajeCargueService logMensajeCargueService;
  private final IMensajeService mensajeService;
  private StepExecution stepExecution;
  private boolean flag = false;

  /**
   * Metodo que obtiene los parametro necesario para la escritura del archivo y manejo de variables
   * de la ejecución para la parte de la estructura.
   *
   * @param stepExecution the step execution
   */
  @BeforeStep
  public void beforeStep(StepExecution stepExecution) {
    this.stepExecution = stepExecution;
    JobParameters parametros = stepExecution.getJobExecution().getJobParameters();
    totalRegistros = parametros.getString("totalRegistros");
    fechaCorte = parametros.getString("fechaCorte");
    nit = parametros.getString("nit");
    solicitudId = parametros.getLong("solicitudId");
    nombreArchivo = parametros.getString("nombreArchivo");
    totalFilasLeidas = parametros.getLong(Constantes.CONTADOR_FILAS);
  }

  /**
   * Método que se llamará despues de que se ejecute el writer, donde se cargan los parametros.
   *
   * @param stepExecution the step execution
   * @return the exit status
   */
  @AfterStep
  public ExitStatus afterStep(StepExecution stepExecution) {
    if (flag) {
      log.info("La solicitud {} tuvo errores en la estructura del archivo.", solicitudId);
      return new ExitStatus("ESTRUCTURA_INVALIDA");
    }
    return ExitStatus.COMPLETED;
  }

  /**
   * Método en donde se realizan las validaciones de control del archivo.
   *
   * @param list Lista de lineas.
   * @throws ErrorGeneralException error general cuando no cumple con ninguna condición evaluada
   */
  @Override
  public void write(List<? extends String> list) throws ErrorGeneralException {
    flag = false;
    log.info("Estructura tamaño lista" + list.size());
    list.forEach(log::info);
    boolean filasIguales = false;

    MensajeValidacionesControlDTO validaNumeroRegistros =
        validacionesControlService.validaNumeroRegistros(totalRegistros);
    MensajeValidacionesControlDTO validaFechaCorte =
        validacionesControlService.validaFechaCorte(fechaCorte);
    MensajeValidacionesControlDTO validarNit =
        validacionesControlService.validarNit(nit, nombreArchivo);

    if (Objects.nonNull(totalFilasLeidas)) {
      filasIguales = totalFilasLeidas == Long.parseLong(totalRegistros);
    }

    guardarLogValidacionControl(
        filasIguales, validaNumeroRegistros, validaFechaCorte, validarNit, nit);

    log.info(
        "Validaciones de estructura expresión: {} numero de registros: {} fecha corte: {} validar"
            + " nit: {}",
        filasIguales,
        validaNumeroRegistros.isError(),
        validaFechaCorte.isError(),
        validarNit.isError());

    if (!filasIguales
        || validaNumeroRegistros.isError()
        || validaFechaCorte.isError()
        || validarNit.isError()) {
      flag = true;
      int registrosInconsistentes = Integer.parseInt(totalRegistros) - list.size();
      this.stepExecution
          .getJobExecution()
          .getExecutionContext()
          .put(Constantes.REGISTROS_INCONSISTENTES, registrosInconsistentes);
    }

    log.info("Finaliza escritura Estructura para el archivo de la solicitud {}", solicitudId);
  }

  /**
   * Método en donde se guarda los logs de validación de control.
   *
   * @param filasIguales True o False.
   * @param validaNumeroRegistros Mensaje de validación de control para num de registros.
   * @param validaFechaCorte Mensaje de validación de control para fecha de corte.
   * @param validarNit Mensaje de validación de control para nit.
   */
  private void guardarLogValidacionControl(
      boolean filasIguales,
      MensajeValidacionesControlDTO validaNumeroRegistros,
      MensajeValidacionesControlDTO validaFechaCorte,
      MensajeValidacionesControlDTO validarNit,
      String nit)
      throws ErrorGeneralException {

    if (validaNumeroRegistros.isError()) {
      String mensaje =
          MessageFormat.format(
              mensajeService
                  .obtenerMensaje(MensajesErrorEnum.ERROR_VALOR_MAXIMO_REGISTROS)
                  .getValor(),
              nombreArchivo);
      logMensajeCargueService.guardarLog(mensaje, solicitudId, TipoLogMensajeEnum.ERROR.getId());
      log.info("Error validando la estructura en el numero de registros");
    }
    if (validaFechaCorte.isError()) {
      String mensaje =
          MessageFormat.format(
              mensajeService.obtenerMensaje(MensajesErrorEnum.ERROR_FECHA_DE_CORTE).getValor(),
              nombreArchivo);
      logMensajeCargueService.guardarLog(mensaje, solicitudId, TipoLogMensajeEnum.ERROR.getId());
      log.info("Error validando la estructura en la fecha corte");
    }
    if (validarNit.isError()) {
      String mensaje =
          MessageFormat.format(
              mensajeService.obtenerMensaje(MensajesErrorEnum.ERROR_NIT).getValor(),
              nit,
              nombreArchivo);
      logMensajeCargueService.guardarLog(mensaje, solicitudId, TipoLogMensajeEnum.ERROR.getId());
      log.info("Error validando la estructura en el nit");
    }

    if (!filasIguales) {
      String mensaje =
          MessageFormat.format(
              "El valor de las filas leidas ({0}) es diferente al reportado en el archivo ({1})."
                  + " Nombre del archivo {2}.",
              totalFilasLeidas, totalRegistros, nombreArchivo);

      logMensajeCargueService.guardarLog(mensaje, solicitudId, TipoLogMensajeEnum.ERROR.getId());
    }
  }
}
