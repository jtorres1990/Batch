package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.utilidades.exception.ErrorGeneralException;

/**
 * Interfaz con todos los métodos disponibles para los registros del tipo de cargue eliminación.
 *
 * @since 1.0.0
 */
public interface IRegistrosEliminacionService {
  /**
   * Método para realizar el proceso registrar el cargue de eliminación.
   *
   * @param vehiculoDTO DTO con la informacion para el cargue.
   * @throws ErrorGeneralException error general cuando no cumple con ninguna condición evaluada.
   */
  void eliminarCargueCreacion(VehiculoDTO vehiculoDTO) throws ErrorGeneralException;
}
