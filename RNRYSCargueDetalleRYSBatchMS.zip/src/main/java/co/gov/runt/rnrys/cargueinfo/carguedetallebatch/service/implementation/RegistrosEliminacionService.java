package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IRegistrosEliminacionService;
import co.gov.runt.rnrys.cargueinfo.core.consultas.dto.FiltroAutomotorDTO;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.AutomotorEntity;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.repository.AutomotorRepository;
import co.gov.runt.rnrys.cargueinfo.core.registros.dto.RegistroRequest;
import co.gov.runt.rnrys.cargueinfo.core.registros.service.IRegistroCargueDetalleRnaService;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Clase que implementa las funcionalidades de la interfaz IRegistrosEliminacionService
 *
 * @since 1.0.0
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class RegistrosEliminacionService implements IRegistrosEliminacionService {

  private final IRegistroCargueDetalleRnaService registroCargueDetalleVehiculo;
  private final AutomotorRepository automotorRepository;

  @Override
  public void eliminarCargueCreacion(VehiculoDTO vehiculoDTO) throws ErrorGeneralException {
    RegistroRequest registroRequest = new RegistroRequest();
    FiltroAutomotorDTO filtro = FiltroAutomotorDTO.builder().build();
    filtro.setNumeroVIN(vehiculoDTO.getVin());
    List<AutomotorEntity> automotorEntity = automotorRepository.findFiltered(filtro);
    registroRequest.setDetalleCargueVehiculoRequest(vehiculoDTO);
    if (!automotorEntity.isEmpty())
      registroRequest.setAutomotor(automotorEntity.stream().findFirst().get());
    registroRequest.setTipoCargue(vehiculoDTO.getTipoCargue());
    registroCargueDetalleVehiculo.registroCargueDetalleVehiculo(registroRequest);
  }
}
