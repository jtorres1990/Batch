package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.utilidades.exception.ErrorGeneralException;

/**
 * Interfaz con todos los métodos disponibles para las validaciones de creación.
 *
 * @since 1.0.0
 */
public interface IValidacionesCreacionService {

  /**
   * Método para validar cuando el tipo de cargue es creación.
   *
   * @param vehiculoDTO DTO con la informacion para el cargue.
   * @param nit Numero de identificación del ensamblador, importador o fabricante.
   * @param nombreArchivo Nombre del archivo.
   * @param idAutoridad Identificador de la autoridad de tránsito.
   * @param idEmpresa Identificador de la empresa.
   * @param idUsuario Identificador del usuario.
   * @throws ErrorGeneralException error general cuando no cumple con ninguna condición evaluada
   */
  void validarCreacion(
      VehiculoDTO vehiculoDTO,
      String nit,
      String nombreArchivo,
      Long idAutoridad,
      Long idEmpresa,
      String idUsuario)
      throws ErrorGeneralException;
}
