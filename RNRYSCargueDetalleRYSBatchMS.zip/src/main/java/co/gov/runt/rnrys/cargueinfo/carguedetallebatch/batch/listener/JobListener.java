package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.batch.listener;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums.EstadoBatchEnum;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IBatchJobProcesorService;
import co.gov.runt.utilidades.exception.ElementoNoEncontradoException;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import java.io.IOException;
import java.util.concurrent.ExecutionException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.stereotype.Component;

/** Clase encargada de la orquestación de los jobs del batch */
@Slf4j
@Component
@RequiredArgsConstructor
public class JobListener implements JobExecutionListener {

  private final IBatchJobProcesorService batchJobProcesorService;

  /** beforeJob cargue detalle vehiculo */
  public void beforeJob(JobExecution jobExecution) {
    log.info("beforeJob ");
    Long idSolicitud = this.batchJobProcesorService.darIdSolicitud(jobExecution);
    batchJobProcesorService.actualizarBatchService(
        idSolicitud, jobExecution.getJobId(), EstadoBatchEnum.EN_PROCESO.getId());
    log.info("beforeJob Cargue detalle");
  }

  /** afterJob cargue detalle vehiculo */
  public void afterJob(JobExecution jobExecution) {
    try {
      this.batchJobProcesorService.procesarFinalizacionJob(jobExecution);
    } catch (ErrorGeneralException
        | ElementoNoEncontradoException
        | IOException
        | ExecutionException e) {
      Long idSolicitud = this.batchJobProcesorService.darIdSolicitud(jobExecution);
      log.error("Error Cargue Detalle afterJob solicitud ::> {}", idSolicitud);
    }
  }
}
