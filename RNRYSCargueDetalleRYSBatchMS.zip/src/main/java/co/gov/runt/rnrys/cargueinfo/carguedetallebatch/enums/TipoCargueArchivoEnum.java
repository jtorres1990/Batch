package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/** Enum que representa los Tipos de cargue */
@Getter
@RequiredArgsConstructor
public enum TipoCargueArchivoEnum {
  /** Tipo cargue creación */
  CREACION("C"),
  /** Tipo cargue modificación */
  MODIFICACION("M"),
  /** Tipo cargue eliminación */
  ELIMINACION("E");

  private final String id;
}
