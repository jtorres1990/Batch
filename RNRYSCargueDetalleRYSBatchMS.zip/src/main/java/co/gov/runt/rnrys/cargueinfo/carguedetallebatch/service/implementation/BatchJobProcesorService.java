package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import static co.gov.runt.rnrys.cargueinfo.carguedetallebatch.utilities.Constantes.*;

import co.gov.runt.rna.rnacarguearchivosapiclient.jpa.entity.BatchSolicitudCargueEntity;
import co.gov.runt.rna.rnacarguearchivosapiclient.jpa.entity.EstadoCargueEntity;
import co.gov.runt.rna.rnacarguearchivosapiclient.jpa.entity.SolicitudCargueEntity;
import co.gov.runt.rna.rnacarguearchivosapiclient.jpa.repository.SolicitudCargueRepository;
import co.gov.runt.rna.rnacarguearchivosapiclient.service.ICargueSolicitudService;
import co.gov.runt.rna.rnacarguearchivosapiclient.service.implementation.LogEstadoCargueService;
import co.gov.runt.rna.rnacarguearchivosapiclient.utilities.Constantes;
import co.gov.runt.rna.rnacarguearchivosapiclient.utilities.TipoMensajeLog;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums.EstadoBatchEnum;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums.MensajesErrorEnum;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums.TipoLogMensajeEnum;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IBatchJobProcesorService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.ILogMensajeCargueService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IMensajeService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.utilities.FuncionesBatch;
import co.gov.runt.utilidades.exception.ElementoNoEncontradoException;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import co.gov.runt.utilidades.utilities.InformacionUsuario;
import com.fasterxml.jackson.core.JsonProcessingException;
import java.io.IOException;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.ExecutionException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.stereotype.Service;

/**
 * Clase que implementa las funcionalidades de la interfaz IBatchJobProcesorService
 *
 * @since 1.0.0
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class BatchJobProcesorService implements IBatchJobProcesorService {

  private final LogEstadoCargueService logEstadoCargueService;
  private final ICargueSolicitudService iCargueSolicitudService;
  private final SolicitudCargueRepository solicitudCargueRepository;
  private final ILogMensajeCargueService logMensajeCargueService;
  private final FuncionesBatch funcionesBatch;
  private final IMensajeService iMensajeService;
  private final InformacionUsuario informacionUsuario;

  @Override
  public Long darIdSolicitud(JobExecution pExecution) {
    JobParameters misParametro = pExecution.getJobParameters();
    return misParametro.getLong(SOLICITUD_ID);
  }

  @Override
  public void cambiarEstadoInicial(SolicitudCargueEntity solicitud)
      throws ElementoNoEncontradoException {
    EstadoCargueEntity estado =
        iCargueSolicitudService.cambiarEstado(
            solicitud,
            Constantes.EstadosSolicitudCargue.ARCHIVO_PROCESO_VALIDACION.getEstadoId(),
            solicitud.getUsuario());

    String mensaje = estado.getNombre() + " " + solicitud.getNombreArchivo();

    this.logEstadoCargueService.registrarLogEstado(
        solicitud.getSolicitud(), mensaje, TipoMensajeLog.TIPO_MENSAJE_INFO.getTipoMensajeId());
  }

  @Override
  public void actualizarBatchService(Long solicitudId, Long job, String estado) {
    Optional<SolicitudCargueEntity> solicitud = solicitudCargueRepository.findById(solicitudId);
    if (solicitud.isPresent() && solicitud.get().getIdBatchSolicitud() != null) {
      BatchSolicitudCargueEntity batchSolicitud = solicitud.get().getIdBatchSolicitud();
      batchSolicitud.setEstado(estado);

      if (batchSolicitud.getJob() == null) {
        batchSolicitud.setJob(job);
      }

      iCargueSolicitudService.actualizarBatchSolicitudCargue(batchSolicitud);
    }
  }

  @Override
  public void procesarFinalizacionJob(JobExecution pExecution)
      throws ElementoNoEncontradoException, IOException, ExecutionException, ErrorGeneralException {
    log.info("procesarFinalizacionJob ::> Job finalizado");
    Integer totalGuardados;

    Long idSolicitud = darIdSolicitud(pExecution);

    Optional<SolicitudCargueEntity> solicitud = solicitudCargueRepository.findById(idSolicitud);

    if (solicitud.isPresent()) {
      log.info("procesarFinalizacionJob ::> Solicitud presente");

      Integer totalRegistrosConError =
          (Integer) pExecution.getExecutionContext().get(REGISTROS_FALLIDOS);
      Integer inconsistentes =
          (Integer) pExecution.getExecutionContext().get(REGISTROS_INCONSISTENTES);
      if (Objects.isNull(pExecution.getExecutionContext().get(REGISTROS_GUARDADOS))) {
        totalGuardados = 0;
      } else {
        totalGuardados = (Integer) pExecution.getExecutionContext().get(REGISTROS_GUARDADOS);
      }

      Integer totalRegistros = Integer.parseInt(obtenerTotalRegistros(pExecution));
      procesarRespuesta(totalRegistros, solicitud.get(), totalGuardados);

      guardarConsolidado(
          inconsistentes != null ? inconsistentes : 0,
          totalRegistros,
          totalGuardados,
          totalRegistrosConError != null ? totalRegistrosConError : 0,
          idSolicitud);

      actualizarBatchService(idSolicitud, null, EstadoBatchEnum.PROCESADO.name());

      String[] arrayFromString =
          Objects.requireNonNull(pExecution.getJobParameters().getString(CORREOS)).split(",");
      enviarCorreo(Arrays.asList(arrayFromString), idSolicitud.toString());
    }
  }

  private void enviarCorreo(List<String> correos, String idSolicitud)
      throws JsonProcessingException {
    funcionesBatch.enviarCorreo(
        correos, idSolicitud, LocalDate.now().toString(), informacionUsuario.getNombreCompleto());
  }

  @Override
  public String obtenerTotalRegistros(JobExecution pExecution) {
    JobParameters misParametro = pExecution.getJobParameters();
    return misParametro.getString(TOTAL_REGISTROS);
  }

  /**
   * Método para procesar el estado de la solicitud de cargue.
   *
   * @param totalRegistros Total registros.
   * @param totalGuardados Total registros guardados.
   * @param solicitud Entidad de la solicitud.
   * @throws ElementoNoEncontradoException error elemento no encontrado.
   */
  private void procesarRespuesta(
      Integer totalRegistros, SolicitudCargueEntity solicitud, Integer totalGuardados)
      throws ElementoNoEncontradoException {

    if (Objects.equals(totalRegistros, totalGuardados)) {
      iCargueSolicitudService.cambiarEstado(
          solicitud,
          Constantes.EstadosSolicitudCargue.CARGUE_ARCHIVO_EXITOSO.getEstadoId(),
          solicitud.getUsuario());
    } else if (totalRegistros > 0 && totalGuardados == 0) {

      iCargueSolicitudService.cambiarEstado(
          solicitud,
          Constantes.EstadosSolicitudCargue.CARGUE_ARCHIVO_FALLIDO.getEstadoId(),
          solicitud.getUsuario());
    } else {

      iCargueSolicitudService.cambiarEstado(
          solicitud,
          Constantes.EstadosSolicitudCargue.CARGUE_ARCHIVO_INCONSISTENTE.getEstadoId(),
          solicitud.getUsuario());
    }
  }

  /**
   * Método para guardar el consolidado de total registros guardados y total registros con error.
   *
   * @param totalGuardados Total registros guardados.
   * @param totalRegistrosConError Total registros con error.
   * @param idSolicitud Identificador de la solicitud.
   */
  private void guardarConsolidado(
      Integer inconsistentes,
      Integer totalRegistros,
      Integer totalGuardados,
      Integer totalRegistrosConError,
      Long idSolicitud)
      throws ErrorGeneralException {

    String mensaje =
        MessageFormat.format(
            iMensajeService
                .obtenerMensaje(MensajesErrorEnum.GENERAL_CONSOLIDADO_VALIDACIONES)
                .getValor(),
            totalRegistros,
            totalGuardados,
            inconsistentes,
            totalRegistrosConError);
    logMensajeCargueService.guardarLog(mensaje, idSolicitud, TipoLogMensajeEnum.GENERAL.getId());
  }
}
