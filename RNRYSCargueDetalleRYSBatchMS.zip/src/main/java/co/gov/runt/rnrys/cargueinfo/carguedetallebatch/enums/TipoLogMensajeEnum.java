package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/** Enum que representa los tipos de log mensaje */
@Getter
@RequiredArgsConstructor
public enum TipoLogMensajeEnum {
  /** Log error */
  ERROR("E"),
  /** Log información */
  INFORMACION("I"),
  /** Log general */
  GENERAL("G");
  private final String id;
}
