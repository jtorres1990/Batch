package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.MensajeValidacionesControlDTO;
import co.gov.runt.utilidades.exception.ErrorGeneralException;

/**
 * Interfaz con todos los métodos disponibles para las validaciones de control del cargue.
 *
 * @since 1.0.0
 */
public interface IValidacionesControlService {

  /**
   * Método para validar estructura y contenido del total de registros
   *
   * @param totalRegistros número de registros que contiene el archivo
   * @return boolean true o false si cumple con las condiciones de estructura y contenido
   * @throws ErrorGeneralException error general cuando no cumple con ninguna condición evaluada
   */
  MensajeValidacionesControlDTO validaNumeroRegistros(String totalRegistros)
      throws ErrorGeneralException;

  /**
   * Método para validar estructura y contenido de la fecha de corte (no debe ser mayor a la fecha
   * de carga y debe ser mayor a 01/01/1900)
   *
   * @param fechaCorte fecha hasta la cual se remite el último registro a cargar
   * @return boolean true o false si cumple con las condiciones de estructura y contenido
   * @throws ErrorGeneralException error general cuando no cumple con ninguna condición evaluada
   */
  MensajeValidacionesControlDTO validaFechaCorte(String fechaCorte) throws ErrorGeneralException;

  /**
   * Método para validar que la línea (registro) cumpla con las condiciones de la expresión regular
   *
   * @param linea registro
   * @return boolean true o false que evalúa si cumple con la condición de la expresión regular
   */
  boolean validaExpresionLinea(String linea);

  /**
   * Método para validar que el nit cumpla con la condición de contenido y este registrado como
   * ensamblador, importador o fabricante en el RNPNJ
   *
   * @param nit nit del ensamblador, importador o fabricante
   * @param nombreArchivo the nombre archivo
   * @return boolean true o false que valida si cumple con las condiciones de contenido
   * @throws ErrorGeneralException error general cuando no cumple con ninguna condición evaluada
   */
  MensajeValidacionesControlDTO validarNit(String nit, String nombreArchivo)
      throws ErrorGeneralException;
}
