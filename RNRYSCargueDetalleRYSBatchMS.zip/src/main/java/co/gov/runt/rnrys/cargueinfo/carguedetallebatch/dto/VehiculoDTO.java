package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto;

import co.gov.runt.rnrys.cargueinfo.core.consultas.dto.DetalleCargueVehiculoRequest;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.AutomotorEntity;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.RaDeclimportEntity;
import lombok.Getter;
import lombok.Setter;

/** Clase VehiculoDTO para ejecución del batch */
@Getter
@Setter
public class VehiculoDTO extends DetalleCargueVehiculoRequest {
  private boolean declaracionManual;
  private boolean declaracionManualNE;
  private boolean insertDeclaracionImport;
  private RaDeclimportEntity declimportEntity;
  private AutomotorEntity automotorEntity;
  private String tipoDocumentoImportador;
  private String numDocumentoImportador;

  private boolean fallidoValEstruContenido;
}
