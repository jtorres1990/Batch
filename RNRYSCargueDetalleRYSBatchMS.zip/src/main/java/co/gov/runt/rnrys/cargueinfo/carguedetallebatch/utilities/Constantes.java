package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.utilities;

/**
 * Clase donde se definen las constantes que se van a utilizar en la lógica y peticiones del
 * aplicativo web.
 *
 * @since 1.0.0
 */
public final class Constantes {

  /** Path batch */
  public static final String PATH_BATCH = "batch";

  /** Path ejecutar tarea */
  public static final String PATH_EJECUTAR_TAREA = "ejecutarTarea";

  /** Constante de identificador de la solicitud */
  public static final String SOLICITUD_ID = "solicitudId";

  /** Constante de registros fallidos */
  public static final String REGISTROS_FALLIDOS = "regFallidosValEstruContenido";

  /** Constante de registros fallidos */
  public static final String REGISTROS_INCONSISTENTES = "regInconsistentes";

  /** Constante de registros exitosos */
  public static final String REGISTROS_EXITOSOS = "registrosExitosos";

  /** Constante de registros guardados */
  public static final String REGISTROS_GUARDADOS = "registrosGuardados";

  /** Constante de ruta del archivo */
  public static final String RUTA_ARCHIVO = "rutaArchivo";

  /** Constante de ruta de total de registros */
  public static final String TOTAL_REGISTROS = "totalRegistros";

  /** Constante de fecha de corte */
  public static final String FECHA_CORTE = "fechaCorte";

  /** Constante de nombre del archivo */
  public static final String NOMBREARCHIVO = "nombreArchivo";

  /** Constante de nit */
  public static final String NIT = "nit";

  /** Constante de Autoridad */
  public static final String IDAUTORIDAD = "idAutoridad";

  /** Constante de Empresa */
  public static final String IDEMPRESA = "idEmpresa";

  /** Constante de Usuario */
  public static final String IDUSUARIO = "idUsuario";

  /** Constante de ip del usuario */
  public static final String IPUSUARIO = "ipUsuario";

  /** Plantilla */
  public static final String PLANTILLA_GENERICA_RUNT_2 = "PLANTILLA_GENERICA_RUNT_2";

  /** Tipo correo */
  public static final String TIPO_CORREO = "ServiciosCiudadanoMailSession";

  /** Asunto */
  public static final String ASUNTO =
      "Finalización procesamiento cargue detalle de remolque o semiremolque";

  /** Constante de lista fallidos */
  public static final String LISTA_INCONSISTENTES = "listaInconsistentes";

  /** Resultado */
  public static final String TITULO = "Resultado cargue";

  /** Cuerpo */
  public static final String CUERPO =
      "Señor(es)<br><br> {0} <br><br>Confirmamos que la ejecución del cargue del archivo registrado"
          + " bajo el número de solicitud {1} el día {2} ya se finalizó y se encuentra disponible"
          + " para consultar el resultado de este.";

  /** The constant CORREOS. */
  public static final String CORREOS = "correos";

  /** Constante de contador de filas leidas */
  public static final String CONTADOR_FILAS = "contadorFilas";

  /** Constante de lista fallidos */
  public static final String LISTA_VIN_EXISTE = "listaVinExiste";

  /** Constante de lista fallidos */
  public static final String LISTA_REPETIDOS = "listaRepetidos";
  /** Constante de nombre del archivo */
  public static final String NOMBRE_USUARIO = "nombreUsuario";

  private Constantes() {
    throw new IllegalStateException("Clase de constantes");
  }
}
