package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.AutomotorEntity;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import java.util.List;

/**
 * Interfaz con todos los métodos disponibles para las validaciones comunes del cargue.
 *
 * @since 1.0.0
 */
public interface IValidacionesComunesService {

  /**
   * Método para validar motor, chasis y marca del automotor.
   *
   * @param vehiculoDTO DTO con la informacion para el cargue.
   * @param nombreArchivo Nombre del archivo.
   * @throws ErrorGeneralException error general cuando no cumple con ninguna condición evaluada.
   */
  void validarMotorChasisMarca(VehiculoDTO vehiculoDTO, String nombreArchivo)
      throws ErrorGeneralException;

  /**
   * Método para obtener el automotor por vin.
   *
   * @param vehiculoDTO DTO con la informacion para el cargue.
   * @param nombreArchivo Nombre del archivo.
   * @return AutomotorEntity automotor entity
   * @throws ErrorGeneralException error general cuando no cumple con ninguna condición evaluada.
   */
  AutomotorEntity obtenerAutomotorPorVin(VehiculoDTO vehiculoDTO, String nombreArchivo)
      throws ErrorGeneralException;

  /**
   * Método para obtener el automotor por linea, marca, chasis, motor, serie y vin.
   *
   * @param vehiculoDTO DTO con la informacion para el cargue.
   * @return Lista de AutomotorEntity
   */
  List<AutomotorEntity> obtenerAutomotorPorLineaMarcaGuarismos(VehiculoDTO vehiculoDTO);
}
