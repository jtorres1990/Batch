package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service;

import co.gov.runt.utilidades.exception.ErrorGeneralException;

/**
 * Interfaz funcional para ejecutar validaciones y capturar la excepción Para este caso todos los
 * fallos por validaciones deberian retornar una excepcion de tipo ErrorGeneralException
 */
@FunctionalInterface
public interface ConsumidorValidacion {
  /**
   * Método para la ejecución de las validaciones.
   *
   * @throws ErrorGeneralException error general cuando no cumple con ninguna condición evaluada.
   */
  void ejecutar() throws ErrorGeneralException;
}
