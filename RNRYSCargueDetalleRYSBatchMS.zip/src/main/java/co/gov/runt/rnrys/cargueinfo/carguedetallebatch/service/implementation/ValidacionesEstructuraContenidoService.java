package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.ConsumidorValidacion;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IValidacionesEstructuraContenidoService;
import co.gov.runt.rnrys.cargueinfo.validaciones.service.IValidacionesActaImportService;
import co.gov.runt.rnrys.cargueinfo.validaciones.service.IValidacionesDetalleService;
import co.gov.runt.rnrys.cargueinfo.validaciones.service.IValidacionesFthService;
import co.gov.runt.rnrys.cargueinfo.validaciones.service.IValidacionesLevanteService;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Clase que implementa las funcionalidades de la interfaz IValidacionesEstructuraContenidoService
 *
 * @since 1.0.0
 */
@Slf4j
@Service
@AllArgsConstructor
public class ValidacionesEstructuraContenidoService
    implements IValidacionesEstructuraContenidoService {

  private final IValidacionesDetalleService validacionesDetalleService;
  private final IValidacionesActaImportService validacionesActaImportService;
  private final IValidacionesFthService validacionesFthService;
  private final IValidacionesLevanteService validacionesLevanteService;

  @Override
  public List<String> ejecutarValidaciones(
      VehiculoDTO vehiculoDTO,
      String nit,
      String nombreArchivo,
      Long idAutoridad,
      Long solicitudId) {
    // Punto 8 y 9 del flujo básico: validaciones de estructura (F.A. 5.5) y contenido del archivo
    // (F.A. 5.6)
    log.info("Inicia proceso validaciones de estructura {}", vehiculoDTO);
    List<ConsumidorValidacion> validaciones =
        validarEstructuraContenido(vehiculoDTO, nit, idAutoridad, nombreArchivo);
    return ejecutarValidacion(validaciones);
  }

  /**
   * Método que toma una lista de objetos ConsumidorValidacion y ejecuta cada uno de ellos.
   *
   * @param validaciones Lista de tipo ConsumidorValidacion.
   * @return lista de mensajes de error o null.
   */
  private List<String> ejecutarValidacion(List<ConsumidorValidacion> validaciones) {
    return validaciones.stream()
        .map(
            validacion -> {
              try {
                validacion.ejecutar();
                return null;
              } catch (ErrorGeneralException ex) {
                log.info("Mensaje validacion ejecutada", ex);
                return ex.getMessage();
              } catch (Exception e) {
                log.info("Error ejecutando las validaciones: ", e);
                return "Error no controlado: ".concat(e.getMessage());
              }
            })
        .filter(Objects::nonNull)
        .toList();
  }

  /**
   * Método que realiza una serie de validaciones de estructura y contenido en un objeto VehiculoDTO
   * y retorna una lista de objetos ConsumidorValidacion.
   *
   * @param vehiculoDTO DTO con la informacion para el cargue.
   * @param nit Numero de identificación del ensamblador, importador o fabricante.
   * @param idAutoridad Identificador de la autoridad de tránsito.
   * @return lista de ConsumidorValidacion.
   */
  private List<ConsumidorValidacion> validarEstructuraContenido(
      VehiculoDTO vehiculoDTO, String nit, Long idAutoridad, String nombreArchivo) {

    List<ConsumidorValidacion> validaciones = new ArrayList<>();
    validaciones.add(() -> validacionesDetalleService.validarSecuencia(vehiculoDTO, nombreArchivo));
    validaciones.add(() -> validacionesDetalleService.validaTipoCargue(vehiculoDTO, nombreArchivo));
    validarTipoRegistro(validaciones, vehiculoDTO, nombreArchivo);
    validaciones.add(
        () -> validacionesDetalleService.validaNumeroCertificado(vehiculoDTO, nit, nombreArchivo));
    validaciones.add(
        () -> validacionesDetalleService.validaNumeroSerie(vehiculoDTO, nombreArchivo));
    validarVin(validaciones, vehiculoDTO, nombreArchivo);
    validaciones.add(() -> validacionesDetalleService.validarMarca(vehiculoDTO, nombreArchivo));
    validaciones.add(() -> validacionesDetalleService.validarLinea(vehiculoDTO, nombreArchivo));
    validaciones.add(() -> validacionesDetalleService.validarClase(vehiculoDTO, nombreArchivo));
    validaciones.add(() -> validacionesDetalleService.validarModelo(vehiculoDTO, nombreArchivo));
    validarFTH(validaciones, vehiculoDTO, nombreArchivo);
    validarEjes(validaciones, vehiculoDTO, nombreArchivo);
    validaciones.add(() -> validacionesFthService.validarAlto(vehiculoDTO, nombreArchivo));
    validaciones.add(() -> validacionesFthService.validarLargo(vehiculoDTO, nombreArchivo));
    validaciones.add(() -> validacionesFthService.validarAncho(vehiculoDTO, nombreArchivo));
    validaciones.add(() -> validacionesFthService.validarPesoTotal(vehiculoDTO, nombreArchivo));
    validaciones.add(() -> validacionesFthService.validarCargaUtil(vehiculoDTO, nombreArchivo));
    validaciones.add(() -> validacionesFthService.validarNumeroLlantas(vehiculoDTO, nombreArchivo));
    validaciones.add(
        () -> validacionesDetalleService.validarTiposCarroceria(vehiculoDTO, nombreArchivo));
    validaciones.add(
        () ->
            validacionesDetalleService.validaNumeroCondicionMovilidad(vehiculoDTO, nombreArchivo));
    validaciones.add(
        () -> validacionesDetalleService.validaNumeroDeclaracion(vehiculoDTO, nit, nombreArchivo));
    validaciones.add(
        () ->
            validacionesActaImportService.validarFechaAceptacion(
                vehiculoDTO, idAutoridad, nombreArchivo));
    validaciones.add(
        () -> validacionesLevanteService.validaNumeroLevante(vehiculoDTO, nit, nombreArchivo));
    validaciones.add(
        () -> validacionesLevanteService.validarFechaLevante(vehiculoDTO, nit, nombreArchivo));
    validaciones.add(
        () ->
            validacionesDetalleService.validaFechaCertificacionRemolque(
                vehiculoDTO, nit, nombreArchivo));
    validaciones.add(
        () -> validacionesDetalleService.validarOrigen(vehiculoDTO, nit, nombreArchivo));
    return validaciones;
  }

  /**
   * Método que valida la FTH.
   *
   * @param vehiculoDTO DTO con la informacion para el cargue.
   * @param validaciones Lista de tipo ConsumidorValidacion.
   */
  private void validarFTH(
      List<ConsumidorValidacion> validaciones, VehiculoDTO vehiculoDTO, String nombreArchivo) {
    validaciones.add(() -> validacionesFthService.validarFichaTecnica(vehiculoDTO, nombreArchivo));
    log.info("No aplica para validacion FTH");
  }

  /**
   * Método que valida el vin.
   *
   * @param vehiculoDTO DTO con la informacion para el cargue.
   * @param validaciones Lista de tipo ConsumidorValidacion.
   */
  private void validarVin(
      List<ConsumidorValidacion> validaciones, VehiculoDTO vehiculoDTO, String nombreArchivo) {
    validaciones.add(() -> validacionesDetalleService.validarVin(vehiculoDTO, nombreArchivo));
  }

  /**
   * Método que valida el tipo de registro.
   *
   * @param vehiculoDTO DTO con la informacion para el cargue.
   * @param validaciones Lista de tipo ConsumidorValidacion.
   */
  private void validarTipoRegistro(
      List<ConsumidorValidacion> validaciones, VehiculoDTO vehiculoDTO, String nombreArchivo) {
    validaciones.add(
        () -> validacionesDetalleService.validarTipoRegistro(vehiculoDTO, nombreArchivo));
  }

  /**
   * Método que valida los ejes.
   *
   * @param validaciones Lista de tipo ConsumidorValidacion.
   */
  private void validarEjes(
      List<ConsumidorValidacion> validaciones, VehiculoDTO vehiculoDTO, String nombreArchivo) {
    validaciones.add(() -> validacionesFthService.validarEjes(vehiculoDTO, nombreArchivo));
  }
}
