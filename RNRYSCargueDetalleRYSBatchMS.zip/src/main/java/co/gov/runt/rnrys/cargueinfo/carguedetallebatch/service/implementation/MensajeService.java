package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums.MensajesErrorEnum;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IMensajeService;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.MensajeEntity;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.repository.MensajeRepository;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * Recuperar mensajes
 *
 * @since 1.0.0
 */
@Service
@AllArgsConstructor
public class MensajeService implements IMensajeService {

  private final MensajeRepository mensajeRepository;

  @Override
  public MensajeEntity obtenerMensaje(MensajesErrorEnum mensajesErrorEnum)
      throws ErrorGeneralException {
    return mensajeRepository
        .findById(mensajesErrorEnum.name())
        .orElseThrow(() -> new ErrorGeneralException("No se encontró el mensaje parametrizado"));
  }
}
