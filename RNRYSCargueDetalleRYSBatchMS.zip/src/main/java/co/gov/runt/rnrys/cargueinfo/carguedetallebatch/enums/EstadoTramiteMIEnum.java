package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/** Enum que representa los estados del trámite de matrícula inicial */
@Getter
@AllArgsConstructor
public enum EstadoTramiteMIEnum {
  /** Estado trámite Aprobado */
  APROBADO("APROBADO");

  private final String id;
}
