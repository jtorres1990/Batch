package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.utilities;

import java.time.Duration;
import java.util.Iterator;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.*;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.metrics.BatchMetrics;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.task.SyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.core.task.TaskRejectedException;
import org.springframework.util.Assert;

/**
 * Clase responsables de iniciar los jobs con determinados parámetros.
 *
 * @since 1.0.0
 */
@Setter
@Slf4j
@NoArgsConstructor
public class SimpleJobLauncherRuntCargue implements JobLauncher, InitializingBean {

  private JobRepository jobRepository;
  private TaskExecutor taskExecutor;
  private ThreadServiceCargue threadService;

  @SuppressWarnings("squid:S3740")
  public JobExecution run(final Job job, final JobParameters jobParameters)
      throws JobExecutionAlreadyRunningException, JobRestartException,
          JobInstanceAlreadyCompleteException, JobParametersInvalidException {
    Assert.notNull(job, "The Job must not be null.");
    Assert.notNull(jobParameters, "The JobParameters must not be null.");
    JobExecution lastExecution =
        this.jobRepository.getLastJobExecution(job.getName(), jobParameters);
    if (lastExecution != null) {
      if (!job.isRestartable()) {
        throw new JobRestartException("JobInstance already exists and is not restartable");
      }

      Iterator var5 = lastExecution.getStepExecutions().iterator();

      while (var5.hasNext()) {
        StepExecution execution = (StepExecution) var5.next();
        BatchStatus status = execution.getStatus();
        if (status.isRunning() || status == BatchStatus.STOPPING) {
          throw new JobExecutionAlreadyRunningException(
              "A job execution for this job is already running: " + lastExecution);
        }

        if (status == BatchStatus.UNKNOWN) {
          throw new JobRestartException(
              "Cannot restart step ["
                  + execution.getStepName()
                  + "] from UNKNOWN status. The last execution ended with a failure that could "
                  + "not be rolled back, so it may "
                  + "be dangerous to proceed. Manual intervention is probably necessary.");
        }
      }
    }
    return jobValidation(job, jobParameters);
  }

  private JobExecution jobValidation(Job job, JobParameters jobParameters)
      throws JobExecutionAlreadyRunningException, JobRestartException,
          JobInstanceAlreadyCompleteException, JobParametersInvalidException {
    job.getJobParametersValidator().validate(jobParameters);
    final JobExecution jobExecution =
        this.jobRepository.createJobExecution(job.getName(), jobParameters);
    try {
      this.taskExecutor.execute(
          threadService.executeOnThread(
              () -> {
                log.info(
                    "Job: ["
                        + job
                        + "] launched with the following parameters: ["
                        + jobParameters
                        + "]");
                job.execute(jobExecution);
                Duration jobExecutionDuration =
                    BatchMetrics.calculateDuration(
                        jobExecution.getStartTime(), jobExecution.getEndTime());
                log.info(
                    "Job: ["
                        + job
                        + "] completed with the following parameters: ["
                        + jobParameters
                        + "] and the following status: ["
                        + jobExecution.getStatus()
                        + "]"
                        + (jobExecutionDuration == null
                            ? ""
                            : " in " + BatchMetrics.formatDuration(jobExecutionDuration)));
              },
              jobParameters));
    } catch (TaskRejectedException e) {
      log.info("Entro al catch del la tarea");
      jobExecution.upgradeStatus(BatchStatus.FAILED);
      if (jobExecution.getExitStatus().equals(ExitStatus.UNKNOWN)) {
        jobExecution.setExitStatus(ExitStatus.FAILED.addExitDescription(e));
      }
      jobRepository.update(jobExecution);
    }
    return jobExecution;
  }

  public void afterPropertiesSet() throws Exception {
    Assert.state(this.jobRepository != null, "A JobRepository has not been set.");
    if (this.taskExecutor == null) {
      log.info("No TaskExecutor has been set, defaulting to synchronous executor.");
      this.taskExecutor = new SyncTaskExecutor();
    }
  }
}
