package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service;

import co.gov.runt.rna.rnacarguearchivosapiclient.jpa.entity.SolicitudCargueEntity;
import co.gov.runt.utilidades.exception.ElementoNoEncontradoException;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import java.io.IOException;
import java.util.concurrent.ExecutionException;
import org.springframework.batch.core.JobExecution;

/** Interfaz para la gestión del servicio de BatchJobProcesor. */
public interface IBatchJobProcesorService {

  /**
   * Método para dar la solicitud
   *
   * @param pExecution objeto job de ejecución
   * @return valor de tipo {@link Long}
   */
  Long darIdSolicitud(JobExecution pExecution);

  /**
   * Método para obtener el total de registros.
   *
   * @param pExecution objeto job de ejecución
   * @return valor de tipo {@link Long}
   */
  String obtenerTotalRegistros(JobExecution pExecution);

  /**
   * Método para cambiar el estado inicial
   *
   * @param solicitud objeto con la entidad de la solicitud
   * @throws ElementoNoEncontradoException cuando no se encuentra la solicitud
   */
  void cambiarEstadoInicial(SolicitudCargueEntity solicitud) throws ElementoNoEncontradoException;

  /**
   * Actualizar BatchSolicitudCargueEntity
   *
   * @param solicitudId identificador de la solicitud
   * @param job objeto Job de la solicitud
   * @param estado estado de la solicitud
   */
  void actualizarBatchService(Long solicitudId, Long job, String estado);

  /**
   * Metodo que procesa la finalización de la tarea
   *
   * @param pExecution objeto job de ejecución
   * @throws ElementoNoEncontradoException cuando no se encuentra el Job
   * @throws IOException cuando no puede guardar/leer archivo
   * @throws ExecutionException cuando no se puede ejecutar Batch
   * @throws ErrorGeneralException the error general exception
   */
  void procesarFinalizacionJob(JobExecution pExecution)
      throws ElementoNoEncontradoException, IOException, ExecutionException, ErrorGeneralException;
}
