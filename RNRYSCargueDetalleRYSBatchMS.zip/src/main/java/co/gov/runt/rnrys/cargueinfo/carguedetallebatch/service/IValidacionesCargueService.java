package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.EjecutarValidacionesRequest;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.utilidades.exception.ErrorGeneralException;

/**
 * Interfaz con todos los métodos disponibles para la ejecución de las validaciones del cargue.
 *
 * @since 1.0.0
 */
public interface IValidacionesCargueService {

  /**
   * Método para orquestar la ejecución de las validaciones.
   *
   * @param request DTO con la informacion para procesar las validaciones.
   * @return VehiculoDTO vehiculo dto
   */
  VehiculoDTO ejecutarValidaciones(
      EjecutarValidacionesRequest request, boolean inconsistente, boolean repetido)
      throws ErrorGeneralException;
}
