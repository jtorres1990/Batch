package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IValidacionesComunesService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IValidacionesDeclaImportService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IValidacionesModificacionService;
import co.gov.runt.rnrys.cargueinfo.core.consultas.enums.EstadoVehiculoEnum;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.AutomotorEntity;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Clase que implementa las funcionalidades de la interfaz IValidacionesModificacionService
 *
 * @since 1.0.0
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ValidacionesModificacionService implements IValidacionesModificacionService {

  private final IValidacionesComunesService validacionesComunesService;
  private final IValidacionesDeclaImportService validacionesDeclaImportService;

  @Override
  public void validarModificacion(
      VehiculoDTO vehiculoDTO,
      String nit,
      String nombreArchivo,
      Long idAutoridad,
      Long idEmpresa,
      String idUsuario)
      throws ErrorGeneralException {
    // 3. El sistema identifica que, para el registro a modificar relacionaron el número de VIN (se
    // sabe al momento de validar contenido y estructura)
    if (Objects.isNull(vehiculoDTO.getVin()) || vehiculoDTO.getVin().isEmpty()) {
      // 5.11
      validacionesComunesService.validarMotorChasisMarca(vehiculoDTO, nombreArchivo);
    }

    AutomotorEntity automotorEntity =
        validacionesComunesService.obtenerAutomotorPorVin(vehiculoDTO, nombreArchivo);

    validarEstado(automotorEntity);

    // 12. El sistema retorna al paso 14 del flujo básico de eventos.
    validacionesDeclaImportService.validacionesDeclaracionImport(
        vehiculoDTO, nit, idAutoridad, idEmpresa, idUsuario, nombreArchivo);

    vehiculoDTO.setAutomotorEntity(automotorEntity);
  }

  private void validarEstado(AutomotorEntity automotor) throws ErrorGeneralException {
    if (!automotor.getEstado().equals(EstadoVehiculoEnum.REGISTRADO.name())) {
      throw new ErrorGeneralException(
          "No se pudo registrar la modificación porque el vehículo a modificar ya tiene un trámite"
              + " de matrícula inicial aprobado");
    }
  }
}
