package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.jpa.repository;

import co.gov.runt.rna.rnacarguearchivosapiclient.jpa.entity.SolicitudCargueEntity;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 * Repositorio que contiene todas las operaciones necesarias para gestionar la entidad
 * SolicitudesCargueEntity.
 */
@Repository
public interface SolicitudesCargueRepository extends JpaRepository<SolicitudCargueEntity, Long> {

  /**
   * Método para obtener las solicitudes pendientes de cargue de detalle vehículo
   *
   * @param idTipoArchivo identificador de tipo de archivo
   * @return List<SolicitudesCargueEntity> lista de solicitudes de cargue pendientes
   */
  @Query(
      value =
          """
                            SELECT cs.* FROM RUNTPROD.CAR_SOLICARGU cs
                            INNER JOIN RUNTPROD.CAR_ESTADOS ce ON ce.ESTADOS_ID = cs.SOLICARGU_ESTADOS_ID
                            WHERE 1=1
                            AND ce.ESTADOS_ID = 1
                            AND cs.SOLICARGU_TIPOARCHI_ID = :idTipoArchivo


                                      """,
      nativeQuery = true)
  List<SolicitudCargueEntity> findSoliCargueByIdTipoArchivoAndEstado(Long idTipoArchivo);
}
