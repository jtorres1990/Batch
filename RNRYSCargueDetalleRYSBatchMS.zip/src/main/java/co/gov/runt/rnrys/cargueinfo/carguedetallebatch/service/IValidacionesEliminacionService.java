package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.utilidades.exception.ErrorGeneralException;

/**
 * Interfaz con todos los métodos disponibles para las validaciones de eliminacion.
 *
 * @since 1.0.0
 */
public interface IValidacionesEliminacionService {

  /**
   * Método para validar cuando el tipo de cargue es eliminacion.
   *
   * @param vehiculoDTO DTO con la informacion para el cargue.
   * @throws ErrorGeneralException error general cuando no cumple con ninguna condición evaluada
   */
  void validarEliminacion(VehiculoDTO vehiculoDTO, String nombreArchivo)
      throws ErrorGeneralException;
}
