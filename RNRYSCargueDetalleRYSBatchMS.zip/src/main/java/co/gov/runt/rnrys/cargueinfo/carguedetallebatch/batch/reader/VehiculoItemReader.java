package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.batch.reader;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.batch.model.ColumnNames;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.Objects;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;

/**
 * Clase encargada de leer los datos del archivo que tienen que ver con la informacion del vehiculo.
 */
@Slf4j
@Component
public class VehiculoItemReader extends FlatFileItemReader<VehiculoDTO> {
  private static final String PIPE = "|";
  /**
   * Metodo que obtiene los parametro necesario para la lectura del archivo y manejo de variables de
   * la ejecución
   *
   * @param stepExecution the step execution
   */
  @BeforeStep
  public void beforeStep(StepExecution stepExecution) {
    log.info("Configurando ruta del archivo");

    JobParameters parametros = stepExecution.getJobExecution().getJobParameters();
    String rutaArchivo = parametros.getString("rutaArchivo");

    log.info("Archivo a procesar {}", rutaArchivo);
    if (Objects.nonNull(rutaArchivo)) {
      setResource(new FileSystemResource(Paths.get(rutaArchivo).toString()));
    } else {
      log.error("Ruta del archivo null");
    }
  }

  /** Metodo que lee las detalles de vehículo del archivo */
  public VehiculoItemReader() {
    setName("vehiculoReader");
    setLinesToSkip(1);
    setLineMapper(getLineMapper());
    setEncoding(StandardCharsets.UTF_8.name());
  }

  /**
   * Metodo que devuelve el mapeo de las lineas del archivo a objetos VehiculoDTO en un paso de
   * procesamiento por lotes.
   */
  private LineMapper<VehiculoDTO> getLineMapper() {
    DefaultLineMapper<VehiculoDTO> lineMapper = new DefaultLineMapper<>();
    DelimitedLineTokenizer tokenizer = new DelimitedLineTokenizer();
    tokenizer.setNames(ColumnNames.getColumnNames());
    tokenizer.setIncludedFields(ColumnNames.getFields());

    BeanWrapperFieldSetMapper<VehiculoDTO> fieldSetMapper = new BeanWrapperFieldSetMapper<>();
    fieldSetMapper.setTargetType(VehiculoDTO.class);
    lineMapper.setLineTokenizer(tokenizer);
    lineMapper.setFieldSetMapper(fieldSetMapper);
    tokenizer.setDelimiter(PIPE);
    tokenizer.setStrict(false);
    return lineMapper;
  }
}
