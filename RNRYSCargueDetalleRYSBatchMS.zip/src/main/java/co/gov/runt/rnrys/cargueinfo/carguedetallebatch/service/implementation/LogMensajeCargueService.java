package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import co.gov.runt.rna.rnacarguearchivosapiclient.dto.LogMensajeDto;
import co.gov.runt.rna.rnacarguearchivosapiclient.service.ILogEstadoCargueService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums.TipoLogMensajeEnum;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.ILogMensajeCargueService;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Clase que implementa las funcionalidades de la interfaz ILogMensajeCargueService
 *
 * @since 1.0.0
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class LogMensajeCargueService implements ILogMensajeCargueService {

  private final ILogEstadoCargueService logEstadoCargueService;

  @Override
  public void guardarLog(String mensaje, Long solicitudId, String tipoLogMensaje) {
    try {
      logEstadoCargueService.registrarLogEstado(solicitudId, mensaje, tipoLogMensaje);
    } catch (Exception e) {
      log.error("Error al guardar el log de error: ", e);
    }
  }

  @Override
  public void guardarListaLog(
      List<String> mensajes, Long solicitudId, String secuencia, String archivoNombre) {
    List<LogMensajeDto> listaMensajes =
        mensajes.stream()
            .map(
                mensaje -> {
                  LogMensajeDto mensajeDto = new LogMensajeDto();
                  mensajeDto.setMensaje(mensaje);
                  mensajeDto.setTipoMensaje(TipoLogMensajeEnum.ERROR.getId());
                  log.error(
                      "Mensaje validacion a registrar:{} con el numero de solicitud: {}",
                      mensaje,
                      solicitudId);
                  return mensajeDto;
                })
            .toList();
    try {
      logEstadoCargueService.registrarLogsEstado(solicitudId, listaMensajes);
    } catch (Exception e) {
      log.error("Error al guardar el log de error: ", e);
    }
  }
}
