package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * DTO Respuesta para el proceso del cargue.
 *
 * @since 1.0.0
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class MensajeDTO {
  private boolean error;
  private String descripcion;
  private List<String> detalleErrores;
}
