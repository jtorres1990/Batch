/**
 * Paquete base del proyecto donde se encuentran las clases que realizan configuraciones a nivel
 * general del framework Spring Boot
 */
package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.batch.listener;
