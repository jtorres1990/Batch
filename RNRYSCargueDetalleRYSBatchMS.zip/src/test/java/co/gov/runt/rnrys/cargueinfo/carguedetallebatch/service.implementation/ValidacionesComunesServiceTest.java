package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.AutomotorEntity;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.MensajeEntity;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.repository.AutomotorRepository;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ValidacionesComunesServiceTest {

  @Mock AutomotorRepository automotorRepository;
  @Mock MensajeService mensajeService;

  @InjectMocks ValidacionesComunesService validacionesComunesService;

  @Test
  void validarMotorChasisMarcaTest() throws ErrorGeneralException {
    AutomotorEntity automotorEntity = new AutomotorEntity();
    automotorEntity.setNroVin("sdf123");
    Mockito.when(automotorRepository.findFiltered(Mockito.any()))
        .thenReturn(Collections.singletonList(automotorEntity));
    validacionesComunesService.obtenerAutomotorPorVin(new VehiculoDTO(), "");
  }

  @Test
  void obtenerAutomotorPorVin() {
    AutomotorEntity automotorEntity = new AutomotorEntity();
    automotorEntity.setNroVin("sdf123");
    MensajeEntity mensaje = new MensajeEntity();
    mensaje.setValor("sd");
    Mockito.when(automotorRepository.findFiltered(Mockito.any())).thenReturn(new ArrayList<>());

    Exception exception =
        Assertions.assertThrows(
            ErrorGeneralException.class,
            () -> validacionesComunesService.obtenerAutomotorPorVin(new VehiculoDTO(), ""));

    Assertions.assertNotNull(exception.getMessage());
  }

  @Test
  void validarMotorChasisMarcaErrorTest() throws ErrorGeneralException {
    AutomotorEntity automotorEntity = new AutomotorEntity();
    automotorEntity.setNroVin("");
    MensajeEntity mensaje = new MensajeEntity();
    mensaje.setValor("sd");
    Mockito.when(mensajeService.obtenerMensaje(Mockito.any())).thenReturn(mensaje);
    Mockito.when(automotorRepository.findFiltered(Mockito.any()))
        .thenReturn(Collections.singletonList(automotorEntity));
    VehiculoDTO vehiculoDTO = new VehiculoDTO();
    vehiculoDTO.setMarca("1");
    Exception exception =
        Assertions.assertThrows(
            ErrorGeneralException.class,
            () -> validacionesComunesService.validarMotorChasisMarca(vehiculoDTO, ""));

    Assertions.assertNotNull(exception.getMessage());
  }

  @Test
  void validarMotorChasisMarcaErrorVinNullTest() throws ErrorGeneralException {
    AutomotorEntity automotorEntity = new AutomotorEntity();
    automotorEntity.setNroVin(null);
    MensajeEntity mensaje = new MensajeEntity();
    mensaje.setValor("sd");
    Mockito.when(mensajeService.obtenerMensaje(Mockito.any())).thenReturn(mensaje);
    Mockito.when(automotorRepository.findFiltered(Mockito.any()))
        .thenReturn(Collections.singletonList(automotorEntity));
    VehiculoDTO vehiculoDTO = new VehiculoDTO();
    vehiculoDTO.setMarca("1");
    Exception exception =
        Assertions.assertThrows(
            ErrorGeneralException.class,
            () -> validacionesComunesService.validarMotorChasisMarca(vehiculoDTO, ""));

    Assertions.assertNotNull(exception.getMessage());
  }

  @Test
  void validarMotorChasisMarcaErrorVinVacioTest() throws ErrorGeneralException {
    AutomotorEntity automotorEntity = new AutomotorEntity();
    automotorEntity.setNroVin(" ");
    MensajeEntity mensaje = new MensajeEntity();
    mensaje.setValor("sd");
    Mockito.when(mensajeService.obtenerMensaje(Mockito.any())).thenReturn(mensaje);
    Mockito.when(automotorRepository.findFiltered(Mockito.any()))
        .thenReturn(Collections.singletonList(automotorEntity));
    VehiculoDTO vehiculoDTO = new VehiculoDTO();
    vehiculoDTO.setMarca("1");
    Exception exception =
        Assertions.assertThrows(
            ErrorGeneralException.class,
            () -> validacionesComunesService.validarMotorChasisMarca(vehiculoDTO, ""));

    Assertions.assertNotNull(exception.getMessage());
  }

  @Test
  void validarMotorChasisMarcaErrorVinNullSTest() throws ErrorGeneralException {
    Mockito.when(automotorRepository.findFiltered(Mockito.any())).thenReturn(null);
    VehiculoDTO vehiculoDTO = new VehiculoDTO();
    vehiculoDTO.setMarca("1");
    validacionesComunesService.validarMotorChasisMarca(vehiculoDTO, "");
  }

  @Test
  void obtenerAutomotorPorLineaMarcaGuarismos() {
    VehiculoDTO vehiculoDTO = new VehiculoDTO();
    vehiculoDTO.setMarca("1");
    vehiculoDTO.setVin("1");
    vehiculoDTO.setLinea("1");
    AutomotorEntity automotorEntity = new AutomotorEntity();
    automotorEntity.setNroVin(" ");
    Mockito.when(automotorRepository.findFiltered(Mockito.any()))
        .thenReturn(Collections.singletonList(automotorEntity));
    List<AutomotorEntity> automotorEntities =
        validacionesComunesService.obtenerAutomotorPorLineaMarcaGuarismos(vehiculoDTO);

    Assertions.assertNotNull(automotorEntities);
  }
}
