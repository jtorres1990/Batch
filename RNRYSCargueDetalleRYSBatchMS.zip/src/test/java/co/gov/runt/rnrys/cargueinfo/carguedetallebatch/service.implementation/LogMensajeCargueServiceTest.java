package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import static org.mockito.Mockito.*;

import co.gov.runt.rna.rnacarguearchivosapiclient.service.ILogEstadoCargueService;
import co.gov.runt.utilidades.exception.ElementoNoEncontradoException;
import java.util.Collections;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

/** The type Log mensaje cargue service test. */
@Slf4j
@ExtendWith(MockitoExtension.class)
class LogMensajeCargueServiceTest {

  @InjectMocks private LogMensajeCargueService logMensajeCargueService;
  @Mock private ILogEstadoCargueService logEstadoCargueService;

  /**
   * Guardar log exitoso.
   *
   * @param idSolicitud the id solicitud
   * @param mensaje the mensaje
   * @param tipoMensaje the tipo mensaje
   * @throws Exception the exception
   */
  @ParameterizedTest
  @CsvSource({"1, 1, nombre"})
  @DisplayName("Guardar Log exitoso")
  void guardarLogExitoso(Long idSolicitud, String mensaje, String tipoMensaje) throws Exception {
    logMensajeCargueService.guardarLog(mensaje, idSolicitud, tipoMensaje);

    Mockito.verify(logEstadoCargueService)
        .registrarLogEstado(Mockito.any(), Mockito.any(), Mockito.any());
  }

  @Test
  void guardarLogErrorTest() throws Exception {

    doThrow(new ElementoNoEncontradoException("Mensaje de la excepción"))
        .when(logEstadoCargueService)
        .registrarLogEstado(anyLong(), anyString(), anyString());

    logMensajeCargueService.guardarLog("", 12L, "");
  }

  @Test
  void guardarListaLogExitosoTest() throws Exception {

    logMensajeCargueService.guardarListaLog(Collections.singletonList("Error"), 12L, "", "");

    Mockito.verify(logEstadoCargueService).registrarLogsEstado(Mockito.any(), Mockito.anyList());
  }

  @Test
  void guardarListaLogErrorTest() throws Exception {

    doThrow(new ElementoNoEncontradoException("Mensaje de la excepción"))
        .when(logEstadoCargueService)
        .registrarLogsEstado(anyLong(), Mockito.anyList());

    logMensajeCargueService.guardarListaLog(Collections.singletonList("Error"), 12L, "", "");
  }
}
