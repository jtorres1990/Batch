package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.MensajeValidacionesControlDTO;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IMensajeService;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.MensajeEntity;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.PersonaEntity;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.repository.PersonaRepository;
import co.gov.runt.rnrys.cargueinfo.validaciones.service.implementation.DependeciasManager;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ValidacionesControlServiceTest {

  @Mock DependeciasManager dependeciasManager;

  @Mock PersonaRepository personaRepository;

  @Mock IMensajeService mensajeService;

  @InjectMocks ValidacionesControlService validacionesControlService;

  @Test
  void validaNumeroRegistrosTest() throws ErrorGeneralException {
    MensajeValidacionesControlDTO mensajeValidacionesControlDTO =
        validacionesControlService.validaNumeroRegistros("5");
    Assertions.assertFalse(mensajeValidacionesControlDTO.isError());
  }

  @Test
  void validaNumeroRegistrosErrorTest() throws ErrorGeneralException {
    MensajeEntity mensaje = new MensajeEntity();
    mensaje.setValor("sd");
    Mockito.when(mensajeService.obtenerMensaje(Mockito.any())).thenReturn(mensaje);
    MensajeValidacionesControlDTO mensajeValidacionesControlDTO =
        validacionesControlService.validaNumeroRegistros("99999999");

    Assertions.assertTrue(mensajeValidacionesControlDTO.isError());
  }

  @Test
  void validaFechaCorteErrorTest() throws ErrorGeneralException {
    MensajeEntity mensaje = new MensajeEntity();
    mensaje.setValor("sd");
    Mockito.when(mensajeService.obtenerMensaje(Mockito.any())).thenReturn(mensaje);
    MensajeValidacionesControlDTO mensajeValidacionesControlDTO =
        validacionesControlService.validaFechaCorte("18000101");

    Assertions.assertTrue(mensajeValidacionesControlDTO.isError());
  }

  @Test
  void validaFechaCorteTest() throws ErrorGeneralException {
    MensajeEntity mensaje = new MensajeEntity();
    mensaje.setValor("sd");
    MensajeValidacionesControlDTO mensajeValidacionesControlDTO =
        validacionesControlService.validaFechaCorte("20240520");

    Assertions.assertFalse(mensajeValidacionesControlDTO.isError());
  }

  @Test
  void validaExpresionLineaErrorTest() {
    boolean validaExpresionLinea = validacionesControlService.validaExpresionLinea("20240520");
    Assertions.assertFalse(validaExpresionLinea);
  }

  @Test
  void validaExpresionLineaTest() {
    boolean validaExpresionLinea =
        validacionesControlService.validaExpresionLinea(
            "1|C|L||SER45REPLC22022024|VYN45REPL22022029|1|1|24|2012||3|6500|4500|5500|9500|10000|12|69|NORMAL||10092019||10092019||I");
    Assertions.assertTrue(validaExpresionLinea);
  }

  @Test
  void validarNitTest() throws ErrorGeneralException {
    MensajeEntity mensaje = new MensajeEntity();
    mensaje.setValor("sd");

    Mockito.when(dependeciasManager.getPersonaRepository()).thenReturn(personaRepository);
    Mockito.when(personaRepository.getImportadorEnsambladorByNit(Mockito.any()))
        .thenReturn(Optional.of(new PersonaEntity()));

    MensajeValidacionesControlDTO mensajeValidacionesControlDTO =
        validacionesControlService.validarNit("1030649630", "");

    Assertions.assertFalse(mensajeValidacionesControlDTO.isError());
  }

  @Test
  void validarNitErrorTest() throws ErrorGeneralException {
    MensajeEntity mensaje = new MensajeEntity();
    mensaje.setValor("sd");
    Mockito.when(mensajeService.obtenerMensaje(Mockito.any())).thenReturn(mensaje);
    Mockito.when(dependeciasManager.getPersonaRepository()).thenReturn(personaRepository);
    Mockito.when(personaRepository.getImportadorEnsambladorByNit(Mockito.any()))
        .thenReturn(Optional.empty());

    MensajeValidacionesControlDTO mensajeValidacionesControlDTO =
        validacionesControlService.validarNit("1030649630", "");

    Assertions.assertTrue(mensajeValidacionesControlDTO.isError());
  }
}
