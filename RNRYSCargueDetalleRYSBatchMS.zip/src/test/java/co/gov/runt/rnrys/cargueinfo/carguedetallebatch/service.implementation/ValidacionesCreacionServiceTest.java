package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IMensajeService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IValidacionesComunesService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IValidacionesDeclaImportService;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.AutomotorEntity;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.MensajeEntity;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.RpServicioEntity;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.repository.RpServicioRepository;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import java.util.Collections;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ValidacionesCreacionServiceTest {

  @InjectMocks ValidacionesCreacionService validacionesCreacionService;

  @Mock IValidacionesDeclaImportService validacionesDeclaImportService;
  @Mock IValidacionesComunesService validacionesComunesService;
  @Mock RpServicioRepository rpServicioRepository;
  @Mock IMensajeService iMensajeService;

  @Test
  void validarCreacionExitosoTest() throws ErrorGeneralException {
    VehiculoDTO vehiculoDTO = new VehiculoDTO();
    vehiculoDTO.setOrigenVehiculo("E");

    validacionesCreacionService.validarCreacion(vehiculoDTO, "", "", 12L, 12L, "");
    Mockito.verify(validacionesDeclaImportService)
        .validacionesDeclaracionImport(vehiculoDTO, "", 12L, 12L, "", "");
  }

  @Test
  void validarCreacionVehiculoExisteTest() {
    VehiculoDTO vehiculoDTO = new VehiculoDTO();
    vehiculoDTO.setOrigenVehiculo("E");
    Mockito.when(validacionesComunesService.obtenerAutomotorPorLineaMarcaGuarismos(Mockito.any()))
        .thenReturn(Collections.singletonList(new AutomotorEntity()));

    Exception exception =
        Assertions.assertThrows(
            ErrorGeneralException.class,
            () -> validacionesCreacionService.validarCreacion(vehiculoDTO, "", "", 12L, 12L, ""));
    Assertions.assertNotNull(exception.getMessage());
  }

  @Test
  void validarCreacionExitosoServicioTest() throws ErrorGeneralException {
    VehiculoDTO vehiculoDTO = new VehiculoDTO();
    vehiculoDTO.setOrigenVehiculo("N");
    Mockito.when(validacionesComunesService.obtenerAutomotorPorLineaMarcaGuarismos(Mockito.any()))
        .thenReturn(null);
    Mockito.when(rpServicioRepository.getImporEnsamFabByNumIden(Mockito.any()))
        .thenReturn(Optional.of(new RpServicioEntity()));

    validacionesCreacionService.validarCreacion(vehiculoDTO, "", "", 12L, 12L, "");
  }

  @Test
  void validarCreacionErrorServicioTest() throws ErrorGeneralException {
    VehiculoDTO vehiculoDTO = new VehiculoDTO();
    vehiculoDTO.setOrigenVehiculo("N");
    Mockito.when(validacionesComunesService.obtenerAutomotorPorLineaMarcaGuarismos(Mockito.any()))
        .thenReturn(null);
    Mockito.when(rpServicioRepository.getImporEnsamFabByNumIden(Mockito.any()))
        .thenReturn(Optional.empty());

    MensajeEntity mensaje = new MensajeEntity();
    mensaje.setValor("Error");
    Mockito.when(iMensajeService.obtenerMensaje(Mockito.any())).thenReturn(mensaje);

    Exception exception =
        Assertions.assertThrows(
            ErrorGeneralException.class,
            () -> validacionesCreacionService.validarCreacion(vehiculoDTO, "", "", 12L, 12L, ""));
    Assertions.assertNotNull(exception.getMessage());
  }
}
