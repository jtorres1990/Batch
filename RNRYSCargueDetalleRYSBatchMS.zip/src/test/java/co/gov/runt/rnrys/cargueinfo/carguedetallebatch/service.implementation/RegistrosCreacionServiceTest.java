package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IRegistrosComunService;
import co.gov.runt.rnrys.cargueinfo.core.registros.dto.RegistroRequest;
import co.gov.runt.rnrys.cargueinfo.core.registros.service.IRegistroCargueDetalleRnaService;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import co.gov.runt.utilidades.utilities.UtilidadesJson;
import com.fasterxml.jackson.core.type.TypeReference;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

/** The type Registros creacion service test. */
@Slf4j
@ExtendWith(MockitoExtension.class)
class RegistrosCreacionServiceTest {

  @InjectMocks private RegistrosCreacionService registrosCreacionService;
  @Mock private IRegistroCargueDetalleRnaService iRegistroCargueDetalleRnaService;
  @Mock private IRegistrosComunService iRegistrosComunService;

  private List<VehiculoDTO> vehiculoDTOList;

  /**
   * Sets .
   *
   * @throws ErrorGeneralException the error general exception
   */
  @BeforeEach
  void setup() throws ErrorGeneralException {
    vehiculoDTOList =
        UtilidadesJson.cargarJsonDesdeArchivo("vehiculoDTO.json", new TypeReference<>() {});
  }

  /**
   * Registrar cargue creacion.
   *
   * @param secuencia the secuencia
   * @throws ErrorGeneralException the error general exception
   */
  @ParameterizedTest
  @CsvSource({"10"})
  @DisplayName("Registrar Cargue Creacion")
  void registrarCargueCreacion(String secuencia) throws ErrorGeneralException {
    VehiculoDTO request =
        vehiculoDTOList.stream()
            .filter(vehiculo -> vehiculo.getSecuencia().equals(secuencia))
            .findFirst()
            .orElse(null);

    Mockito.when(
            iRegistrosComunService.crearRegistroRequest(
                Mockito.any(),
                Mockito.any(),
                Mockito.any(),
                Mockito.any(),
                Mockito.any(),
                Mockito.any()))
        .thenReturn(new RegistroRequest());

    registrosCreacionService.registrarCargueCreacion(
        request, "Nit", "Id Usuario", 1L, "Ip Usuario", 1L);

    Mockito.verify(iRegistroCargueDetalleRnaService).registroCargueDetalleVehiculo(Mockito.any());
    Mockito.verify(iRegistrosComunService)
        .crearRegistroRequest(
            Mockito.any(),
            Mockito.any(),
            Mockito.any(),
            Mockito.any(),
            Mockito.any(),
            Mockito.any());
  }
}
