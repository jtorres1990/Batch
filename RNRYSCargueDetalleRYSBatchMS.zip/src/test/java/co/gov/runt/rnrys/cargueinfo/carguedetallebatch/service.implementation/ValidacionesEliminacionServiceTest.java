package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.AutomotorEntity;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.repository.AutomotorRepository;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ValidacionesEliminacionServiceTest {

  @InjectMocks ValidacionesEliminacionService validacionesEliminacionService;

  @Mock AutomotorRepository automotorRepository;

  @Test
  void validarEliminacionExitosoTest() throws ErrorGeneralException {
    AutomotorEntity automotorEntity = new AutomotorEntity();
    automotorEntity.setEstado("REGISTRADO");
    VehiculoDTO vehiculoDTO = new VehiculoDTO();
    vehiculoDTO.setVin("12");
    vehiculoDTO.setMarca("1");
    vehiculoDTO.setNumeroSerieFabricacion("1");
    Mockito.when(
            automotorRepository.buscarAutomotorVinSerieMarca(
                Mockito.anyString(), Mockito.anyString(), Mockito.anyLong()))
        .thenReturn(Optional.of(automotorEntity));
    validacionesEliminacionService.validarEliminacion(vehiculoDTO, "");
  }

  @Test
  void validarEliminacionActivoTest() {
    AutomotorEntity automotorEntity = new AutomotorEntity();
    automotorEntity.setEstado("ACTIVO");
    VehiculoDTO vehiculoDTO = new VehiculoDTO();
    vehiculoDTO.setVin("12");
    vehiculoDTO.setMarca("1");
    vehiculoDTO.setNumeroSerieFabricacion("1");
    Mockito.when(
            automotorRepository.buscarAutomotorVinSerieMarca(
                Mockito.anyString(), Mockito.anyString(), Mockito.anyLong()))
        .thenReturn(Optional.of(automotorEntity));

    Exception exception =
        Assertions.assertThrows(
            ErrorGeneralException.class,
            () -> validacionesEliminacionService.validarEliminacion(vehiculoDTO, ""));
    Assertions.assertNotNull(exception.getMessage());
  }

  @Test
  void validarEliminacionEliminadoTest() {
    AutomotorEntity automotorEntity = new AutomotorEntity();
    automotorEntity.setEstado("ELIMINADO");
    VehiculoDTO vehiculoDTO = new VehiculoDTO();
    vehiculoDTO.setVin("12");
    vehiculoDTO.setMarca("1");
    vehiculoDTO.setNumeroSerieFabricacion("1");
    Mockito.when(
            automotorRepository.buscarAutomotorVinSerieMarca(
                Mockito.anyString(), Mockito.anyString(), Mockito.anyLong()))
        .thenReturn(Optional.of(automotorEntity));

    Exception exception =
        Assertions.assertThrows(
            ErrorGeneralException.class,
            () -> validacionesEliminacionService.validarEliminacion(vehiculoDTO, ""));
    Assertions.assertNotNull(exception.getMessage());
  }

  @Test
  void validarEliminacionNoExisteAutomotorTest() {
    AutomotorEntity automotorEntity = new AutomotorEntity();
    automotorEntity.setEstado("REGISTRADO");
    VehiculoDTO vehiculoDTO = new VehiculoDTO();
    vehiculoDTO.setVin("12");
    vehiculoDTO.setMarca("1");
    vehiculoDTO.setNumeroSerieFabricacion("1");
    Exception exception =
        Assertions.assertThrows(
            ErrorGeneralException.class,
            () -> validacionesEliminacionService.validarEliminacion(vehiculoDTO, ""));
    Assertions.assertNotNull(exception.getMessage());
  }
}
