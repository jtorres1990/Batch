package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import static org.mockito.Mockito.doThrow;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.rnrys.cargueinfo.validaciones.service.IValidacionesActaImportService;
import co.gov.runt.rnrys.cargueinfo.validaciones.service.IValidacionesDetalleService;
import co.gov.runt.rnrys.cargueinfo.validaciones.service.IValidacionesFthService;
import co.gov.runt.rnrys.cargueinfo.validaciones.service.IValidacionesLevanteService;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import java.util.List;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ValidacionesEstructuraContenidoServiceTest {

  @Mock IValidacionesDetalleService validacionesDetalleService;
  @Mock IValidacionesActaImportService validacionesActaImportService;
  @Mock IValidacionesFthService validacionesFthService;
  @Mock IValidacionesLevanteService validacionesLevanteService;

  @InjectMocks ValidacionesEstructuraContenidoService validacionesEstructuraContenidoService;

  @Test
  void ejecutarValidacionesTest() {

    List<String> strings =
        validacionesEstructuraContenidoService.ejecutarValidaciones(
            new VehiculoDTO(), "12", "sd", 12L, 12L);

    Assertions.assertNotNull(strings);
  }

  @Test
  void ejecutarValidacionesExceptionTest() throws ErrorGeneralException {

    doThrow(new ErrorGeneralException("Mensaje de la excepción"))
        .when(validacionesDetalleService)
        .validarSecuencia(Mockito.any(), Mockito.anyString());

    List<String> strings =
        validacionesEstructuraContenidoService.ejecutarValidaciones(
            new VehiculoDTO(), "12", "sd", 12L, 12L);

    Assertions.assertNotNull(strings);
  }

  @Test
  void ejecutarValidacionesExceptionNullTest() throws ErrorGeneralException {

    doThrow(new NullPointerException("Mensaje de la excepción"))
        .when(validacionesDetalleService)
        .validarSecuencia(Mockito.any(), Mockito.anyString());

    List<String> strings =
        validacionesEstructuraContenidoService.ejecutarValidaciones(
            new VehiculoDTO(), "12", "sd", 12L, 12L);

    Assertions.assertNotNull(strings);
  }
}
