package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import static org.mockito.Mockito.doThrow;

import co.gov.runt.rna.rnacarguearchivosapiclient.jpa.entity.SolicitudCargueEntity;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.utilities.FuncionesBatch;
import co.gov.runt.utilidades.exception.ElementoNoEncontradoException;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

/** The type Batch service test. */
@Slf4j
@ExtendWith(MockitoExtension.class)
class BatchServiceTest {

  @InjectMocks private BatchService batchService;
  @Mock private BatchJobProcesorService batchJobProcesorService;
  @Mock private FuncionesBatch funcionesBatch;

  /**
   * Ejecutar exitoso.
   *
   * @param idSolicitud the id solicitud
   * @param ruta the ruta
   * @throws ElementoNoEncontradoException the elemento no encontrado exception
   */
  @ParameterizedTest
  @CsvSource({"1, ruta"})
  @DisplayName("Ejecutar exitoso")
  void ejecutarExitoso(Long idSolicitud, String ruta) throws ElementoNoEncontradoException {
    SolicitudCargueEntity solicitudesCargueEntity = new SolicitudCargueEntity();
    solicitudesCargueEntity.setSolicitud(idSolicitud);

    Mockito.when(funcionesBatch.darRutaArchivo(Mockito.any())).thenReturn(ruta);

    batchService.ejecutar(solicitudesCargueEntity);
  }

  @Test
  void ejecutarError() throws ElementoNoEncontradoException {
    SolicitudCargueEntity solicitudesCargueEntity = new SolicitudCargueEntity();
    solicitudesCargueEntity.setSolicitud(1L);

    doThrow(new ElementoNoEncontradoException("Mensaje de la excepción"))
        .when(batchJobProcesorService)
        .cambiarEstadoInicial(Mockito.any());

    batchService.ejecutar(solicitudesCargueEntity);
  }
}
