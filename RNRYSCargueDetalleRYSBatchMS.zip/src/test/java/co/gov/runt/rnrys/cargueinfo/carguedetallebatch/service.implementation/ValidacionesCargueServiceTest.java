package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import static org.mockito.Mockito.doThrow;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.EjecutarValidacionesRequest;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.*;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import co.gov.runt.utilidades.utilities.UtilidadesJson;
import com.fasterxml.jackson.core.type.TypeReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

/** The type Validaciones cargue service test. */
@Slf4j
@ExtendWith(MockitoExtension.class)
class ValidacionesCargueServiceTest {

  @InjectMocks ValidacionesCargueService validacionesCargueService;
  @Mock ILogMensajeCargueService iLogMensajeCargueService;
  @Mock IValidacionesCreacionService iValidacionesCreacionService;
  @Mock IValidacionesEstructuraContenidoService iValidacionesEstructuraContenidoService;
  @Mock IValidacionesModificacionService iValidacionesModificacionService;
  @Mock ValidacionesEliminacionService validacionesEliminacionService;

  private List<VehiculoDTO> vehiculoDTOList;

  /**
   * Sets .
   *
   * @throws ErrorGeneralException the error general exception
   */
  @BeforeEach
  void setup() throws ErrorGeneralException {
    vehiculoDTOList =
        UtilidadesJson.cargarJsonDesdeArchivo("vehiculoDTO.json", new TypeReference<>() {});
  }

  /**
   * Ejecutar validaciones creacion.
   *
   * @param secuencia the secuencia
   * @param nit the nit
   * @param idSolicitud the id solicitud
   * @param idUsuario the id usuario
   * @throws ErrorGeneralException the error general exception
   */
  @ParameterizedTest
  @CsvSource({"12, 123456, 31, usuario"})
  @DisplayName("Ejecutar Validaciones Creación")
  void ejecutarValidacionesCreacion(
      String secuencia, String nit, Long idSolicitud, String idUsuario)
      throws ErrorGeneralException {
    VehiculoDTO request =
        vehiculoDTOList.stream()
            .filter(vehiculo -> vehiculo.getSecuencia().equals(secuencia))
            .findFirst()
            .orElse(null);

    EjecutarValidacionesRequest ejecutarValidacionesRequest = new EjecutarValidacionesRequest();
    ejecutarValidacionesRequest.setVehiculoDTO(request);
    ejecutarValidacionesRequest.setSolicitudId(idSolicitud);
    ejecutarValidacionesRequest.setNit(nit);
    ejecutarValidacionesRequest.setIdUsuario(idUsuario);
    ejecutarValidacionesRequest.setFallidoValEstruContenido(Boolean.FALSE);

    VehiculoDTO ejecutarValidaciones =
        validacionesCargueService.ejecutarValidaciones(ejecutarValidacionesRequest, false, false);

    Assertions.assertFalse(ejecutarValidaciones.isFallidoValEstruContenido());
  }

  @Test
  void ejecutarValidacionesCreacionErroresValidacion() throws ErrorGeneralException {
    Mockito.when(
            iValidacionesEstructuraContenidoService.ejecutarValidaciones(
                Mockito.any(),
                Mockito.anyString(),
                Mockito.anyString(),
                Mockito.anyLong(),
                Mockito.anyLong()))
        .thenReturn(Collections.singletonList("Error"));

    EjecutarValidacionesRequest ejecutarValidacionesRequest = new EjecutarValidacionesRequest();
    ejecutarValidacionesRequest.setVehiculoDTO(new VehiculoDTO());
    ejecutarValidacionesRequest.setSolicitudId(0L);
    ejecutarValidacionesRequest.setIdAutoridad(0L);
    ejecutarValidacionesRequest.setNit("");
    ejecutarValidacionesRequest.setNombreArchivo("");
    ejecutarValidacionesRequest.setFallidoValEstruContenido(Boolean.FALSE);

    VehiculoDTO ejecutarValidaciones =
        validacionesCargueService.ejecutarValidaciones(ejecutarValidacionesRequest, false, false);

    Assertions.assertTrue(ejecutarValidaciones.isFallidoValEstruContenido());
  }

  @Test
  void ejecutarValidacionesCreacionExcepcionValidacion() throws ErrorGeneralException {
    Mockito.when(
            iValidacionesEstructuraContenidoService.ejecutarValidaciones(
                Mockito.any(),
                Mockito.anyString(),
                Mockito.anyString(),
                Mockito.anyLong(),
                Mockito.anyLong()))
        .thenReturn(new ArrayList<>());

    doThrow(new ErrorGeneralException("Mensaje de la excepción"))
        .when(iValidacionesModificacionService)
        .validarModificacion(
            Mockito.any(),
            Mockito.anyString(),
            Mockito.anyString(),
            Mockito.anyLong(),
            Mockito.anyLong(),
            Mockito.any());

    VehiculoDTO vehiculoDTO = new VehiculoDTO();
    vehiculoDTO.setTipoCargue("M");
    vehiculoDTO.setSecuencia("1");

    EjecutarValidacionesRequest ejecutarValidacionesRequest = new EjecutarValidacionesRequest();
    ejecutarValidacionesRequest.setVehiculoDTO(vehiculoDTO);
    ejecutarValidacionesRequest.setSolicitudId(0L);
    ejecutarValidacionesRequest.setIdAutoridad(0L);
    ejecutarValidacionesRequest.setNit("");
    ejecutarValidacionesRequest.setNombreArchivo("");
    ejecutarValidacionesRequest.setFallidoValEstruContenido(Boolean.FALSE);

    VehiculoDTO ejecutarValidaciones =
        validacionesCargueService.ejecutarValidaciones(ejecutarValidacionesRequest, false, false);

    Assertions.assertTrue(ejecutarValidaciones.isFallidoValEstruContenido());
  }

  @Test
  void ejecutarValidacionesCreacionInconsistenteTest() throws ErrorGeneralException {

    VehiculoDTO vehiculoDTO = new VehiculoDTO();
    vehiculoDTO.setTipoCargue("M");
    vehiculoDTO.setSecuencia("1");

    EjecutarValidacionesRequest ejecutarValidacionesRequest = new EjecutarValidacionesRequest();
    ejecutarValidacionesRequest.setVehiculoDTO(vehiculoDTO);
    ejecutarValidacionesRequest.setSolicitudId(0L);
    ejecutarValidacionesRequest.setIdAutoridad(0L);
    ejecutarValidacionesRequest.setNit("");
    ejecutarValidacionesRequest.setNombreArchivo("");
    ejecutarValidacionesRequest.setFallidoValEstruContenido(Boolean.FALSE);

    VehiculoDTO ejecutarValidaciones =
        validacionesCargueService.ejecutarValidaciones(ejecutarValidacionesRequest, true, false);

    Assertions.assertTrue(ejecutarValidaciones.isFallidoValEstruContenido());
  }

  @Test
  void ejecutarValidacionesCreacionRepetidoTest() throws ErrorGeneralException {

    VehiculoDTO vehiculoDTO = new VehiculoDTO();
    vehiculoDTO.setTipoCargue("M");
    vehiculoDTO.setSecuencia("1");

    EjecutarValidacionesRequest ejecutarValidacionesRequest = new EjecutarValidacionesRequest();
    ejecutarValidacionesRequest.setVehiculoDTO(vehiculoDTO);
    ejecutarValidacionesRequest.setSolicitudId(0L);
    ejecutarValidacionesRequest.setIdAutoridad(0L);
    ejecutarValidacionesRequest.setNit("");
    ejecutarValidacionesRequest.setNombreArchivo("");
    ejecutarValidacionesRequest.setFallidoValEstruContenido(Boolean.FALSE);

    VehiculoDTO ejecutarValidaciones =
        validacionesCargueService.ejecutarValidaciones(ejecutarValidacionesRequest, false, true);

    Assertions.assertTrue(ejecutarValidaciones.isFallidoValEstruContenido());
  }

  @Test
  void ejecutarValidacionesCreacionRepetidoRegistroBlancoTest() throws ErrorGeneralException {

    VehiculoDTO vehiculoDTO = new VehiculoDTO();
    vehiculoDTO.setTipoCargue("M");
    vehiculoDTO.setSecuencia("");

    EjecutarValidacionesRequest ejecutarValidacionesRequest = new EjecutarValidacionesRequest();
    ejecutarValidacionesRequest.setVehiculoDTO(vehiculoDTO);
    ejecutarValidacionesRequest.setSolicitudId(0L);
    ejecutarValidacionesRequest.setIdAutoridad(0L);
    ejecutarValidacionesRequest.setNit("");
    ejecutarValidacionesRequest.setNombreArchivo("");
    ejecutarValidacionesRequest.setFallidoValEstruContenido(Boolean.FALSE);

    VehiculoDTO ejecutarValidaciones =
        validacionesCargueService.ejecutarValidaciones(ejecutarValidacionesRequest, false, true);

    Assertions.assertTrue(ejecutarValidaciones.isFallidoValEstruContenido());
  }

  @Test
  void ejecutarValidacionesCreacionExcepcionEliminacionValidacion() throws ErrorGeneralException {
    Mockito.when(
            iValidacionesEstructuraContenidoService.ejecutarValidaciones(
                Mockito.any(),
                Mockito.anyString(),
                Mockito.anyString(),
                Mockito.anyLong(),
                Mockito.anyLong()))
        .thenReturn(new ArrayList<>());

    VehiculoDTO vehiculoDTO = new VehiculoDTO();
    vehiculoDTO.setTipoCargue("E");

    EjecutarValidacionesRequest ejecutarValidacionesRequest = new EjecutarValidacionesRequest();
    ejecutarValidacionesRequest.setVehiculoDTO(vehiculoDTO);
    ejecutarValidacionesRequest.setSolicitudId(0L);
    ejecutarValidacionesRequest.setIdAutoridad(0L);
    ejecutarValidacionesRequest.setNit("");
    ejecutarValidacionesRequest.setNombreArchivo("");
    ejecutarValidacionesRequest.setFallidoValEstruContenido(Boolean.FALSE);

    VehiculoDTO ejecutarValidaciones =
        validacionesCargueService.ejecutarValidaciones(ejecutarValidacionesRequest, false, false);

    Assertions.assertFalse(ejecutarValidaciones.isFallidoValEstruContenido());
  }

  /**
   * Ejecutar validaciones modificacion.
   *
   * @param secuencia the secuencia
   * @param nit the nit
   * @param idSolicitud the id solicitud
   * @param idUsuario the id usuario
   * @throws ErrorGeneralException the error general exception
   */
  @ParameterizedTest
  @CsvSource({"13, 123456, 31, usuario"})
  @DisplayName("Ejecutar Validaciones Modificación")
  void ejecutarValidacionesModificacion(
      String secuencia, String nit, Long idSolicitud, String idUsuario)
      throws ErrorGeneralException {
    VehiculoDTO request =
        vehiculoDTOList.stream()
            .filter(vehiculo -> vehiculo.getSecuencia().equals(secuencia))
            .findFirst()
            .orElse(null);

    EjecutarValidacionesRequest ejecutarValidacionesRequest =
        getEjecutarValidacionesRequest(nit, idSolicitud, idUsuario, request);

    VehiculoDTO ejecutarValidaciones =
        validacionesCargueService.ejecutarValidaciones(ejecutarValidacionesRequest, false, false);

    Assertions.assertFalse(ejecutarValidaciones.isFallidoValEstruContenido());
  }

  /**
   * Ejecutar validaciones errores estructura cont.
   *
   * @param secuencia the secuencia
   * @param nit the nit
   * @param idSolicitud the id solicitud
   * @param idUsuario the id usuario
   * @throws ErrorGeneralException the error general exception
   */
  @CsvSource({"14, 123456, 31, usuario"})
  @DisplayName("Ejecutar Validaciones con errores de estructura y contenido")
  void ejecutarValidacionesErroresEstructuraCont(
      String secuencia, String nit, Long idSolicitud, String idUsuario)
      throws ErrorGeneralException {
    VehiculoDTO request =
        vehiculoDTOList.stream()
            .filter(vehiculo -> vehiculo.getSecuencia().equals(secuencia))
            .findFirst()
            .orElse(null);

    String nombreArchivo = "900327290AUT00220221228.txt";
    Long idAutoridad = 11001000L;
    Long idEmpresa = 31L;

    EjecutarValidacionesRequest ejecutarValidacionesRequest =
        getEjecutarValidacionesRequest(nit, idSolicitud, idUsuario, request);
    ejecutarValidacionesRequest.setIdAutoridad(idAutoridad);
    ejecutarValidacionesRequest.setIdEmpresa(idEmpresa);
    ejecutarValidacionesRequest.setNombreArchivo(nombreArchivo);

    Mockito.when(
            iValidacionesEstructuraContenidoService.ejecutarValidaciones(
                request, nit, nombreArchivo, idAutoridad, idSolicitud))
        .thenReturn(List.of("Errores"));

    VehiculoDTO ejecutarValidaciones =
        validacionesCargueService.ejecutarValidaciones(ejecutarValidacionesRequest, false, false);

    Assertions.assertTrue(ejecutarValidaciones.isFallidoValEstruContenido());
  }

  private EjecutarValidacionesRequest getEjecutarValidacionesRequest(
      String nit, Long idSolicitud, String idUsuario, VehiculoDTO request) {
    EjecutarValidacionesRequest ejecutarValidacionesRequest = new EjecutarValidacionesRequest();
    ejecutarValidacionesRequest.setVehiculoDTO(request);
    ejecutarValidacionesRequest.setSolicitudId(idSolicitud);
    ejecutarValidacionesRequest.setNit(nit);
    ejecutarValidacionesRequest.setIdUsuario(idUsuario);
    ejecutarValidacionesRequest.setFallidoValEstruContenido(Boolean.FALSE);
    return ejecutarValidacionesRequest;
  }
}
