package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import co.gov.runt.rna.rnacarguearchivosapiclient.jpa.entity.SolicitudCargueEntity;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.jpa.repository.SolicitudesCargueRepository;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IBatchService;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

/** The type Batch cargue detalle service test. */
@Slf4j
@ExtendWith(MockitoExtension.class)
class BatchCargueDetalleServiceTest {

  @InjectMocks private BatchCargueDetalleService batchCargueDetalleService;
  @Mock private IBatchService batchService;
  @Mock private SolicitudesCargueRepository solicitudCargueRepository;

  /** Procesar cargue detalle. */
  @Test
  @DisplayName("Procesar cargue detalle")
  void procesarCargueDetalle() {
    Mockito.when(
            solicitudCargueRepository.findSoliCargueByIdTipoArchivoAndEstado(Mockito.anyLong()))
        .thenReturn(List.of(new SolicitudCargueEntity()));

    batchCargueDetalleService.procesarCargueDetalle();

    Mockito.verify(batchService).ejecutar(Mockito.any());
    Mockito.verify(solicitudCargueRepository)
        .findSoliCargueByIdTipoArchivoAndEstado(Mockito.anyLong());
  }
}
