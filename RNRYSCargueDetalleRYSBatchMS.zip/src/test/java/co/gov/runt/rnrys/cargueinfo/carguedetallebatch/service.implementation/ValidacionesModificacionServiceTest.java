package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IMensajeService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IValidacionesComunesService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IValidacionesDeclaImportService;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.AutomotorEntity;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.MarcaVehiculoEntity;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.MensajeEntity;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ValidacionesModificacionServiceTest {

  @Mock IValidacionesComunesService validacionesComunesService;
  @Mock IValidacionesDeclaImportService validacionesDeclaImportService;
  @Mock IMensajeService iMensajeService;

  @InjectMocks ValidacionesModificacionService validacionesModificacionService;

  @Test
  void validarModificacionExitosoTest() throws ErrorGeneralException {

    VehiculoDTO vehiculoDTO = new VehiculoDTO();
    vehiculoDTO.setVin("");
    vehiculoDTO.setMarca("13");
    AutomotorEntity automotorEntity = new AutomotorEntity();
    MarcaVehiculoEntity marcaVehiculoEntity = new MarcaVehiculoEntity();
    marcaVehiculoEntity.setId(13L);
    automotorEntity.setMarcaVehiculo(marcaVehiculoEntity);
    automotorEntity.setEstado("REGISTRADO");

    Mockito.when(
            validacionesComunesService.obtenerAutomotorPorVin(Mockito.any(), Mockito.anyString()))
        .thenReturn(automotorEntity);
    validacionesModificacionService.validarModificacion(vehiculoDTO, "", "", 12L, 12L, "");

    Mockito.verify(validacionesComunesService)
        .obtenerAutomotorPorVin(Mockito.any(), Mockito.anyString());
  }

  @Test
  void validarModificacionErrorEstadoTest() throws ErrorGeneralException {

    VehiculoDTO vehiculoDTO = new VehiculoDTO();
    vehiculoDTO.setVin("");
    vehiculoDTO.setMarca("13");
    AutomotorEntity automotorEntity = new AutomotorEntity();
    MarcaVehiculoEntity marcaVehiculoEntity = new MarcaVehiculoEntity();
    marcaVehiculoEntity.setId(13L);
    automotorEntity.setMarcaVehiculo(marcaVehiculoEntity);
    automotorEntity.setEstado("ACTIVO");

    Mockito.when(
            validacionesComunesService.obtenerAutomotorPorVin(Mockito.any(), Mockito.anyString()))
        .thenReturn(automotorEntity);

    Exception exception =
        Assertions.assertThrows(
            ErrorGeneralException.class,
            () ->
                validacionesModificacionService.validarModificacion(
                    vehiculoDTO, "", "", 12L, 12L, ""));
    Assertions.assertNotNull(exception.getMessage());
  }

  @Test
  void validarModificacionErrorGuarismosTest() throws ErrorGeneralException {

    VehiculoDTO vehiculoDTO = new VehiculoDTO();
    vehiculoDTO.setVin("");
    vehiculoDTO.setMarca("13");
    AutomotorEntity automotorEntity = new AutomotorEntity();
    MarcaVehiculoEntity marcaVehiculoEntity = new MarcaVehiculoEntity();
    marcaVehiculoEntity.setId(10L);
    automotorEntity.setMarcaVehiculo(marcaVehiculoEntity);
    automotorEntity.setEstado("ACTIVO");

    Mockito.when(
            validacionesComunesService.obtenerAutomotorPorVin(Mockito.any(), Mockito.anyString()))
        .thenReturn(automotorEntity);

    MensajeEntity mensaje = new MensajeEntity();
    mensaje.setValor("Error");
    Exception exception =
        Assertions.assertThrows(
            ErrorGeneralException.class,
            () ->
                validacionesModificacionService.validarModificacion(
                    vehiculoDTO, "", "", 12L, 12L, ""));
    Assertions.assertNotNull(exception.getMessage());
  }
}
