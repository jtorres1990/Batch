package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.controller;

import co.gov.runt.rnf.procesadorsolicitudes.service.implementation.ThreadService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IBatchCargueDetalleService;
import co.gov.runt.utilidades.model.Mensaje;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

/** The type Batch controller test. */
@Slf4j
@ExtendWith(MockitoExtension.class)
class BatchControllerTest {

  @InjectMocks private BatchController batchController;
  @Mock private ThreadService threadService;
  @Mock private IBatchCargueDetalleService batchCargueDetalleService;

  /** Batch cargue archivo. */
  @Test
  @DisplayName("Batch cargue archivo")
  void batchCargueArchivo() {
    Mensaje resultado = batchController.batchCargueArchivo();

    Mockito.verify(threadService).executeOnThread(Mockito.any());
    Assertions.assertEquals("200", resultado.getCodigoResultado());
    Assertions.assertEquals(
        "Se inicializo el procesamiento de cargues de detalle de vehículo de forma exitosa",
        resultado.descripcionRespuesta);
  }
}
