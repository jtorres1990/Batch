package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.enums.MensajesErrorEnum;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.MensajeEntity;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.repository.MensajeRepository;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class IMensajeServiceTest {

  @InjectMocks MensajeService mensajeService;

  @Mock MensajeRepository mensajeRepository;

  @Test
  void obtenerMensajeExitosoTest() throws ErrorGeneralException {
    Mockito.when(mensajeRepository.findById(Mockito.anyString()))
        .thenReturn(Optional.of(new MensajeEntity()));
    mensajeService.obtenerMensaje(MensajesErrorEnum.MENSAJES_DIAN);
  }

  @Test
  void obtenerMensajeErrorTest() {
    Mockito.when(mensajeRepository.findById(Mockito.anyString())).thenReturn(Optional.empty());
    Exception exception =
        Assertions.assertThrows(
            ErrorGeneralException.class,
            () -> mensajeService.obtenerMensaje(MensajesErrorEnum.MENSAJES_DIAN));
    Assertions.assertNotNull(exception.getMessage());
  }
}
