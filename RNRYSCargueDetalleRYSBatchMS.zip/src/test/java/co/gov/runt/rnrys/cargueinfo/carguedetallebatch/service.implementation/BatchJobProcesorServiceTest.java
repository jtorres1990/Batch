package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import static org.junit.jupiter.api.Assertions.assertNull;

import co.gov.runt.rna.rnacarguearchivosapiclient.jpa.entity.*;
import co.gov.runt.rna.rnacarguearchivosapiclient.jpa.repository.SolicitudCargueRepository;
import co.gov.runt.rna.rnacarguearchivosapiclient.service.ICargueSolicitudService;
import co.gov.runt.rna.rnacarguearchivosapiclient.service.implementation.LogEstadoCargueService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.ILogMensajeCargueService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IMensajeService;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.utilities.FuncionesBatch;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.MensajeEntity;
import co.gov.runt.utilidades.exception.ElementoNoEncontradoException;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import co.gov.runt.utilidades.utilities.InformacionUsuario;
import java.io.IOException;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.item.ExecutionContext;

/** The type Batch job procesor service test. */
@Slf4j
@ExtendWith(MockitoExtension.class)
class BatchJobProcesorServiceTest {
  @InjectMocks private BatchJobProcesorService batchJobProcesorService;

  @Mock ICargueSolicitudService iCargueSolicitudService;

  @Mock ILogMensajeCargueService iLogMensajeCargueService;

  @Mock LogEstadoCargueService logEstadoCargueService;

  @Mock SolicitudCargueRepository solicitudCargueRepository;
  @Mock FuncionesBatch funcionesBatch;

  @Mock ExecutionContext executionContext;

  @Mock JobParameters jobParameters;

  @Mock IMensajeService iMensajeService;

  @Mock InformacionUsuario informacionUsuario;

  /** Dar id solicitud. */
  @Test
  @DisplayName("Dar IdSolicitud")
  void darIdSolicitud() {
    JobExecution jobExecution = Mockito.mock(JobExecution.class);

    Mockito.when(jobExecution.getJobParameters()).thenReturn(new JobParameters());

    assertNull(batchJobProcesorService.darIdSolicitud(jobExecution));
    Mockito.verify(jobExecution).getJobParameters();
  }

  /**
   * Cambiar estado inicial.
   *
   * @throws ElementoNoEncontradoException the elemento no encontrado exception
   */
  @Test
  @DisplayName("Cambiar estado inicial")
  void cambiarEstadoInicial() throws ElementoNoEncontradoException {
    SolicitudCargueEntity solicitudesCargueEntity = new SolicitudCargueEntity();
    solicitudesCargueEntity.setSolicitud(1L);

    EstadoCargueEntity estadoCargueEntity = new EstadoCargueEntity();
    estadoCargueEntity.setId((short) 1);
    estadoCargueEntity.setNombre("Nombre");

    Mockito.when(iCargueSolicitudService.cambiarEstado(Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(estadoCargueEntity);

    batchJobProcesorService.cambiarEstadoInicial(solicitudesCargueEntity);

    Mockito.verify(logEstadoCargueService)
        .registrarLogEstado(Mockito.any(), Mockito.any(), Mockito.any());
    Mockito.verify(iCargueSolicitudService)
        .cambiarEstado(Mockito.any(), Mockito.any(), Mockito.any());
  }

  /**
   * Actualizar batch service.
   *
   * @param idSolicitud the id solicitud
   * @param idJob the id job
   * @param estado the estado
   */
  @ParameterizedTest
  @CsvSource({"1, 1, estado"})
  @DisplayName("Actualizar batch service")
  void actualizarBatchService(Long idSolicitud, Long idJob, String estado) {
    SolicitudCargueEntity solicitud = new SolicitudCargueEntity();
    solicitud.setIdBatchSolicitud(new BatchSolicitudCargueEntity());

    Mockito.when(solicitudCargueRepository.findById(Mockito.anyLong()))
        .thenReturn(Optional.of(solicitud));

    batchJobProcesorService.actualizarBatchService(idSolicitud, idJob, estado);

    Mockito.verify(iCargueSolicitudService).actualizarBatchSolicitudCargue(Mockito.any());
  }

  @Test
  void procesarFinalizacionJobExitosoTest()
      throws ElementoNoEncontradoException, ErrorGeneralException, IOException, ExecutionException {
    JobExecution jobExecution = Mockito.mock(JobExecution.class);
    Mockito.when(jobExecution.getJobParameters()).thenReturn(jobParameters);
    Mockito.when(jobExecution.getExecutionContext()).thenReturn(executionContext);
    Mockito.when(jobParameters.getString(Mockito.anyString())).thenReturn("2", "2");
    Mockito.when(executionContext.get(Mockito.anyString())).thenReturn(0, 0, 1);
    MensajeEntity mensaje = new MensajeEntity();
    mensaje.setValor("sd");
    Mockito.when(iMensajeService.obtenerMensaje(Mockito.any())).thenReturn(mensaje);
    SolicitudCargueEntity solicitudesCargueEntity = new SolicitudCargueEntity();
    solicitudesCargueEntity.setUsuario("fd");
    Mockito.when(solicitudCargueRepository.findById(Mockito.anyLong()))
        .thenReturn(Optional.of(solicitudesCargueEntity));
    batchJobProcesorService.procesarFinalizacionJob(jobExecution);
    Mockito.verify(iLogMensajeCargueService)
        .guardarLog(Mockito.anyString(), Mockito.anyLong(), Mockito.any());
  }

  @Test
  void procesarFinalizacionJobGuardadosTest()
      throws ElementoNoEncontradoException, ErrorGeneralException, IOException, ExecutionException {
    JobExecution jobExecution = Mockito.mock(JobExecution.class);
    Mockito.when(jobExecution.getJobParameters()).thenReturn(jobParameters);
    Mockito.when(jobExecution.getExecutionContext()).thenReturn(executionContext);
    Mockito.when(jobParameters.getString(Mockito.anyString())).thenReturn("2", "2");
    Mockito.when(executionContext.get(Mockito.anyString())).thenReturn(0, 0, null);
    MensajeEntity mensaje = new MensajeEntity();
    mensaje.setValor("sd");
    Mockito.when(iMensajeService.obtenerMensaje(Mockito.any())).thenReturn(mensaje);
    SolicitudCargueEntity solicitudesCargueEntity = new SolicitudCargueEntity();
    solicitudesCargueEntity.setUsuario("fd");
    Mockito.when(solicitudCargueRepository.findById(Mockito.anyLong()))
        .thenReturn(Optional.of(solicitudesCargueEntity));
    batchJobProcesorService.procesarFinalizacionJob(jobExecution);
    Mockito.verify(iLogMensajeCargueService)
        .guardarLog(Mockito.anyString(), Mockito.anyLong(), Mockito.any());
  }

  @Test
  void procesarFinalizacionJobGuardadosExitosoTest()
      throws ElementoNoEncontradoException, ErrorGeneralException, IOException, ExecutionException {
    JobExecution jobExecution = Mockito.mock(JobExecution.class);
    Mockito.when(jobExecution.getJobParameters()).thenReturn(jobParameters);
    Mockito.when(jobExecution.getExecutionContext()).thenReturn(executionContext);
    Mockito.when(jobParameters.getString(Mockito.anyString())).thenReturn("2", "2");
    Mockito.when(executionContext.get(Mockito.anyString())).thenReturn(0, 0, 2);
    MensajeEntity mensaje = new MensajeEntity();
    mensaje.setValor("sd");
    Mockito.when(iMensajeService.obtenerMensaje(Mockito.any())).thenReturn(mensaje);
    SolicitudCargueEntity solicitudesCargueEntity = new SolicitudCargueEntity();
    solicitudesCargueEntity.setUsuario("fd");
    Mockito.when(solicitudCargueRepository.findById(Mockito.anyLong()))
        .thenReturn(Optional.of(solicitudesCargueEntity));
    batchJobProcesorService.procesarFinalizacionJob(jobExecution);
    Mockito.verify(iLogMensajeCargueService)
        .guardarLog(Mockito.anyString(), Mockito.anyLong(), Mockito.any());
  }
}
