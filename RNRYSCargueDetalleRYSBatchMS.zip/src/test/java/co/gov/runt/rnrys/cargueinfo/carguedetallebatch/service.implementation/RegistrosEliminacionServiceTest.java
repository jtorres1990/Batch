package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.entity.AutomotorEntity;
import co.gov.runt.rnrys.cargueinfo.core.consultas.jpa.repository.AutomotorRepository;
import co.gov.runt.rnrys.cargueinfo.core.registros.service.IRegistroCargueDetalleRnaService;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import java.util.ArrayList;
import java.util.Collections;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

/** The type Registros eliminacion service test. */
@Slf4j
@ExtendWith(MockitoExtension.class)
class RegistrosEliminacionServiceTest {

  @InjectMocks private RegistrosEliminacionService registrosEliminacionService;
  @Mock IRegistroCargueDetalleRnaService registroCargueDetalleVehiculo;
  @Mock AutomotorRepository automotorRepository;

  @Test
  void eliminarCargueCreacionTest() throws ErrorGeneralException {
    Mockito.when(automotorRepository.findFiltered(Mockito.any()))
        .thenReturn(Collections.singletonList(new AutomotorEntity()));
    registrosEliminacionService.eliminarCargueCreacion(new VehiculoDTO());

    Mockito.verify(registroCargueDetalleVehiculo).registroCargueDetalleVehiculo(Mockito.any());
  }

  @Test
  void eliminarCargueTest() throws ErrorGeneralException {
    Mockito.when(automotorRepository.findFiltered(Mockito.any())).thenReturn(new ArrayList<>());
    registrosEliminacionService.eliminarCargueCreacion(new VehiculoDTO());

    Mockito.verify(registroCargueDetalleVehiculo).registroCargueDetalleVehiculo(Mockito.any());
  }
}
