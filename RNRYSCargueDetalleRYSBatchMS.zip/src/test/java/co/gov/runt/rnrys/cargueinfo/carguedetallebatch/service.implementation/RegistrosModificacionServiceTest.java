package co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.implementation;

import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.dto.VehiculoDTO;
import co.gov.runt.rnrys.cargueinfo.carguedetallebatch.service.IRegistrosComunService;
import co.gov.runt.rnrys.cargueinfo.core.registros.dto.RegistroRequest;
import co.gov.runt.rnrys.cargueinfo.core.registros.service.IRegistroCargueDetalleRnaService;
import co.gov.runt.utilidades.exception.ErrorGeneralException;
import co.gov.runt.utilidades.utilities.UtilidadesJson;
import com.fasterxml.jackson.core.type.TypeReference;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

/** The type Registros modificacion service test. */
@Slf4j
@ExtendWith(MockitoExtension.class)
class RegistrosModificacionServiceTest {

  @InjectMocks private RegistrosModificacionService registrosModificacionService;
  @Mock private IRegistroCargueDetalleRnaService iRegistroCargueDetalleRnaService;
  @Mock private IRegistrosComunService iRegistrosComunService;

  private List<VehiculoDTO> vehiculoDTOList;

  /**
   * Sets .
   *
   * @throws ErrorGeneralException the error general exception
   */
  @BeforeEach
  void setup() throws ErrorGeneralException {
    vehiculoDTOList =
        UtilidadesJson.cargarJsonDesdeArchivo("vehiculoDTO.json", new TypeReference<>() {});
  }

  /**
   * Modificar cargue creacion.
   *
   * @param secuencia the secuencia
   * @param nit the nit
   * @param idUsuario the id usuario
   * @param idAutoridad the id autoridad
   * @param ip the ip
   * @param idSolicitud the id solicitud
   * @throws ErrorGeneralException the error general exception
   */
  @ParameterizedTest
  @CsvSource({"10, nit, usuario, 1, ip, 1"})
  @DisplayName("Modificar Cargue Creacion")
  void modificarCargueCreacion(
      String secuencia, String nit, String idUsuario, Long idAutoridad, String ip, Long idSolicitud)
      throws ErrorGeneralException {
    VehiculoDTO request =
        vehiculoDTOList.stream()
            .filter(vehiculo -> vehiculo.getSecuencia().equals(secuencia))
            .findFirst()
            .orElse(null);

    Mockito.when(
            iRegistrosComunService.crearRegistroRequest(
                Mockito.any(),
                Mockito.anyString(),
                Mockito.anyString(),
                Mockito.anyLong(),
                Mockito.anyString(),
                Mockito.anyLong()))
        .thenReturn(new RegistroRequest());

    registrosModificacionService.modificarCargueCreacion(
        request, nit, idUsuario, idAutoridad, ip, idSolicitud);

    Mockito.verify(iRegistroCargueDetalleRnaService).registroCargueDetalleVehiculo(Mockito.any());
    Mockito.verify(iRegistrosComunService)
        .crearRegistroRequest(
            Mockito.any(),
            Mockito.anyString(),
            Mockito.anyString(),
            Mockito.anyLong(),
            Mockito.anyString(),
            Mockito.anyLong());
  }
}
